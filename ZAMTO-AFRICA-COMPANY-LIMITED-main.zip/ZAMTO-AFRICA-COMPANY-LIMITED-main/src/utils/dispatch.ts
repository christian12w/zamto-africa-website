import type { DispatchResult } from './dispatchTypes';
import { buildWhatsAppUrl, SUPPORT_EMAIL } from './format';

export interface NotificationDispatchPayload {
  kind:
    | 'Car Hire Booking'
    | 'Contact Inquiry'
    | 'Test Drive Request'
    | 'Purchase Offer'
    | 'Sell / Trade-In Lead';
  reference?: string;
  customerName: string;
  customerPhone: string;
  customerEmail?: string;
  topicOrVehicle?: string;
  pickupLocation?: string;
  dropoffLocation?: string;
  dateRange?: string;
  totalDisplay?: string;
  paymentSummary?: string;
  message?: string;
}

export async function dispatchZamtoNotification(
  payload: NotificationDispatchPayload
): Promise<DispatchResult> {
  const fallbackText = [
    `ZAMTO AFRICA — ${payload.kind.toUpperCase()}`,
    `Client: ${payload.customerName}`,
    `Phone: ${payload.customerPhone}`,
    payload.customerEmail ? `Email: ${payload.customerEmail}` : '',
    payload.topicOrVehicle ? `Vehicle / Topic: ${payload.topicOrVehicle}` : '',
    payload.pickupLocation ? `Pickup: ${payload.pickupLocation}` : '',
    payload.dropoffLocation ? `Drop-off: ${payload.dropoffLocation}` : '',
    payload.dateRange ? `Dates: ${payload.dateRange}` : '',
    payload.totalDisplay ? `Amount: ${payload.totalDisplay}` : '',
    payload.paymentSummary ? `Payment: ${payload.paymentSummary}` : '',
    payload.message ? `Details: ${payload.message}` : '',
  ]
    .filter(Boolean)
    .join('\n');

  const fallbackResult: DispatchResult = {
    ok: false,
    reference: payload.reference || `ZA-${Date.now().toString().slice(-6)}`,
    emailSent: false,
    emailProvider: 'none',
    whatsappCloudSent: false,
    whatsappUrl: buildWhatsAppUrl(fallbackText),
    mailtoUrl: `mailto:${SUPPORT_EMAIL}?subject=${encodeURIComponent(
      `[Zamto Africa ${payload.kind}] ${payload.customerName}`
    )}&body=${encodeURIComponent(fallbackText)}`,
    targetEmail: SUPPORT_EMAIL,
    targetWhatsAppDisplay: '+260 572 213 038',
  };

  try {
    const res = await fetch('/api/notify', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    if (!res.ok) return fallbackResult;
    const data = (await res.json()) as Partial<DispatchResult>;
    return {
      ...fallbackResult,
      ...data,
      ok: Boolean(data.ok),
    };
  } catch {
    return fallbackResult;
  }
}
