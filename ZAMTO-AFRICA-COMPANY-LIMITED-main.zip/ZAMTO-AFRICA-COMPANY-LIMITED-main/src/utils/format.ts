import type { CurrencyMode } from '../types';

// Current Bank of Zambia / interbank indicative default rate (updated daily / editable in Admin)
export const DEFAULT_ZMW_PER_USD = 20.61;
const FX_STORAGE_KEY = 'zamto_africa_zmw_per_usd_v1';

let cachedZmwPerUsd: number = (() => {
  try {
    const raw = localStorage.getItem(FX_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as { rate?: number };
      if (parsed.rate && parsed.rate > 5 && parsed.rate < 100) {
        return parsed.rate;
      }
    }
  } catch {
    // Ignore storage read errors
  }
  return DEFAULT_ZMW_PER_USD;
})();

export function getZmwPerUsd(): number {
  return cachedZmwPerUsd;
}

export function setZmwPerUsd(rate: number, source: 'live' | 'admin' = 'admin'): number {
  if (!Number.isFinite(rate) || rate < 5 || rate > 100) return cachedZmwPerUsd;
  const rounded = Math.round(rate * 100) / 100;
  cachedZmwPerUsd = rounded;
  try {
    localStorage.setItem(
      FX_STORAGE_KEY,
      JSON.stringify({
        rate: rounded,
        source,
        updatedAt: new Date().toISOString(),
      })
    );
  } catch {
    // Ignore storage quota errors
  }
  return rounded;
}

export function getFxMetadata(): { rate: number; source: string; updatedAt: string | null } {
  try {
    const raw = localStorage.getItem(FX_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as { rate?: number; source?: string; updatedAt?: string };
      return {
        rate: parsed.rate || cachedZmwPerUsd,
        source: parsed.source || 'Bank of Zambia Indicative',
        updatedAt: parsed.updatedAt || null,
      };
    }
  } catch {
    // Ignore
  }
  return {
    rate: cachedZmwPerUsd,
    source: 'Bank of Zambia Indicative',
    updatedAt: null,
  };
}

export async function fetchLiveUsdZmwRate(): Promise<number | null> {
  try {
    const res = await fetch('https://open.er-api.com/v6/latest/USD');
    if (!res.ok) return null;
    const data = (await res.json()) as { rates?: { ZMW?: number } };
    const rate = data?.rates?.ZMW;
    if (typeof rate === 'number' && rate > 5 && rate < 100) {
      return setZmwPerUsd(rate, 'live');
    }
    return null;
  } catch {
    return null;
  }
}

export const WHATSAPP_NUMBER = '260572213038';
export const SUPPORT_PHONE_DISPLAY = '+260 572 213 038';
export const SUPPORT_EMAIL = 'zamtoafrica@gmail.com';
export const COMPANY_NAME = 'Zamto Africa';
export const COMPANY_LEGAL_NAME = 'Zamto Africa Company Limited';
export const ZAMTO_LOGO_URL = '/assets/aistudio/logo_529d2d6f.png';
export const GOOGLE_MAPS_API_KEY = import.meta.env.VITE_GOOGLE_MAPS_API_KEY || '';
export const HEAD_OFFICE_ADDRESS =
  'Corner of Katapola Road & Great East Rd, Plot 1222, Rhodes Park, Lusaka';
export const RENTAL_AGREEMENT_PDF =
  '/assets/aistudio/CAR_RENTAL_AGREEMENT_V1.0_Phoenix_7d3cf85c.pdf';

export const SOCIAL_LINKS = {
  facebook: 'https://www.facebook.com/profile.php?id=61581947339658&mibextid=wwXIfr',
  instagram: 'https://www.instagram.com/zamtoafrica?igsh=MWN3b3ZxMGk0OXIzaA%3D%3D&utm_source=qr',
  tiktok: 'https://www.tiktok.com/@zamtoafrica',
  whatsapp: `https://wa.me/${WHATSAPP_NUMBER}`,
};

export function formatMoney(
  amountZmw: number,
  currency: CurrencyMode,
  overrideRate?: number
): string {
  if (currency === 'USD') {
    const rate = overrideRate && overrideRate > 0 ? overrideRate : cachedZmwPerUsd;
    const usd = amountZmw / rate;
    const formatted =
      usd < 200
        ? usd.toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 2 })
        : Math.round(usd).toLocaleString('en-US');
    return `USD ${formatted}`;
  }
  return `ZMW ${Math.round(amountZmw).toLocaleString('en-US')}`;
}

export function formatDualUsdFirst(amountZmw: number, overrideRate?: number): string {
  return `${formatMoney(amountZmw, 'USD', overrideRate)} / ${formatMoney(amountZmw, 'ZMW', overrideRate)}`;
}

/** Extracts the included 16% Zambian VAT portion from a VAT-inclusive ZMW total */
export function calcIncludedZambiaVat(vatInclusiveZmw: number): number {
  if (!Number.isFinite(vatInclusiveZmw) || vatInclusiveZmw <= 0) return 0;
  return Math.round((vatInclusiveZmw * 16) / 116);
}

export function calculateDays(startDate: string, endDate: string): number {
  if (!startDate || !endDate) return 3;
  const start = new Date(startDate);
  const end = new Date(endDate);
  const diff = Math.round((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24));
  return diff > 0 ? diff : 1;
}

export function buildWhatsAppUrl(message: string): string {
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
}

