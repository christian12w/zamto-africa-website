export interface DispatchResult {
  ok: boolean;
  reference: string;
  emailSent: boolean;
  emailProvider: string;
  emailError?: string;
  whatsappCloudSent: boolean;
  whatsappUrl: string;
  mailtoUrl: string;
  targetEmail: string;
  targetWhatsAppDisplay: string;
}
