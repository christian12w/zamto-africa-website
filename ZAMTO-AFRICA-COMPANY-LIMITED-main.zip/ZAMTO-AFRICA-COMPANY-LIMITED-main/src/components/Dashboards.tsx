import React, { useState } from 'react';
import {
  CalendarCheck,
  Car,
  Check,
  Copy,
  CreditCard,
  Download,
  Edit3,
  FileText,
  ImagePlus,
  KeyRound,
  Lock,
  LogOut,
  Mail,
  MessageCircle,
  PlusCircle,
  RefreshCw,
  RotateCcw,
  ShieldCheck,
  Trash2,
  X,
} from 'lucide-react';
import { signInWithPopup } from 'firebase/auth';
import { auth, googleAuthProvider } from '../lib/firebase';
import {
  buildBrandedResendEmailHtml,
  buildResendDashboardHtmlTemplate,
  RESEND_GLOBAL_CSS,
  ZAMTO_BRAND_LOGO_PATH,
} from '../lib/resendEmailTemplate';
import type {
  CurrencyMode,
  CustomerBooking,
  HireVehicle,
  PageRoute,
  SaleVehicle,
  SellCarSubmission,
  VehicleCategory,
  VehiclePhoto,
} from '../types';
import {
  IMG_INTERIOR,
  IMG_STUDIO_ALPHARD,
  IMG_STUDIO_CX5,
  IMG_STUDIO_HATCH,
  IMG_STUDIO_HILUX,
  IMG_STUDIO_PRADO,
  IMG_STUDIO_SEDAN,
  IMG_STUDIO_TRUCK,
  ZAMBIA_LOCATIONS,
} from '../data/zambiaData';
import { useI18n } from '../i18n/I18nContext';
import { dispatchZamtoNotification } from '../utils/dispatch';
import {
  buildWhatsAppUrl,
  formatDualUsdFirst,
  formatMoney,
  getFxMetadata,
  RENTAL_AGREEMENT_PDF,
} from '../utils/format';
import { SignedRentalContractModal } from './SignedRentalContractModal';
import { PaymentCheckoutWidget, type PaymentCompletionResult } from './PaymentCheckoutWidget';
import { VehicleImage } from './VehicleImage';

const STUDIO_PRESET_PHOTOS: { label: string; url: string }[] = [
  { label: 'Compact Hatch Studio', url: IMG_STUDIO_HATCH },
  { label: 'Mazda CX-5 Studio', url: IMG_STUDIO_CX5 },
  { label: 'Mark X Sedan Studio', url: IMG_STUDIO_SEDAN },
  { label: 'Prado 4×4 Studio', url: IMG_STUDIO_PRADO },
  { label: 'Hilux Pickup Studio', url: IMG_STUDIO_HILUX },
  { label: 'Alphard MPV Studio', url: IMG_STUDIO_ALPHARD },
  { label: 'Box Truck Studio', url: IMG_STUDIO_TRUCK },
  { label: 'SUV Interior', url: IMG_INTERIOR },
];

function readImageAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const rawUrl = String(reader.result || '');
      if (!rawUrl.startsWith('data:image/')) {
        resolve(rawUrl);
        return;
      }
      const img = new Image();
      img.onload = () => {
        const maxDim = 1280;
        let { width, height } = img;
        if (width > maxDim || height > maxDim) {
          const ratio = Math.min(maxDim / width, maxDim / height);
          width = Math.round(width * ratio);
          height = Math.round(height * ratio);
        }
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(rawUrl);
          return;
        }
        ctx.drawImage(img, 0, 0, width, height);
        resolve(canvas.toDataURL('image/jpeg', 0.82));
      };
      img.onerror = () => resolve(rawUrl);
      img.src = rawUrl;
    };
    reader.onerror = () => reject(new Error('Could not read file'));
    reader.readAsDataURL(file);
  });
}

export const MyBookingsView: React.FC<{
  bookings: CustomerBooking[];
  currency: CurrencyMode;
  onCancelBooking: (id: string) => void;
  onCompleteBookingPayment: (id: string, payment: PaymentCompletionResult) => void;
  onNavigate: (route: PageRoute) => void;
}> = ({
  bookings,
  currency,
  onCancelBooking,
  onCompleteBookingPayment,
  onNavigate,
}) => {
  const { t } = useI18n();
  const [contractBooking, setContractBooking] = useState<CustomerBooking | null>(null);
  const [payingBooking, setPayingBooking] = useState<CustomerBooking | null>(null);

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-10 sm:py-14 space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.16em] text-[#e11d48] mb-1">
            {t.bookings.kicker}
          </p>
          <h1 className="text-3xl sm:text-4xl font-semibold text-[#003087]">
            {t.bookings.title}
          </h1>
          <p className="text-sm text-[#475569] mt-1">{t.bookings.subtitle}</p>
        </div>
        <button
          type="button"
          onClick={() => onNavigate('hire')}
          className="rounded-lg bg-[#003087] text-white text-xs sm:text-sm font-semibold px-4 py-2.5 whitespace-nowrap"
        >
          {t.bookings.newBookingBtn}
        </button>
      </div>

      {bookings.length === 0 ? (
        <div className="rounded-2xl bg-white border border-[#e2e8f0] p-10 text-center space-y-4">
          <CalendarCheck className="w-10 h-10 text-[#003087] mx-auto opacity-80" />
          <h2 className="text-xl font-semibold text-[#003087]">{t.bookings.emptyTitle}</h2>
          <p className="text-sm text-[#64748b] max-w-md mx-auto">{t.bookings.emptyDesc}</p>
          <div className="flex justify-center gap-3 pt-2">
            <button
              type="button"
              onClick={() => onNavigate('hire')}
              className="rounded-lg bg-[#003087] text-white text-xs font-semibold px-5 py-2.5"
            >
              {t.bookings.browseHireBtn}
            </button>
            <button
              type="button"
              onClick={() => onNavigate('sales')}
              className="rounded-lg border border-[#003087] text-[#003087] text-xs font-semibold px-5 py-2.5"
            >
              {t.bookings.browseSalesBtn}
            </button>
          </div>
        </div>
      ) : (
        <div className="space-y-4">
          {bookings.map((b) => {
            const isPaid = b.paymentStatus === 'Paid';
            const canPayOnline =
              b.type === 'Car Hire' && b.status !== 'Cancelled' && !isPaid;

            return (
              <article
                key={b.id}
                className="rounded-2xl bg-white border border-[#e2e8f0] p-5 flex flex-col lg:flex-row lg:items-center justify-between gap-4"
              >
                <div className="space-y-1.5">
                  <div className="flex flex-wrap items-center gap-2 text-xs">
                    <span className="font-mono font-bold text-[#e11d48]">{b.id}</span>
                    <span>·</span>
                    <span className="font-semibold text-[#003087]">{b.type}</span>
                    <span>·</span>
                    <span
                      className={`font-semibold ${
                        b.status === 'Cancelled' ? 'text-[#be123c]' : 'text-[#003087]'
                      }`}
                    >
                      {b.status}
                    </span>
                    {b.paymentStatus && (
                      <>
                        <span>·</span>
                        <span className="font-semibold text-[#0f172a]">
                          {b.paymentStatus}
                          {b.paymentTransactionRef ? ` (${b.paymentTransactionRef})` : ''}
                        </span>
                      </>
                    )}
                  </div>
                  <h2 className="text-lg font-semibold text-[#0f172a]">{b.vehicleName}</h2>
                  <p className="text-xs text-[#64748b]">
                    {b.startDate}
                    {b.endDate ? ` to ${b.endDate}` : ''} · {b.pickupLocation || 'Lusaka Rhodes Park'}
                    {b.packageTier ? ` · ${b.packageTier} Package` : ''}
                    {b.tripZone ? ` (${b.tripZone})` : ''}
                  </p>
                  <p className="text-xs text-[#475569]">
                    Guest: {b.customerName} ({b.customerPhone}) · Payment: {b.paymentMethod}
                    {b.nrcOrPassport ? ` · ID: ${b.nrcOrPassport}` : ''}
                    {b.agreementAccepted ? ' · Agreement Signed' : ''}
                  </p>
                  {b.hireKind === 'Company' && b.companyName && (
                    <p className="text-[11px] font-medium text-[#003087]">
                      Corporate Account: {b.companyName}
                    </p>
                  )}
                </div>

                <div className="flex flex-col sm:flex-row lg:flex-col items-start sm:items-center lg:items-end gap-2.5">
                  <p className="text-base sm:text-lg font-bold text-[#003087] tabular-nums text-right">
                    {formatDualUsdFirst(b.totalZmw)}
                  </p>

                  <div className="flex flex-wrap items-center gap-2">
                    {b.type === 'Car Hire' && (
                      <button
                        type="button"
                        onClick={() => setContractBooking(b)}
                        className="rounded-lg bg-[#eff6ff] border border-[#bfdbfe] hover:border-[#003087] px-3 py-1.5 text-xs font-semibold text-[#003087] inline-flex items-center gap-1.5"
                      >
                        <FileText className="w-3.5 h-3.5 text-[#e11d48]" />
                        <span>{t.bookings.signedAgreementBtn}</span>
                      </button>
                    )}

                    {canPayOnline && (
                      <button
                        type="button"
                        onClick={() => setPayingBooking(b)}
                        className="rounded-lg bg-[#e11d48] hover:bg-[#be123c] px-3 py-1.5 text-xs font-bold text-white inline-flex items-center gap-1.5"
                      >
                        <CreditCard className="w-3.5 h-3.5" />
                        <span>{t.bookings.payOnlineBtn}</span>
                      </button>
                    )}

                    <a
                      href={RENTAL_AGREEMENT_PDF}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="rounded-lg border border-[#cbd5e1] hover:border-[#003087] px-3 py-1.5 text-xs font-semibold text-[#475569] inline-flex items-center gap-1"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>PDF</span>
                    </a>

                    <a
                      href={buildWhatsAppUrl(
                        `Hello Zamto Africa, checking on booking ${b.id} (${b.vehicleName}, ${b.paymentStatus || b.paymentMethod}).`
                      )}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="rounded-lg border border-[#cbd5e1] hover:border-[#003087] px-3 py-1.5 text-xs font-semibold text-[#003087] inline-flex items-center gap-1"
                    >
                      <MessageCircle className="w-3.5 h-3.5" />
                      <span>{t.bookings.supportBtn}</span>
                    </a>

                    {b.status !== 'Cancelled' && (
                      <button
                        type="button"
                        onClick={() => onCancelBooking(b.id)}
                        className="rounded-lg border border-[#fecdd3] hover:bg-[#fff1f2] px-3 py-1.5 text-xs font-semibold text-[#be123c]"
                      >
                        {t.bookings.cancelBtn}
                      </button>
                    )}
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      )}

      {contractBooking && (
        <SignedRentalContractModal
          booking={contractBooking}
          currency={currency}
          onClose={() => setContractBooking(null)}
        />
      )}

      {payingBooking && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-xl w-full shadow-2xl border border-[#e2e8f0] overflow-hidden">
            <div className="bg-[#003087] text-white px-5 py-4 flex items-center justify-between">
              <div>
                <p className="text-[11px] uppercase tracking-wider text-[#fda4af] font-semibold">
                  {t.bookings.completePaymentTitle} · {payingBooking.id}
                </p>
                <h2 className="text-lg font-semibold text-white">{payingBooking.vehicleName}</h2>
              </div>
              <button
                type="button"
                onClick={() => setPayingBooking(null)}
                className="p-1.5 rounded hover:bg-white/10"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-5 sm:p-6">
              <PaymentCheckoutWidget
                totalZmw={
                  payingBooking.paidAmountZmw && payingBooking.paidAmountZmw < payingBooking.totalZmw
                    ? payingBooking.totalZmw - payingBooking.paidAmountZmw
                    : payingBooking.totalZmw
                }
                currency={currency}
                defaultPhone={payingBooking.customerPhone}
                defaultName={payingBooking.customerName}
                defaultEmail={payingBooking.customerEmail}
                bookingRef={payingBooking.id}
                vehicleName={payingBooking.vehicleName}
                onBeforeRedirect={(pendingMeta) => {
                  try {
                    sessionStorage.setItem(
                      'zamto_pending_checkout_v1',
                      JSON.stringify({
                        mode: 'update',
                        bookingId: payingBooking.id,
                        paymentMethod: pendingMeta.paymentMethod,
                        payOption: pendingMeta.payOption,
                        amountDueZmw: pendingMeta.amountDueZmw,
                      })
                    );
                  } catch {
                    // Ignore session storage errors
                  }
                }}
                onPaymentCompleted={(payment) => {
                  onCompleteBookingPayment(payingBooking.id, payment);
                  void dispatchZamtoNotification({
                    kind: 'Car Hire Booking',
                    reference: payingBooking.id,
                    customerName: payingBooking.customerName,
                    customerPhone: payingBooking.customerPhone,
                    customerEmail: payingBooking.customerEmail,
                    topicOrVehicle: payingBooking.vehicleName,
                    pickupLocation: payingBooking.pickupLocation,
                    dropoffLocation: payingBooking.dropoffLocation,
                    dateRange: `${payingBooking.startDate} to ${payingBooking.endDate || ''}`,
                    totalDisplay: formatMoney(payingBooking.totalZmw, currency),
                    paymentSummary: `${payment.paymentStatus} via ${payment.paymentMethod} (${payment.transactionRef})`,
                  });
                  setPayingBooking(null);
                }}
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

/* ---------------- ADMIN VEHICLE EDIT MODALS ---------------- */

const HireVehicleEditorModal: React.FC<{
  vehicle: HireVehicle;
  onSave: (updated: HireVehicle) => void;
  onClose: () => void;
}> = ({ vehicle, onSave, onClose }) => {
  const [draft, setDraft] = useState<HireVehicle>({ ...vehicle, photos: [...vehicle.photos] });
  const [featuresText, setFeaturesText] = useState(vehicle.features.join(', '));
  const [allowCityExit, setAllowCityExit] = useState(Boolean(vehicle.cityExitRateZmw));
  const [newPhotoUrl, setNewPhotoUrl] = useState('');
  const [newPhotoLabel, setNewPhotoLabel] = useState('Side / Studio Angle');

  const handleUploadFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const dataUrl = await readImageAsDataUrl(file);
      if (dataUrl) {
        setDraft((prev) => ({
          ...prev,
          photos: [{ url: dataUrl, label: file.name.replace(/\.[^.]+$/, '') || 'Uploaded Photo' }, ...prev.photos],
        }));
      }
    } catch {
      // Ignore invalid file read
    }
    e.target.value = '';
  };

  const handleAddPhotoUrl = () => {
    if (!newPhotoUrl.trim()) return;
    const item: VehiclePhoto = {
      url: newPhotoUrl.trim(),
      label: newPhotoLabel.trim() || 'Vehicle Photo',
    };
    setDraft((prev) => ({ ...prev, photos: [...prev.photos, item] }));
    setNewPhotoUrl('');
  };

  const setPrimaryPhoto = (idx: number) => {
    setDraft((prev) => {
      const copy = [...prev.photos];
      const [chosen] = copy.splice(idx, 1);
      return { ...prev, photos: [chosen, ...copy] };
    });
  };

  const removePhoto = (idx: number) => {
    setDraft((prev) => {
      if (prev.photos.length <= 1) return prev;
      return { ...prev, photos: prev.photos.filter((_, i) => i !== idx) };
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanedFeatures = featuresText
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean);
    onSave({
      ...draft,
      dailyRateZmw: draft.premiumRateZmw || draft.dailyRateZmw,
      cityExitRateZmw: allowCityExit ? draft.cityExitRateZmw || draft.dailyRateZmw + 500 : undefined,
      locations: allowCityExit ? ZAMBIA_LOCATIONS : ZAMBIA_LOCATIONS.slice(0, 7),
      features: cleanedFeatures.length > 0 ? cleanedFeatures : draft.features,
    });
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-3xl w-full max-h-[92vh] overflow-y-auto shadow-2xl border border-[#e2e8f0]">
        <div className="sticky top-0 z-10 bg-[#003087] text-white px-5 py-4 flex items-center justify-between">
          <div>
            <p className="text-[11px] uppercase tracking-wider text-[#fda4af] font-semibold">
              Edit Hire Vehicle Details
            </p>
            <h2 className="text-lg font-semibold text-white">{draft.name || 'Vehicle'}</h2>
          </div>
          <button type="button" onClick={onClose} className="p-1.5 rounded hover:bg-white/10">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 sm:p-6 space-y-5 text-xs">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="sm:col-span-2">
              <label className="block font-semibold text-[#475569] mb-1">Vehicle Name *</label>
              <input
                type="text"
                required
                value={draft.name}
                onChange={(e) => setDraft({ ...draft, name: e.target.value })}
                className="w-full rounded-lg border border-[#cbd5e1] px-3 py-2 text-sm"
              />
            </div>
            <div>
              <label className="block font-semibold text-[#475569] mb-1">Brand</label>
              <input
                type="text"
                value={draft.brand}
                onChange={(e) => setDraft({ ...draft, brand: e.target.value })}
                className="w-full rounded-lg border border-[#cbd5e1] px-3 py-2 text-sm"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div>
              <label className="block font-semibold text-[#475569] mb-1">Category</label>
              <select
                value={draft.category}
                onChange={(e) => setDraft({ ...draft, category: e.target.value as VehicleCategory })}
                className="w-full rounded-lg border border-[#cbd5e1] px-2.5 py-2 text-xs"
              >
                {['Economy', 'Sedan', 'SUV / 4x4', 'Pickup', 'Luxury', 'Van / Bus', 'Small Truck'].map(
                  (c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  )
                )}
              </select>
            </div>
            <div>
              <label className="block font-semibold text-[#475569] mb-1">Class Label</label>
              <input
                type="text"
                value={draft.fleetClass || ''}
                onChange={(e) => setDraft({ ...draft, fleetClass: e.target.value })}
                placeholder="e.g. Small Car · CX-5"
                className="w-full rounded-lg border border-[#cbd5e1] px-2.5 py-2 text-xs"
              />
            </div>
            <div>
              <label className="block font-semibold text-[#475569] mb-1">Model Intro / Year Note</label>
              <input
                type="text"
                value={draft.modelIntro || ''}
                onChange={(e) => setDraft({ ...draft, modelIntro: e.target.value })}
                placeholder="e.g. 2020Y model"
                className="w-full rounded-lg border border-[#cbd5e1] px-2.5 py-2 text-xs"
              />
            </div>
            <div>
              <label className="block font-semibold text-[#475569] mb-1">Status</label>
              <select
                value={draft.status}
                onChange={(e) =>
                  setDraft({ ...draft, status: e.target.value as HireVehicle['status'] })
                }
                className="w-full rounded-lg border border-[#cbd5e1] px-2.5 py-2 text-xs font-semibold"
              >
                <option value="Available">Available</option>
                <option value="Booked">Booked</option>
                <option value="Maintenance">Maintenance</option>
              </select>
            </div>
          </div>

          {/* Pricing Grid */}
          <div className="rounded-xl bg-[#f8fafc] border border-[#e2e8f0] p-4 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <p className="font-bold text-[#003087] uppercase tracking-wider text-[11px]">
                Pricing (ZMW — USD converts live at daily rate)
              </p>
              <label className="inline-flex items-center gap-1.5 font-semibold text-[#0f172a] cursor-pointer">
                <input
                  type="checkbox"
                  checked={allowCityExit}
                  onChange={(e) => setAllowCityExit(e.target.checked)}
                  className="accent-[#003087]"
                />
                <span>Allow City Exit Travel</span>
              </label>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 tabular-nums">
              <div>
                <label className="block text-[#475569] mb-1">Premium / Day</label>
                <input
                  type="number"
                  value={draft.premiumRateZmw || draft.dailyRateZmw}
                  onChange={(e) => {
                    const val = Number(e.target.value) || 0;
                    setDraft({ ...draft, premiumRateZmw: val, dailyRateZmw: val });
                  }}
                  className="w-full rounded-lg border border-[#cbd5e1] bg-white px-2.5 py-1.5 font-semibold"
                />
              </div>
              <div>
                <label className="block text-[#475569] mb-1">City Exit / Day</label>
                <input
                  type="number"
                  disabled={!allowCityExit}
                  value={allowCityExit ? draft.cityExitRateZmw || 0 : 0}
                  onChange={(e) =>
                    setDraft({ ...draft, cityExitRateZmw: Number(e.target.value) || 0 })
                  }
                  className="w-full rounded-lg border border-[#cbd5e1] bg-white disabled:opacity-50 px-2.5 py-1.5 font-semibold"
                />
              </div>
              <div>
                <label className="block text-[#475569] mb-1">Weekly (ZMW)</label>
                <input
                  type="number"
                  value={draft.weeklyRateZmw}
                  onChange={(e) =>
                    setDraft({ ...draft, weeklyRateZmw: Number(e.target.value) || 0 })
                  }
                  className="w-full rounded-lg border border-[#cbd5e1] bg-white px-2.5 py-1.5"
                />
              </div>
              <div>
                <label className="block text-[#475569] mb-1">Monthly (ZMW)</label>
                <input
                  type="number"
                  value={draft.monthlyRateZmw}
                  onChange={(e) =>
                    setDraft({ ...draft, monthlyRateZmw: Number(e.target.value) || 0 })
                  }
                  className="w-full rounded-lg border border-[#cbd5e1] bg-white px-2.5 py-1.5"
                />
              </div>
              <div>
                <label className="block text-[#475569] mb-1">Deposit (ZMW)</label>
                <input
                  type="number"
                  value={draft.depositZmw}
                  onChange={(e) =>
                    setDraft({ ...draft, depositZmw: Number(e.target.value) || 0 })
                  }
                  className="w-full rounded-lg border border-[#cbd5e1] bg-white px-2.5 py-1.5"
                />
              </div>
            </div>
          </div>

          {/* Specs Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-6 gap-3">
            <div>
              <label className="block font-semibold text-[#475569] mb-1">Year</label>
              <input
                type="number"
                value={draft.year}
                onChange={(e) => setDraft({ ...draft, year: Number(e.target.value) || 2020 })}
                className="w-full rounded-lg border border-[#cbd5e1] px-2.5 py-1.5 tabular-nums"
              />
            </div>
            <div>
              <label className="block font-semibold text-[#475569] mb-1">Transmission</label>
              <select
                value={draft.transmission}
                onChange={(e) =>
                  setDraft({ ...draft, transmission: e.target.value as HireVehicle['transmission'] })
                }
                className="w-full rounded-lg border border-[#cbd5e1] px-2 py-1.5"
              >
                <option value="Automatic">Automatic</option>
                <option value="Manual">Manual</option>
              </select>
            </div>
            <div>
              <label className="block font-semibold text-[#475569] mb-1">Fuel</label>
              <select
                value={draft.fuel}
                onChange={(e) => setDraft({ ...draft, fuel: e.target.value as HireVehicle['fuel'] })}
                className="w-full rounded-lg border border-[#cbd5e1] px-2 py-1.5"
              >
                <option value="Petrol">Petrol</option>
                <option value="Diesel">Diesel</option>
                <option value="Hybrid">Hybrid</option>
              </select>
            </div>
            <div>
              <label className="block font-semibold text-[#475569] mb-1">Seats</label>
              <input
                type="number"
                value={draft.seats}
                onChange={(e) => setDraft({ ...draft, seats: Number(e.target.value) || 5 })}
                className="w-full rounded-lg border border-[#cbd5e1] px-2.5 py-1.5 tabular-nums"
              />
            </div>
            <div>
              <label className="block font-semibold text-[#475569] mb-1">Bags</label>
              <input
                type="number"
                value={draft.bags}
                onChange={(e) => setDraft({ ...draft, bags: Number(e.target.value) || 3 })}
                className="w-full rounded-lg border border-[#cbd5e1] px-2.5 py-1.5 tabular-nums"
              />
            </div>
            <div>
              <label className="block font-semibold text-[#475569] mb-1">Engine</label>
              <input
                type="text"
                value={draft.engine}
                onChange={(e) => setDraft({ ...draft, engine: e.target.value })}
                className="w-full rounded-lg border border-[#cbd5e1] px-2.5 py-1.5"
              />
            </div>
          </div>

          <div className="flex flex-wrap gap-4 pt-1">
            {[
              { key: 'has4x4', label: '4×4 / AWD' },
              { key: 'hasAc', label: 'Air Conditioning' },
              { key: 'hasGps', label: 'GPS Ready' },
              { key: 'hasChildSeatOption', label: 'Child Seat' },
              { key: 'unlimitedMileage', label: 'Unlimited Mileage' },
            ].map((flag) => (
              <label key={flag.key} className="inline-flex items-center gap-1.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={Boolean(draft[flag.key as keyof HireVehicle])}
                  onChange={(e) => setDraft({ ...draft, [flag.key]: e.target.checked })}
                  className="accent-[#003087]"
                />
                <span>{flag.label}</span>
              </label>
            ))}
          </div>

          <div>
            <label className="block font-semibold text-[#475569] mb-1">
              Features (comma separated)
            </label>
            <input
              type="text"
              value={featuresText}
              onChange={(e) => setFeaturesText(e.target.value)}
              className="w-full rounded-lg border border-[#cbd5e1] px-3 py-2 text-xs"
            />
          </div>

          <div>
            <label className="block font-semibold text-[#475569] mb-1">Description</label>
            <textarea
              rows={2}
              value={draft.description}
              onChange={(e) => setDraft({ ...draft, description: e.target.value })}
              className="w-full rounded-lg border border-[#cbd5e1] px-3 py-2 text-xs"
            />
          </div>

          {/* Photo Manager */}
          <div className="rounded-xl border border-[#e2e8f0] p-4 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <p className="font-bold text-[#003087] uppercase tracking-wider text-[11px]">
                Vehicle Photos ({draft.photos.length})
              </p>
              <label className="inline-flex items-center gap-1.5 rounded-lg bg-[#eff6ff] border border-[#bfdbfe] px-3 py-1.5 text-xs font-semibold text-[#003087] cursor-pointer hover:border-[#003087]">
                <ImagePlus className="w-3.5 h-3.5" />
                <span>Upload PNG/JPG Cutout</span>
                <input type="file" accept="image/*" onChange={handleUploadFile} className="sr-only" />
              </label>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {draft.photos.map((p, idx) => (
                <div key={`${p.url}-${idx}`} className="rounded-lg border border-[#e2e8f0] p-2 bg-[#f8fafc] space-y-1.5">
                  <div className="aspect-[4/3] bg-white rounded overflow-hidden">
                    <VehicleImage src={p.url} alt={p.label} />
                  </div>
                  <p className="font-semibold text-[11px] truncate">{p.label}</p>
                  <div className="flex items-center justify-between gap-1">
                    {idx === 0 ? (
                      <span className="text-[10px] font-bold text-[#003087]">Primary Photo</span>
                    ) : (
                      <button
                        type="button"
                        onClick={() => setPrimaryPhoto(idx)}
                        className="text-[10px] font-semibold text-[#003087] hover:underline"
                      >
                        Set Primary
                      </button>
                    )}
                    {draft.photos.length > 1 && (
                      <button
                        type="button"
                        onClick={() => removePhoto(idx)}
                        className="text-[10px] font-semibold text-[#e11d48] hover:underline"
                      >
                        Remove
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-12 gap-2 pt-2 border-t border-[#f1f5f9]">
              <select
                value=""
                onChange={(e) => {
                  if (!e.target.value) return;
                  const preset = STUDIO_PRESET_PHOTOS.find((p) => p.url === e.target.value);
                  if (preset) {
                    setDraft((prev) => ({
                      ...prev,
                      photos: [{ url: preset.url, label: preset.label }, ...prev.photos],
                    }));
                  }
                }}
                className="sm:col-span-4 rounded-lg border border-[#cbd5e1] px-2.5 py-1.5 text-xs"
              >
                <option value="">+ Add Studio Preset Cutout...</option>
                {STUDIO_PRESET_PHOTOS.map((preset) => (
                  <option key={preset.label} value={preset.url}>
                    {preset.label}
                  </option>
                ))}
              </select>
              <input
                type="text"
                value={newPhotoUrl}
                onChange={(e) => setNewPhotoUrl(e.target.value)}
                placeholder="Or paste image URL..."
                className="sm:col-span-4 rounded-lg border border-[#cbd5e1] px-2.5 py-1.5 text-xs"
              />
              <input
                type="text"
                value={newPhotoLabel}
                onChange={(e) => setNewPhotoLabel(e.target.value)}
                placeholder="Label"
                className="sm:col-span-2 rounded-lg border border-[#cbd5e1] px-2.5 py-1.5 text-xs"
              />
              <button
                type="button"
                onClick={handleAddPhotoUrl}
                className="sm:col-span-2 rounded-lg bg-[#003087] text-white font-semibold px-3 py-1.5"
              >
                Add Photo
              </button>
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-2 border-t border-[#e2e8f0]">
            <button
              type="button"
              onClick={onClose}
              className="rounded-lg border border-[#cbd5e1] px-4 py-2 font-semibold text-[#475569]"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="rounded-lg bg-[#e11d48] hover:bg-[#be123c] text-white px-5 py-2 font-bold"
            >
              Save Vehicle Changes
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

const SaleVehicleEditorModal: React.FC<{
  vehicle: SaleVehicle;
  onSave: (updated: SaleVehicle) => void;
  onClose: () => void;
}> = ({ vehicle, onSave, onClose }) => {
  const [draft, setDraft] = useState<SaleVehicle>({ ...vehicle, photos: [...vehicle.photos] });
  const [featuresText, setFeaturesText] = useState(vehicle.features.join(', '));
  const [newPhotoUrl, setNewPhotoUrl] = useState('');

  const handleUploadFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const dataUrl = await readImageAsDataUrl(file);
      if (dataUrl) {
        setDraft((prev) => ({
          ...prev,
          photos: [{ url: dataUrl, label: file.name.replace(/\.[^.]+$/, '') || 'Uploaded Photo' }, ...prev.photos],
        }));
      }
    } catch {
      // Ignore invalid file read
    }
    e.target.value = '';
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanedFeatures = featuresText
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean);
    onSave({
      ...draft,
      features: cleanedFeatures.length > 0 ? cleanedFeatures : draft.features,
    });
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-3xl w-full max-h-[92vh] overflow-y-auto shadow-2xl border border-[#e2e8f0]">
        <div className="sticky top-0 z-10 bg-[#003087] text-white px-5 py-4 flex items-center justify-between">
          <div>
            <p className="text-[11px] uppercase tracking-wider text-[#fda4af] font-semibold">
              Edit Vehicle For Sale
            </p>
            <h2 className="text-lg font-semibold text-white">{draft.name || 'Sales Listing'}</h2>
          </div>
          <button type="button" onClick={onClose} className="p-1.5 rounded hover:bg-white/10">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 sm:p-6 space-y-5 text-xs">
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
            <div className="sm:col-span-2">
              <label className="block font-semibold text-[#475569] mb-1">Listing Title *</label>
              <input
                type="text"
                required
                value={draft.name}
                onChange={(e) => setDraft({ ...draft, name: e.target.value })}
                className="w-full rounded-lg border border-[#cbd5e1] px-3 py-2 text-sm"
              />
            </div>
            <div>
              <label className="block font-semibold text-[#475569] mb-1">Make</label>
              <input
                type="text"
                value={draft.make}
                onChange={(e) => setDraft({ ...draft, make: e.target.value })}
                className="w-full rounded-lg border border-[#cbd5e1] px-3 py-2 text-sm"
              />
            </div>
            <div>
              <label className="block font-semibold text-[#475569] mb-1">Model</label>
              <input
                type="text"
                value={draft.model}
                onChange={(e) => setDraft({ ...draft, model: e.target.value })}
                className="w-full rounded-lg border border-[#cbd5e1] px-3 py-2 text-sm"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 tabular-nums">
            <div>
              <label className="block font-semibold text-[#475569] mb-1">Price (ZMW)</label>
              <input
                type="number"
                value={draft.priceZmw}
                onChange={(e) => setDraft({ ...draft, priceZmw: Number(e.target.value) || 0 })}
                className="w-full rounded-lg border border-[#cbd5e1] px-2.5 py-2 font-bold text-[#e11d48]"
              />
            </div>
            <div>
              <label className="block font-semibold text-[#475569] mb-1">Year</label>
              <input
                type="number"
                value={draft.year}
                onChange={(e) => setDraft({ ...draft, year: Number(e.target.value) || 2020 })}
                className="w-full rounded-lg border border-[#cbd5e1] px-2.5 py-2"
              />
            </div>
            <div>
              <label className="block font-semibold text-[#475569] mb-1">Mileage (km)</label>
              <input
                type="number"
                value={draft.mileageKm}
                onChange={(e) => setDraft({ ...draft, mileageKm: Number(e.target.value) || 0 })}
                className="w-full rounded-lg border border-[#cbd5e1] px-2.5 py-2"
              />
            </div>
            <div>
              <label className="block font-semibold text-[#475569] mb-1">Status</label>
              <select
                value={draft.status}
                onChange={(e) =>
                  setDraft({ ...draft, status: e.target.value as SaleVehicle['status'] })
                }
                className="w-full rounded-lg border border-[#cbd5e1] px-2.5 py-2 font-semibold"
              >
                <option value="For Sale">For Sale</option>
                <option value="Reserved">Reserved</option>
                <option value="Sold">Sold</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div>
              <label className="block font-semibold text-[#475569] mb-1">Body Type</label>
              <select
                value={draft.bodyType}
                onChange={(e) =>
                  setDraft({ ...draft, bodyType: e.target.value as VehicleCategory })
                }
                className="w-full rounded-lg border border-[#cbd5e1] px-2.5 py-2"
              >
                {['Economy', 'Sedan', 'SUV / 4x4', 'Pickup', 'Luxury', 'Van / Bus'].map((b) => (
                  <option key={b} value={b}>
                    {b}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block font-semibold text-[#475569] mb-1">Fuel</label>
              <select
                value={draft.fuel}
                onChange={(e) => setDraft({ ...draft, fuel: e.target.value as SaleVehicle['fuel'] })}
                className="w-full rounded-lg border border-[#cbd5e1] px-2.5 py-2"
              >
                <option value="Diesel">Diesel</option>
                <option value="Petrol">Petrol</option>
              </select>
            </div>
            <div>
              <label className="block font-semibold text-[#475569] mb-1">Transmission</label>
              <select
                value={draft.transmission}
                onChange={(e) =>
                  setDraft({ ...draft, transmission: e.target.value as SaleVehicle['transmission'] })
                }
                className="w-full rounded-lg border border-[#cbd5e1] px-2.5 py-2"
              >
                <option value="Automatic">Automatic</option>
                <option value="Manual">Manual</option>
              </select>
            </div>
            <div>
              <label className="block font-semibold text-[#475569] mb-1">Condition</label>
              <select
                value={draft.condition}
                onChange={(e) =>
                  setDraft({ ...draft, condition: e.target.value as SaleVehicle['condition'] })
                }
                className="w-full rounded-lg border border-[#cbd5e1] px-2.5 py-2"
              >
                <option value="Fresh Japanese Import">Fresh Japanese Import</option>
                <option value="Certified Pre-Owned">Certified Pre-Owned</option>
                <option value="Zambian Used">Zambian Used</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block font-semibold text-[#475569] mb-1">Engine</label>
              <input
                type="text"
                value={draft.engine}
                onChange={(e) => setDraft({ ...draft, engine: e.target.value })}
                className="w-full rounded-lg border border-[#cbd5e1] px-2.5 py-2"
              />
            </div>
            <div>
              <label className="block font-semibold text-[#475569] mb-1">Warranty</label>
              <input
                type="text"
                value={draft.warranty}
                onChange={(e) => setDraft({ ...draft, warranty: e.target.value })}
                className="w-full rounded-lg border border-[#cbd5e1] px-2.5 py-2"
              />
            </div>
            <div className="flex items-end pb-2">
              <label className="inline-flex items-center gap-2 font-semibold text-[#003087] cursor-pointer">
                <input
                  type="checkbox"
                  checked={Boolean(draft.featured)}
                  onChange={(e) => setDraft({ ...draft, featured: e.target.checked })}
                  className="accent-[#003087]"
                />
                <span>Featured on Homepage</span>
              </label>
            </div>
          </div>

          <div>
            <label className="block font-semibold text-[#475569] mb-1">Condition Summary</label>
            <textarea
              rows={2}
              value={draft.conditionSummary}
              onChange={(e) => setDraft({ ...draft, conditionSummary: e.target.value })}
              className="w-full rounded-lg border border-[#cbd5e1] px-3 py-2"
            />
          </div>

          <div>
            <label className="block font-semibold text-[#475569] mb-1">
              Features (comma separated)
            </label>
            <input
              type="text"
              value={featuresText}
              onChange={(e) => setFeaturesText(e.target.value)}
              className="w-full rounded-lg border border-[#cbd5e1] px-3 py-2"
            />
          </div>

          <div className="rounded-xl border border-[#e2e8f0] p-4 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <p className="font-bold text-[#003087] uppercase tracking-wider text-[11px]">
                Listing Photos ({draft.photos.length})
              </p>
              <label className="inline-flex items-center gap-1.5 rounded-lg bg-[#eff6ff] border border-[#bfdbfe] px-3 py-1.5 text-xs font-semibold text-[#003087] cursor-pointer">
                <ImagePlus className="w-3.5 h-3.5" />
                <span>Upload Photo</span>
                <input type="file" accept="image/*" onChange={handleUploadFile} className="sr-only" />
              </label>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {draft.photos.map((p, idx) => (
                <div key={`${p.url}-${idx}`} className="rounded-lg border border-[#e2e8f0] p-2 bg-[#f8fafc] space-y-1">
                  <div className="aspect-[4/3] bg-white rounded overflow-hidden">
                    <VehicleImage src={p.url} alt={p.label} />
                  </div>
                  <div className="flex items-center justify-between">
                    {idx === 0 ? (
                      <span className="text-[10px] font-bold text-[#003087]">Main</span>
                    ) : (
                      <button
                        type="button"
                        onClick={() => {
                          const copy = [...draft.photos];
                          const [chosen] = copy.splice(idx, 1);
                          setDraft({ ...draft, photos: [chosen, ...copy] });
                        }}
                        className="text-[10px] font-semibold text-[#003087] hover:underline"
                      >
                        Set Main
                      </button>
                    )}
                    {draft.photos.length > 1 && (
                      <button
                        type="button"
                        onClick={() =>
                          setDraft({
                            ...draft,
                            photos: draft.photos.filter((_, i) => i !== idx),
                          })
                        }
                        className="text-[10px] font-semibold text-[#e11d48] hover:underline"
                      >
                        Remove
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>

            <div className="flex flex-wrap gap-2 pt-2 border-t border-[#f1f5f9]">
              <input
                type="text"
                value={newPhotoUrl}
                onChange={(e) => setNewPhotoUrl(e.target.value)}
                placeholder="Paste studio image URL..."
                className="flex-1 min-w-[180px] rounded-lg border border-[#cbd5e1] px-2.5 py-1.5"
              />
              <button
                type="button"
                onClick={() => {
                  if (!newPhotoUrl.trim()) return;
                  setDraft({
                    ...draft,
                    photos: [{ url: newPhotoUrl.trim(), label: 'Custom View' }, ...draft.photos],
                  });
                  setNewPhotoUrl('');
                }}
                className="rounded-lg bg-[#003087] text-white font-semibold px-3 py-1.5"
              >
                Add Photo URL
              </button>
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-2 border-t border-[#e2e8f0]">
            <button
              type="button"
              onClick={onClose}
              className="rounded-lg border border-[#cbd5e1] px-4 py-2 font-semibold text-[#475569]"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="rounded-lg bg-[#e11d48] hover:bg-[#be123c] text-white px-5 py-2 font-bold"
            >
              Save Sales Listing
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

/* ---------------- ADMIN DASHBOARD ---------------- */

export interface AdminAuthProps {
  authenticated: boolean;
  passwordConfigured: boolean;
  authLoading: boolean;
  onSetupPassword: (password: string, idToken?: string) => Promise<string | null>;
  onLoginPassword: (password: string, idToken?: string) => Promise<string | null>;
  onVerifyGoogleAdmin: (idToken: string) => Promise<string | null>;
  onLogout: () => Promise<void>;
  onChangePassword: (currentPassword: string, newPassword: string) => Promise<string | null>;
}

export const AdminDashboardView: React.FC<{
  hireFleet: HireVehicle[];
  salesInventory: SaleVehicle[];
  bookings: CustomerBooking[];
  sellerLeads: SellCarSubmission[];
  currency: CurrencyMode;
  zmwPerUsd: number;
  adminAuth: AdminAuthProps;
  onUpdateExchangeRate: (rate: number, source: 'live' | 'admin') => void;
  onSyncLiveRate: () => Promise<number | null>;
  onUpdateHireVehicle: (id: string, patch: Partial<HireVehicle>) => void;
  onAddHireVehicle: (v: HireVehicle) => void;
  onDeleteHireVehicle: (id: string) => void;
  onUpdateSaleVehicle: (id: string, patch: Partial<SaleVehicle>) => void;
  onAddSaleVehicle: (v: SaleVehicle) => void;
  onDeleteSaleVehicle: (id: string) => void;
  onResetFleetDefaults: () => void;
  onUpdateBookingStatus: (id: string, status: CustomerBooking['status']) => void;
  onUpdateBookingPaymentStatus: (
    id: string,
    paymentStatus: NonNullable<CustomerBooking['paymentStatus']>
  ) => void;
  onDeleteBooking: (id: string) => void;
}> = ({
  hireFleet,
  salesInventory,
  bookings,
  sellerLeads,
  currency,
  zmwPerUsd,
  adminAuth,
  onUpdateExchangeRate,
  onSyncLiveRate,
  onUpdateHireVehicle,
  onAddHireVehicle,
  onDeleteHireVehicle,
  onUpdateSaleVehicle,
  onAddSaleVehicle,
  onDeleteSaleVehicle,
  onResetFleetDefaults,
  onUpdateBookingStatus,
  onUpdateBookingPaymentStatus,
  onDeleteBooking,
}) => {
  const { t } = useI18n();
  const [tab, setTab] = useState<'hire' | 'sales' | 'bookings' | 'sellers' | 'emailTemplate'>('hire');
  const [copiedBlock, setCopiedBlock] = useState<'css' | 'html' | null>(null);
  const [passwordInput, setPasswordInput] = useState('');
  const [confirmPasswordInput, setConfirmPasswordInput] = useState('');
  const [authError, setAuthError] = useState('');
  const [authSubmitting, setAuthSubmitting] = useState(false);

  const [showChangePassword, setShowChangePassword] = useState(false);
  const [currentPwdDraft, setCurrentPwdDraft] = useState('');
  const [newPwdDraft, setNewPwdDraft] = useState('');
  const [confirmNewPwdDraft, setConfirmNewPwdDraft] = useState('');
  const [changePwdError, setChangePwdError] = useState('');
  const [changePwdBusy, setChangePwdBusy] = useState(false);

  const [newHireName, setNewHireName] = useState('');
  const [newHireCat, setNewHireCat] = useState<VehicleCategory>('Economy');
  const [newHireRate, setNewHireRate] = useState(1800);

  const [newSaleName, setNewSaleName] = useState('');
  const [newSaleMake, setNewSaleMake] = useState('Mazda');
  const [newSaleYear, setNewSaleYear] = useState(2019);
  const [newSalePrice, setNewSalePrice] = useState(335000);

  const [editingHire, setEditingHire] = useState<HireVehicle | null>(null);
  const [editingSale, setEditingSale] = useState<SaleVehicle | null>(null);
  const [contractBooking, setContractBooking] = useState<CustomerBooking | null>(null);

  const [rateDraft, setRateDraft] = useState(zmwPerUsd.toFixed(2));
  const [syncingFx, setSyncingFx] = useState(false);

  React.useEffect(() => {
    setRateDraft(zmwPerUsd.toFixed(2));
  }, [zmwPerUsd]);

  const fxMeta = getFxMetadata();

  const handleQuickAddHire = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newHireName.trim()) return;
    const presetPhoto =
      newHireCat === 'Economy'
        ? IMG_STUDIO_CX5
        : newHireCat === 'Sedan'
        ? IMG_STUDIO_SEDAN
        : newHireCat === 'Pickup'
        ? IMG_STUDIO_HILUX
        : newHireCat === 'Van / Bus'
        ? IMG_STUDIO_ALPHARD
        : newHireCat === 'Small Truck'
        ? IMG_STUDIO_TRUCK
        : IMG_STUDIO_PRADO;

    onAddHireVehicle({
      id: `hire-custom-${Date.now()}`,
      name: newHireName.trim(),
      brand: newHireName.split(' ')[0] || 'Toyota',
      year: 2021,
      category: newHireCat,
      fleetClass: newHireCat === 'Economy' ? 'Small Car' : newHireCat,
      transmission: 'Automatic',
      fuel: newHireCat === 'Economy' || newHireCat === 'Sedan' ? 'Petrol' : 'Diesel',
      seats: 5,
      bags: 4,
      dailyRateZmw: newHireRate,
      basicRateZmw: Math.max(650, newHireRate - 200),
      premiumRateZmw: newHireRate,
      cityExitRateZmw: newHireRate + 500,
      weeklyRateZmw: newHireRate * 6,
      monthlyRateZmw: newHireRate * 22,
      depositZmw: 3500,
      engine: '2.0L / 2.4L',
      mileagePolicy: 'Within City 120 km/day · City Exit 180 km/day',
      locations: ZAMBIA_LOCATIONS,
      features: ['A/C', 'Studio Inspected', 'Bluetooth', 'Reverse Camera'],
      has4x4: newHireCat === 'SUV / 4x4' || newHireCat === 'Pickup',
      hasGps: true,
      hasAc: true,
      hasChildSeatOption: true,
      unlimitedMileage: true,
      status: 'Available',
      bookedDates: [],
      photos: [
        { url: presetPhoto, label: 'Studio Cutout' },
        { url: IMG_INTERIOR, label: 'Interior' },
      ],
      description: 'Newly added Zamto Africa fleet unit ready for Lusaka and upcountry hire.',
    });
    setNewHireName('');
  };

  const handleQuickAddSale = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSaleName.trim()) return;
    onAddSaleVehicle({
      id: `sale-custom-${Date.now()}`,
      name: `${newSaleYear} ${newSaleMake} ${newSaleName.trim()}`,
      make: newSaleMake,
      model: newSaleName.trim(),
      year: newSaleYear,
      bodyType: 'Economy',
      priceZmw: newSalePrice,
      mileageKm: 58000,
      engine: '2.0L Skyactiv',
      fuel: 'Petrol',
      transmission: 'Automatic',
      color: 'Pearl Metallic',
      location: ZAMBIA_LOCATIONS[0],
      condition: 'Fresh Japanese Import',
      status: 'For Sale',
      importOrigin: 'Japan (ZRA Cleared)',
      warranty: '3 Months Dealer Warranty',
      serviceHistory: 'Full workshop service completed in Lusaka.',
      conditionSummary: 'Clean inspected import ready for immediate delivery.',
      features: ['Air Conditioning', 'Reverse Camera', 'Alloy Wheels', 'ABS'],
      photos: [
        { url: IMG_STUDIO_CX5, label: 'Studio Cutout' },
        { url: IMG_INTERIOR, label: 'Interior' },
        { url: IMG_STUDIO_SEDAN, label: 'Profile' },
      ],
    });
    setNewSaleName('');
  };

  const handleApplyFx = (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = Number(rateDraft);
    if (parsed >= 5 && parsed <= 100) {
      onUpdateExchangeRate(parsed, 'admin');
    }
  };

  const handleLiveSyncClick = async () => {
    setSyncingFx(true);
    await onSyncLiveRate();
    setSyncingFx(false);
  };

  const handleAdminAuthSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    if (!adminAuth.passwordConfigured) {
      if (passwordInput.length < 8) {
        setAuthError('Please choose a password of at least 8 characters.');
        return;
      }
      if (passwordInput !== confirmPasswordInput) {
        setAuthError('Passwords do not match.');
        return;
      }
      setAuthSubmitting(true);
      const err = await adminAuth.onSetupPassword(passwordInput);
      setAuthSubmitting(false);
      if (err) {
        setAuthError(err);
      } else {
        setPasswordInput('');
        setConfirmPasswordInput('');
      }
      return;
    }

    if (!passwordInput) {
      setAuthError('Enter your admin password.');
      return;
    }
    setAuthSubmitting(true);
    const err = await adminAuth.onLoginPassword(passwordInput);
    setAuthSubmitting(false);
    if (err) {
      setAuthError(err);
    } else {
      setPasswordInput('');
    }
  };

  const handleGoogleAdminSignIn = async () => {
    setAuthError('');
    setAuthSubmitting(true);
    try {
      const cred = await signInWithPopup(auth, googleAuthProvider);
      const idToken = await cred.user.getIdToken();
      const err = await adminAuth.onVerifyGoogleAdmin(idToken);
      if (err) setAuthError(err);
    } catch {
      setAuthError('Google sign-in was cancelled or could not be completed.');
    } finally {
      setAuthSubmitting(false);
    }
  };

  const handleChangePasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setChangePwdError('');
    if (newPwdDraft.length < 8) {
      setChangePwdError('New password must be at least 8 characters.');
      return;
    }
    if (newPwdDraft !== confirmNewPwdDraft) {
      setChangePwdError('New passwords do not match.');
      return;
    }
    setChangePwdBusy(true);
    const err = await adminAuth.onChangePassword(currentPwdDraft, newPwdDraft);
    setChangePwdBusy(false);
    if (err) {
      setChangePwdError(err);
    } else {
      setCurrentPwdDraft('');
      setNewPwdDraft('');
      setConfirmNewPwdDraft('');
      setShowChangePassword(false);
    }
  };

  if (!adminAuth.authenticated) {
    return (
      <div className="max-w-md mx-auto px-4 py-14 sm:py-20">
        <div className="rounded-2xl bg-white border border-[#e2e8f0] shadow-sm p-6 sm:p-8 space-y-5">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-[#eff6ff] border border-[#bfdbfe] flex items-center justify-center shrink-0">
              <Lock className="w-5 h-5 text-[#003087]" />
            </div>
            <div>
              <p className="text-[11px] font-bold uppercase tracking-wider text-[#e11d48]">
                Zamto Africa Operations
              </p>
              <h1 className="text-xl font-bold text-[#003087]">
                {adminAuth.passwordConfigured ? 'Admin Password Required' : 'Set Up Admin Password'}
              </h1>
            </div>
          </div>

          <p className="text-xs text-[#475569] leading-relaxed">
            {adminAuth.passwordConfigured
              ? 'Enter the backend admin password to edit hire vehicles, sales stock, daily FX rates, and customer bookings.'
              : 'Create an admin password (minimum 8 characters) to lock fleet, pricing, and booking controls. All edits persist across sessions and devices.'}
          </p>

          {adminAuth.authLoading ? (
            <p className="text-xs font-medium text-[#64748b]">Checking session...</p>
          ) : (
            <form onSubmit={handleAdminAuthSubmit} className="space-y-3.5">
              <div>
                <label className="block text-xs font-semibold text-[#334155] mb-1">
                  {adminAuth.passwordConfigured ? 'Admin Password' : 'New Admin Password (8+ chars)'}
                </label>
                <input
                  type="password"
                  required
                  value={passwordInput}
                  onChange={(e) => setPasswordInput(e.target.value)}
                  placeholder="Enter admin password"
                  autoComplete={adminAuth.passwordConfigured ? 'current-password' : 'new-password'}
                  className="w-full rounded-lg border border-[#cbd5e1] bg-[#f8fafc] focus:bg-white focus:border-[#003087] focus:outline-none px-3.5 py-2.5 text-sm"
                />
              </div>

              {!adminAuth.passwordConfigured && (
                <div>
                  <label className="block text-xs font-semibold text-[#334155] mb-1">
                    Confirm Admin Password
                  </label>
                  <input
                    type="password"
                    required
                    value={confirmPasswordInput}
                    onChange={(e) => setConfirmPasswordInput(e.target.value)}
                    placeholder="Re-enter password"
                    autoComplete="new-password"
                    className="w-full rounded-lg border border-[#cbd5e1] bg-[#f8fafc] focus:bg-white focus:border-[#003087] focus:outline-none px-3.5 py-2.5 text-sm"
                  />
                </div>
              )}

              {authError && (
                <p className="text-xs font-semibold text-[#be123c] bg-[#fff1f2] border border-[#fecdd3] rounded-lg px-3 py-2">
                  {authError}
                </p>
              )}

              <button
                type="submit"
                disabled={authSubmitting}
                className="w-full rounded-lg bg-[#003087] hover:bg-[#002266] disabled:opacity-55 text-white text-sm font-semibold py-2.5 px-4 transition-colors"
              >
                {authSubmitting
                  ? 'Verifying...'
                  : adminAuth.passwordConfigured
                  ? 'Unlock Admin Dashboard'
                  : 'Save Password & Unlock'}
              </button>

              {adminAuth.passwordConfigured && (
                <button
                  type="button"
                  onClick={handleGoogleAdminSignIn}
                  disabled={authSubmitting}
                  className="w-full rounded-lg border border-[#cbd5e1] hover:border-[#003087] bg-white text-[#0f172a] text-xs font-semibold py-2.5 px-4 transition-colors"
                >
                  Sign in with Authorized Google Account
                </button>
              )}
            </form>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-10 sm:py-14 space-y-8">
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.16em] text-[#e11d48] mb-1">
            {t.admin.kicker}
          </p>
          <h1 className="text-3xl font-semibold text-[#003087]">{t.admin.title}</h1>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#003087] bg-[#eff6ff] px-3 py-1.5 rounded-lg">
            <ShieldCheck className="w-4 h-4" />
            {t.admin.savedBadge}
          </span>
          <button
            type="button"
            onClick={() => setShowChangePassword((v) => !v)}
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#003087] hover:bg-[#eff6ff] border border-[#bfdbfe] bg-white px-3 py-1.5 rounded-lg"
          >
            <KeyRound className="w-3.5 h-3.5" />
            <span>Change Password</span>
          </button>
          <button
            type="button"
            onClick={onResetFleetDefaults}
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#475569] hover:text-[#e11d48] border border-[#cbd5e1] bg-white px-3 py-1.5 rounded-lg"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            {t.admin.resetDefaultsBtn}
          </button>
          <button
            type="button"
            onClick={() => void adminAuth.onLogout()}
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#be123c] hover:bg-[#fff1f2] border border-[#fecdd3] bg-white px-3 py-1.5 rounded-lg"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Lock Admin</span>
          </button>
        </div>
      </div>

      {showChangePassword && (
        <form
          onSubmit={handleChangePasswordSubmit}
          className="rounded-2xl bg-white border border-[#bfdbfe] p-4 sm:p-5 space-y-3"
        >
          <div className="flex items-center justify-between">
            <p className="text-xs font-bold uppercase tracking-wider text-[#003087]">
              Update Backend Admin Password
            </p>
            <button
              type="button"
              onClick={() => setShowChangePassword(false)}
              className="text-xs font-semibold text-[#64748b] hover:text-[#0f172a]"
            >
              Close
            </button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs">
            <input
              type="password"
              required
              value={currentPwdDraft}
              onChange={(e) => setCurrentPwdDraft(e.target.value)}
              placeholder="Current password"
              className="rounded-lg border border-[#cbd5e1] px-3 py-2"
            />
            <input
              type="password"
              required
              value={newPwdDraft}
              onChange={(e) => setNewPwdDraft(e.target.value)}
              placeholder="New password (8+ chars)"
              className="rounded-lg border border-[#cbd5e1] px-3 py-2"
            />
            <input
              type="password"
              required
              value={confirmNewPwdDraft}
              onChange={(e) => setConfirmNewPwdDraft(e.target.value)}
              placeholder="Confirm new password"
              className="rounded-lg border border-[#cbd5e1] px-3 py-2"
            />
            <button
              type="submit"
              disabled={changePwdBusy}
              className="rounded-lg bg-[#003087] hover:bg-[#002266] disabled:opacity-55 text-white font-semibold px-4 py-2"
            >
              {changePwdBusy ? 'Saving...' : 'Save New Password'}
            </button>
          </div>
          {changePwdError && (
            <p className="text-xs font-semibold text-[#be123c]">{changePwdError}</p>
          )}
        </form>
      )}

      {/* Live Daily USD / ZMW Rate Bar */}
      <form
        onSubmit={handleApplyFx}
        className="rounded-2xl bg-white border border-[#e2e8f0] p-4 sm:p-5 flex flex-col md:flex-row md:items-center justify-between gap-4"
      >
        <div>
          <p className="text-xs font-bold uppercase tracking-wider text-[#003087]">
            {t.admin.fxTitle}
          </p>
          <p className="text-xs text-[#64748b] mt-0.5 tabular-nums">
            Active Rate: <strong>1 USD = ZMW {zmwPerUsd.toFixed(2)}</strong> · Source: {fxMeta.source}
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <div className="inline-flex items-center gap-1.5 rounded-lg border border-[#cbd5e1] bg-[#f8fafc] px-2.5 py-1.5 text-xs">
            <span className="font-semibold text-[#475569]">1 USD = ZMW</span>
            <input
              type="number"
              step="0.01"
              min="5"
              max="99"
              value={rateDraft}
              onChange={(e) => setRateDraft(e.target.value)}
              className="w-20 bg-white border border-[#cbd5e1] rounded px-2 py-1 font-bold text-[#003087] tabular-nums"
            />
          </div>
          <button
            type="submit"
            className="rounded-lg bg-[#003087] hover:bg-[#002266] text-white text-xs font-semibold px-3.5 py-2"
          >
            {t.admin.setDailyRateBtn}
          </button>
          <button
            type="button"
            onClick={handleLiveSyncClick}
            disabled={syncingFx}
            className="rounded-lg border border-[#003087] text-[#003087] hover:bg-[#eff6ff] text-xs font-semibold px-3.5 py-2 inline-flex items-center gap-1.5 disabled:opacity-60"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${syncingFx ? 'animate-spin' : ''}`} />
            <span>{syncingFx ? t.admin.syncingBtn : t.admin.syncRateBtn}</span>
          </button>
        </div>
      </form>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 tabular-nums">
        {[
          { label: t.admin.kpis.hireUnits, value: hireFleet.length },
          {
            label: t.admin.kpis.salesStock,
            value: salesInventory.filter((s) => s.status === 'For Sale').length,
          },
          { label: t.admin.kpis.customerBookings, value: bookings.length },
          { label: t.admin.kpis.sellerLeads, value: sellerLeads.length },
        ].map((kpi) => (
          <div key={kpi.label} className="rounded-xl bg-white border border-[#e2e8f0] p-4">
            <p className="text-xs text-[#64748b]">{kpi.label}</p>
            <p className="text-2xl font-bold text-[#003087] mt-1">{kpi.value}</p>
          </div>
        ))}
      </div>

      <div className="flex flex-wrap gap-2">
        {(
          [
            { id: 'hire', label: `${t.admin.tabs.hire} (${hireFleet.length})` },
            { id: 'sales', label: `${t.admin.tabs.sales} (${salesInventory.length})` },
            { id: 'bookings', label: `${t.admin.tabs.bookings} (${bookings.length})` },
            { id: 'sellers', label: `${t.admin.tabs.sellers} (${sellerLeads.length})` },
            { id: 'emailTemplate', label: 'Resend Template & CSS' },
          ] as const
        ).map((item) => (
          <button
            key={item.id}
            type="button"
            onClick={() => setTab(item.id)}
            className={`rounded-lg px-4 py-2 text-xs sm:text-sm font-semibold inline-flex items-center gap-1.5 ${
              tab === item.id
                ? 'bg-[#003087] text-white'
                : 'bg-white border border-[#cbd5e1] text-[#475569]'
            }`}
          >
            {item.id === 'emailTemplate' && <Mail className="w-3.5 h-3.5" />}
            {item.label}
          </button>
        ))}
      </div>

      {tab === 'hire' && (
        <div className="space-y-6">
          <form
            onSubmit={handleQuickAddHire}
            className="rounded-2xl bg-white border border-[#e2e8f0] p-5 grid grid-cols-1 sm:grid-cols-4 gap-3 items-end"
          >
            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold mb-1">Add Hire Vehicle Model *</label>
              <input
                type="text"
                required
                value={newHireName}
                onChange={(e) => setNewHireName(e.target.value)}
                placeholder="e.g. Mazda CX-5 GT / Toyota Fortuner"
                className="w-full rounded-lg border border-[#cbd5e1] px-3 py-2 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold mb-1">Category</label>
              <select
                value={newHireCat}
                onChange={(e) => setNewHireCat(e.target.value as VehicleCategory)}
                className="w-full rounded-lg border border-[#cbd5e1] px-3 py-2 text-sm"
              >
                {['Economy', 'Sedan', 'SUV / 4x4', 'Pickup', 'Luxury', 'Van / Bus', 'Small Truck'].map(
                  (c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  )
                )}
              </select>
            </div>
            <div className="flex gap-2 items-end">
              <div className="flex-1">
                <label className="block text-xs font-semibold mb-1">Premium ZMW</label>
                <input
                  type="number"
                  value={newHireRate}
                  onChange={(e) => setNewHireRate(Number(e.target.value))}
                  className="w-full rounded-lg border border-[#cbd5e1] px-3 py-2 text-sm tabular-nums"
                />
              </div>
              <button
                type="submit"
                className="rounded-lg bg-[#003087] text-white px-4 py-2 text-xs font-semibold inline-flex items-center gap-1 h-[38px]"
              >
                <PlusCircle className="w-4 h-4" /> Add
              </button>
            </div>
          </form>

          <div className="rounded-2xl bg-white border border-[#e2e8f0] overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#f1f5f9] text-[#475569] uppercase">
                <tr>
                  <th className="py-3 px-4">Photo</th>
                  <th className="py-3 px-4">Vehicle</th>
                  <th className="py-3 px-4">Class / Category</th>
                  <th className="py-3 px-4">Premium (ZMW)</th>
                  <th className="py-3 px-4">City Exit (ZMW)</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#f1f5f9] tabular-nums">
                {hireFleet.map((car) => (
                  <tr key={car.id}>
                    <td className="py-2 px-4">
                      <div className="w-16 h-12 rounded border border-[#e2e8f0] overflow-hidden bg-white">
                        <VehicleImage src={car.photos[0]?.url} alt={car.name} />
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <p className="font-semibold text-[#0f172a]">{car.name}</p>
                      <p className="text-[11px] text-[#64748b]">
                        {car.year} · {car.transmission} · {car.seats} seats
                      </p>
                    </td>
                    <td className="py-3 px-4">{car.fleetClass || car.category}</td>
                    <td className="py-3 px-4">
                      <input
                        type="number"
                        value={car.premiumRateZmw || car.dailyRateZmw}
                        onChange={(e) => {
                          const val = Number(e.target.value) || 0;
                          onUpdateHireVehicle(car.id, {
                            dailyRateZmw: val,
                            premiumRateZmw: val,
                          });
                        }}
                        className="w-24 rounded border border-[#cbd5e1] px-2 py-1 text-xs font-semibold"
                      />
                    </td>
                    <td className="py-3 px-4">
                      {car.cityExitRateZmw ? formatMoney(car.cityExitRateZmw, currency) : 'Within Lusaka'}
                    </td>
                    <td className="py-3 px-4">
                      <select
                        value={car.status}
                        onChange={(e) =>
                          onUpdateHireVehicle(car.id, {
                            status: e.target.value as HireVehicle['status'],
                          })
                        }
                        className="rounded border border-[#cbd5e1] px-2 py-1 text-xs font-semibold"
                      >
                        <option value="Available">Available</option>
                        <option value="Booked">Booked</option>
                        <option value="Maintenance">Maintenance</option>
                      </select>
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => setEditingHire(car)}
                          className="rounded-lg bg-[#eff6ff] border border-[#bfdbfe] hover:border-[#003087] px-2.5 py-1.5 text-xs font-semibold text-[#003087] inline-flex items-center gap-1 whitespace-nowrap"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                          <span>Edit Details</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => onDeleteHireVehicle(car.id)}
                          aria-label={`Delete ${car.name}`}
                          className="rounded-lg border border-[#fecdd3] hover:bg-[#fff1f2] p-1.5 text-[#be123c]"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {tab === 'sales' && (
        <div className="space-y-6">
          <form
            onSubmit={handleQuickAddSale}
            className="rounded-2xl bg-white border border-[#e2e8f0] p-5 grid grid-cols-1 sm:grid-cols-4 gap-3 items-end"
          >
            <div>
              <label className="block text-xs font-semibold mb-1">Make</label>
              <input
                type="text"
                value={newSaleMake}
                onChange={(e) => setNewSaleMake(e.target.value)}
                className="w-full rounded-lg border border-[#cbd5e1] px-3 py-2 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold mb-1">Model *</label>
              <input
                type="text"
                required
                value={newSaleName}
                onChange={(e) => setNewSaleName(e.target.value)}
                placeholder="e.g. CX-5 / Hilux Revo"
                className="w-full rounded-lg border border-[#cbd5e1] px-3 py-2 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold mb-1">Year</label>
              <input
                type="number"
                value={newSaleYear}
                onChange={(e) => setNewSaleYear(Number(e.target.value))}
                className="w-full rounded-lg border border-[#cbd5e1] px-3 py-2 text-sm tabular-nums"
              />
            </div>
            <div className="flex gap-2 items-end">
              <div className="flex-1">
                <label className="block text-xs font-semibold mb-1">Price (ZMW)</label>
                <input
                  type="number"
                  value={newSalePrice}
                  onChange={(e) => setNewSalePrice(Number(e.target.value))}
                  className="w-full rounded-lg border border-[#cbd5e1] px-3 py-2 text-sm tabular-nums"
                />
              </div>
              <button
                type="submit"
                className="rounded-lg bg-[#003087] text-white px-4 py-2 text-xs font-semibold inline-flex items-center gap-1 h-[38px]"
              >
                <Car className="w-4 h-4" /> List
              </button>
            </div>
          </form>

          <div className="rounded-2xl bg-white border border-[#e2e8f0] overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#f1f5f9] text-[#475569] uppercase">
                <tr>
                  <th className="py-3 px-4">Photo</th>
                  <th className="py-3 px-4">Vehicle</th>
                  <th className="py-3 px-4">Mileage</th>
                  <th className="py-3 px-4">Price (ZMW)</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#f1f5f9] tabular-nums">
                {salesInventory.map((car) => (
                  <tr key={car.id}>
                    <td className="py-2 px-4">
                      <div className="w-16 h-12 rounded border border-[#e2e8f0] overflow-hidden bg-white">
                        <VehicleImage src={car.photos[0]?.url} alt={car.name} />
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <p className="font-semibold text-[#0f172a]">{car.name}</p>
                      <p className="text-[11px] text-[#64748b]">{car.condition}</p>
                    </td>
                    <td className="py-3 px-4">{car.mileageKm.toLocaleString('en-US')} km</td>
                    <td className="py-3 px-4">
                      <input
                        type="number"
                        value={car.priceZmw}
                        onChange={(e) =>
                          onUpdateSaleVehicle(car.id, {
                            priceZmw: Number(e.target.value) || 0,
                          })
                        }
                        className="w-28 rounded border border-[#cbd5e1] px-2 py-1 text-xs font-semibold"
                      />
                    </td>
                    <td className="py-3 px-4">
                      <select
                        value={car.status}
                        onChange={(e) =>
                          onUpdateSaleVehicle(car.id, {
                            status: e.target.value as SaleVehicle['status'],
                          })
                        }
                        className="rounded border border-[#cbd5e1] px-2 py-1 text-xs font-semibold"
                      >
                        <option value="For Sale">For Sale</option>
                        <option value="Reserved">Reserved</option>
                        <option value="Sold">Sold</option>
                      </select>
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => setEditingSale(car)}
                          className="rounded-lg bg-[#eff6ff] border border-[#bfdbfe] hover:border-[#003087] px-2.5 py-1.5 text-xs font-semibold text-[#003087] inline-flex items-center gap-1 whitespace-nowrap"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                          <span>Edit Details</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => onDeleteSaleVehicle(car.id)}
                          aria-label={`Delete ${car.name}`}
                          className="rounded-lg border border-[#fecdd3] hover:bg-[#fff1f2] p-1.5 text-[#be123c]"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {tab === 'bookings' && (
        <div className="rounded-2xl bg-white border border-[#e2e8f0] overflow-x-auto">
          {bookings.length === 0 ? (
            <p className="p-8 text-sm text-[#64748b]">No bookings submitted yet.</p>
          ) : (
            <table className="w-full text-left text-xs">
              <thead className="bg-[#f1f5f9] text-[#475569] uppercase">
                <tr>
                  <th className="py-3 px-4">Ref</th>
                  <th className="py-3 px-4">Vehicle</th>
                  <th className="py-3 px-4">Customer</th>
                  <th className="py-3 px-4">Total &amp; Payment</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4">Contract</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#f1f5f9] tabular-nums">
                {bookings.map((b) => (
                  <tr key={b.id}>
                    <td className="py-3 px-4 font-mono font-bold text-[#e11d48]">{b.id}</td>
                    <td className="py-3 px-4 font-semibold">
                      {b.vehicleName}
                      <span className="block text-[11px] font-normal text-[#64748b]">
                        {b.type} · {b.startDate}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      {b.customerName}
                      <span className="block text-[11px] text-[#64748b]">{b.customerPhone}</span>
                    </td>
                    <td className="py-3 px-4 space-y-1">
                      <span className="font-semibold block">{formatDualUsdFirst(b.totalZmw)}</span>
                      <select
                        value={
                          b.paymentStatus === 'Pending Desk Payment'
                            ? 'Pending Online Verification'
                            : b.paymentStatus || 'Pending Online Verification'
                        }
                        onChange={(e) =>
                          onUpdateBookingPaymentStatus(
                            b.id,
                            e.target.value as NonNullable<CustomerBooking['paymentStatus']>
                          )
                        }
                        className="rounded border border-[#cbd5e1] px-2 py-1 text-[11px]"
                      >
                        <option value="Paid">Paid</option>
                        <option value="Deposit Paid">Deposit Paid</option>
                        <option value="Pending Online Verification">Pending Online Verification</option>
                      </select>
                    </td>
                    <td className="py-3 px-4">
                      <select
                        value={b.status}
                        onChange={(e) =>
                          onUpdateBookingStatus(
                            b.id,
                            e.target.value as CustomerBooking['status']
                          )
                        }
                        className="rounded border border-[#cbd5e1] px-2 py-1 text-xs"
                      >
                        <option value="Confirmed">Confirmed</option>
                        <option value="Pending Verification">Pending Verification</option>
                        <option value="Cancelled">Cancelled</option>
                      </select>
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-1.5">
                        {b.type === 'Car Hire' && (
                          <button
                            type="button"
                            onClick={() => setContractBooking(b)}
                            className="rounded border border-[#bfdbfe] bg-[#eff6ff] px-2.5 py-1 text-[11px] font-semibold text-[#003087]"
                          >
                            Agreement
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={() => onDeleteBooking(b.id)}
                          className="rounded border border-[#fecdd3] p-1 text-[#be123c] hover:bg-[#fff1f2]"
                          aria-label={`Remove ${b.id}`}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      )}

      {tab === 'sellers' && (
        <div className="rounded-2xl bg-white border border-[#e2e8f0] overflow-x-auto">
          {sellerLeads.length === 0 ? (
            <p className="p-8 text-sm text-[#64748b]">
              No trade-in or private seller listings submitted yet.
            </p>
          ) : (
            <table className="w-full text-left text-xs tabular-nums">
              <thead className="bg-[#f1f5f9] text-[#475569] uppercase">
                <tr>
                  <th className="py-3 px-4">ID</th>
                  <th className="py-3 px-4">Seller</th>
                  <th className="py-3 px-4">Vehicle</th>
                  <th className="py-3 px-4">City</th>
                  <th className="py-3 px-4">Asking Price</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#f1f5f9]">
                {sellerLeads.map((lead) => (
                  <tr key={lead.id}>
                    <td className="py-3 px-4 font-mono font-bold text-[#e11d48]">{lead.id}</td>
                    <td className="py-3 px-4">
                      {lead.name} ({lead.sellerType}) · {lead.phone}
                    </td>
                    <td className="py-3 px-4 font-semibold">
                      {lead.year} {lead.makeModel} ({lead.mileageKm.toLocaleString('en-US')} km)
                    </td>
                    <td className="py-3 px-4">{lead.city}</td>
                    <td className="py-3 px-4 font-semibold">
                      {formatMoney(lead.askingPriceZmw, currency)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      )}

      {tab === 'emailTemplate' && (() => {
        const origin =
          typeof window !== 'undefined' ? window.location.origin : 'https://zamtoafrica.com';
        const previewHtml = buildBrandedResendEmailHtml({
          logoUrl: `${origin}${ZAMTO_BRAND_LOGO_PATH}`,
          siteUrl: origin,
          kind: 'Car Hire Booking',
          reference: 'ZAMTO-8842A1',
          headline: 'Car Hire Booking Confirmation',
          introText:
            'Thank you for choosing Zamto Africa Company Limited. Below is the official record for your booking and Lusaka dispatch reference.',
          rows: [
            { label: 'Submission Type', value: 'Car Hire Booking' },
            { label: 'Reference', value: 'ZAMTO-8842A1' },
            { label: 'Client Name', value: 'Chanda Mwansa' },
            { label: 'Phone / WhatsApp', value: '+260 977 123 456' },
            { label: 'Client Email', value: 'chanda@example.zm' },
            { label: 'Vehicle / Topic', value: 'Toyota Land Cruiser Prado TX-L (Self Drive)' },
            { label: 'Pickup / Location', value: 'Kenneth Kaunda International Airport (KKIA)' },
            { label: 'Drop-off', value: 'Rhodes Park Head Office, Lusaka' },
            { label: 'Dates', value: '2026-12-01 to 2026-12-05 (4 days)' },
          ],
          totalDisplay: '$480.00 (ZMW 9,893 · 16% VAT Included)',
          paymentSummary: 'Paid Online via Lenco Zambia (MTN Mobile Money)',
          notes: 'Flight arrives 14:20 — please meet at KKIA Arrivals Gate.',
          whatsappUrl: buildWhatsAppUrl('Hello Zamto Africa, checking booking ZAMTO-8842A1'),
        });
        const dashboardHtmlTemplate = buildResendDashboardHtmlTemplate(origin);

        const copyToClipboard = async (mode: 'css' | 'html', content: string) => {
          try {
            await navigator.clipboard.writeText(content);
            setCopiedBlock(mode);
            window.setTimeout(() => setCopiedBlock((curr) => (curr === mode ? null : curr)), 2500);
          } catch {
            // Clipboard permission denied
          }
        };

        return (
          <div className="space-y-6">
            <div className="rounded-2xl bg-white border border-[#e2e8f0] p-5 sm:p-6 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
              <div>
                <p className="text-xs font-bold uppercase tracking-wider text-[#e11d48]">
                  Resend Email &amp; Form Template
                </p>
                <h2 className="text-xl font-semibold text-[#003087] mt-0.5">
                  Branded Zamto Africa Global CSS + Logo Template
                </h2>
                <p className="text-xs text-[#475569] mt-1 max-w-2xl">
                  Automatically applied to every booking, seller submission, and contact alert sent via Resend. You can also copy the Global CSS or full HTML template below for your Resend dashboard.
                </p>
              </div>
              <div className="flex flex-wrap items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => void copyToClipboard('css', RESEND_GLOBAL_CSS)}
                  className="inline-flex items-center gap-1.5 rounded-lg border border-[#003087] text-[#003087] hover:bg-[#eff6ff] text-xs font-semibold px-3.5 py-2"
                >
                  {copiedBlock === 'css' ? (
                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                  ) : (
                    <Copy className="w-3.5 h-3.5" />
                  )}
                  <span>{copiedBlock === 'css' ? 'Global CSS Copied' : 'Copy Global CSS'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => void copyToClipboard('html', dashboardHtmlTemplate)}
                  className="inline-flex items-center gap-1.5 rounded-lg bg-[#e11d48] hover:bg-[#be123c] text-white text-xs font-semibold px-3.5 py-2"
                >
                  {copiedBlock === 'html' ? (
                    <Check className="w-3.5 h-3.5" />
                  ) : (
                    <Copy className="w-3.5 h-3.5" />
                  )}
                  <span>
                    {copiedBlock === 'html' ? 'HTML Template Copied' : 'Copy Full HTML Template'}
                  </span>
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
              <div className="xl:col-span-7 rounded-2xl bg-white border border-[#e2e8f0] overflow-hidden">
                <div className="px-4 py-3 bg-[#f8fafc] border-b border-[#e2e8f0] flex items-center justify-between gap-2">
                  <span className="text-xs font-bold uppercase tracking-wider text-[#003087]">
                    Live Email Preview (with Official Logo)
                  </span>
                  <a
                    href="/api/resend-template-preview"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-[11px] font-semibold text-[#003087] hover:text-[#e11d48] underline"
                  >
                    Open Full Preview
                  </a>
                </div>
                <iframe
                  title="Zamto Africa Resend Email Preview"
                  srcDoc={previewHtml}
                  className="w-full h-[640px] border-0 bg-[#f1f5f9]"
                />
              </div>

              <div className="xl:col-span-5 rounded-2xl bg-white border border-[#e2e8f0] overflow-hidden">
                <div className="px-4 py-3 bg-[#f8fafc] border-b border-[#e2e8f0] flex items-center justify-between">
                  <span className="text-xs font-bold uppercase tracking-wider text-[#003087]">
                    Global CSS Stylesheet
                  </span>
                  <button
                    type="button"
                    onClick={() => void copyToClipboard('css', RESEND_GLOBAL_CSS)}
                    className="text-xs font-semibold text-[#e11d48] hover:underline"
                  >
                    {copiedBlock === 'css' ? 'Copied' : 'Copy CSS'}
                  </button>
                </div>
                <pre className="p-4 text-[11px] leading-relaxed font-mono text-[#0f172a] bg-[#f8fafc] overflow-x-auto max-h-[640px] overflow-y-auto">
                  {RESEND_GLOBAL_CSS}
                </pre>
              </div>
            </div>
          </div>
        );
      })()}

      {editingHire && (
        <HireVehicleEditorModal
          vehicle={editingHire}
          onSave={(updated) => {
            onUpdateHireVehicle(updated.id, updated);
            setEditingHire(null);
          }}
          onClose={() => setEditingHire(null)}
        />
      )}

      {editingSale && (
        <SaleVehicleEditorModal
          vehicle={editingSale}
          onSave={(updated) => {
            onUpdateSaleVehicle(updated.id, updated);
            setEditingSale(null);
          }}
          onClose={() => setEditingSale(null)}
        />
      )}

      {contractBooking && (
        <SignedRentalContractModal
          booking={contractBooking}
          currency={currency}
          onClose={() => setContractBooking(null)}
        />
      )}
    </div>
  );
};
