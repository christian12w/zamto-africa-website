import React from 'react';
import type { LanguageCode } from '../types';

export interface LanguageOptionMeta {
  code: LanguageCode;
  short: string;
  nativeName: string;
  englishName: string;
}

export const INTERNATIONAL_LANGUAGES: LanguageOptionMeta[] = [
  { code: 'en', short: 'EN', nativeName: 'English', englishName: 'English' },
  { code: 'zh', short: '中文', nativeName: '中文 (简体)', englishName: 'Chinese' },
  { code: 'fr', short: 'FR', nativeName: 'Français', englishName: 'French' },
  { code: 'pt', short: 'PT', nativeName: 'Português', englishName: 'Portuguese' },
  { code: 'es', short: 'ES', nativeName: 'Español', englishName: 'Spanish' },
  { code: 'de', short: 'DE', nativeName: 'Deutsch', englishName: 'German' },
  { code: 'ja', short: 'JA', nativeName: '日本語', englishName: 'Japanese' },
];

export const FlagIcon: React.FC<{ code: LanguageCode; className?: string }> = ({
  code,
  className = 'w-4 h-3',
}) => {
  switch (code) {
    case 'en':
      return (
        <svg viewBox="0 0 24 16" className={`${className} rounded-[2px] border border-black/15 shrink-0`} aria-hidden="true">
          <rect width="24" height="16" fill="#012169" />
          <path d="M0 0L24 16M24 0L0 16" stroke="#ffffff" strokeWidth="3" />
          <path d="M0 0L24 16M24 0L0 16" stroke="#C8102E" strokeWidth="1.4" />
          <path d="M12 0V16M0 8H24" stroke="#ffffff" strokeWidth="4.6" />
          <path d="M12 0V16M0 8H24" stroke="#C8102E" strokeWidth="2.6" />
        </svg>
      );
    case 'zh':
      return (
        <svg viewBox="0 0 24 16" className={`${className} rounded-[2px] border border-black/15 shrink-0`} aria-hidden="true">
          <rect width="24" height="16" fill="#DE2910" />
          <polygon points="4.5,2.2 5.2,4.3 7.4,4.3 5.6,5.6 6.3,7.7 4.5,6.4 2.7,7.7 3.4,5.6 1.6,4.3 3.8,4.3" fill="#FFDE00" />
          <circle cx="9.2" cy="2.3" r="0.65" fill="#FFDE00" />
          <circle cx="10.4" cy="3.8" r="0.65" fill="#FFDE00" />
          <circle cx="10.4" cy="5.7" r="0.65" fill="#FFDE00" />
          <circle cx="9.2" cy="7.1" r="0.65" fill="#FFDE00" />
        </svg>
      );
    case 'fr':
      return (
        <svg viewBox="0 0 24 16" className={`${className} rounded-[2px] border border-black/15 shrink-0`} aria-hidden="true">
          <rect width="8" height="16" x="0" fill="#0055A4" />
          <rect width="8" height="16" x="8" fill="#FFFFFF" />
          <rect width="8" height="16" x="16" fill="#EF4135" />
        </svg>
      );
    case 'pt':
      return (
        <svg viewBox="0 0 24 16" className={`${className} rounded-[2px] border border-black/15 shrink-0`} aria-hidden="true">
          <rect width="9.5" height="16" x="0" fill="#006600" />
          <rect width="14.5" height="16" x="9.5" fill="#FF0000" />
          <circle cx="9.5" cy="8" r="3.1" fill="#FFCC00" />
          <circle cx="9.5" cy="8" r="1.9" fill="#FFFFFF" />
        </svg>
      );
    case 'es':
      return (
        <svg viewBox="0 0 24 16" className={`${className} rounded-[2px] border border-black/15 shrink-0`} aria-hidden="true">
          <rect width="24" height="4" y="0" fill="#AA151B" />
          <rect width="24" height="8" y="4" fill="#F1BF00" />
          <rect width="24" height="4" y="12" fill="#AA151B" />
          <rect width="2.2" height="3.2" x="5.4" y="6.4" rx="0.5" fill="#AA151B" />
        </svg>
      );
    case 'de':
      return (
        <svg viewBox="0 0 24 16" className={`${className} rounded-[2px] border border-black/15 shrink-0`} aria-hidden="true">
          <rect width="24" height="5.34" y="0" fill="#000000" />
          <rect width="24" height="5.34" y="5.33" fill="#DD0000" />
          <rect width="24" height="5.34" y="10.66" fill="#FFCE00" />
        </svg>
      );
    case 'ja':
      return (
        <svg viewBox="0 0 24 16" className={`${className} rounded-[2px] border border-black/15 shrink-0`} aria-hidden="true">
          <rect width="24" height="16" fill="#FFFFFF" />
          <circle cx="12" cy="8" r="4.3" fill="#BC002D" />
        </svg>
      );
  }
};
