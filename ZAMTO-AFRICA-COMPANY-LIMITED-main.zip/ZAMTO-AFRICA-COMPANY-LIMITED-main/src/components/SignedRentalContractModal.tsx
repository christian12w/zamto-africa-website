import React from 'react';
import {
  CheckCircle2,
  Download,
  FileText,
  Printer,
  ShieldCheck,
  X,
} from 'lucide-react';
import type { CurrencyMode, CustomerBooking } from '../types';
import {
  COMPANY_LEGAL_NAME,
  HEAD_OFFICE_ADDRESS,
  RENTAL_AGREEMENT_PDF,
  SUPPORT_EMAIL,
  SUPPORT_PHONE_DISPLAY,
  ZAMTO_LOGO_URL,
  calcIncludedZambiaVat,
  formatDualUsdFirst,
} from '../utils/format';

interface SignedRentalContractModalProps {
  booking: CustomerBooking;
  currency: CurrencyMode;
  onClose: () => void;
}

export const SignedRentalContractModal: React.FC<SignedRentalContractModalProps> = ({
  booking,
  onClose,
}) => {
  const signedTimestamp = booking.contractSignedAt || booking.createdAt;
  const formattedSignedDate = new Date(signedTimestamp).toLocaleString('en-ZM', {
    dateStyle: 'medium',
    timeStyle: 'short',
  });
  const includedVatZmw =
    booking.vatAmountZmw && booking.vatAmountZmw > 0
      ? booking.vatAmountZmw
      : calcIncludedZambiaVat(booking.totalZmw);

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/65 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 overflow-y-auto print:static print:bg-white print:p-0">
      <div className="bg-white rounded-2xl max-w-3xl w-full max-h-[92vh] overflow-y-auto shadow-2xl border border-[#e2e8f0] print:max-h-none print:shadow-none print:border-0">
        {/* Top Modal Action Bar */}
        <div className="sticky top-0 z-10 bg-[#003087] text-white px-5 py-4 flex flex-wrap items-center justify-between gap-3 print:static print:bg-[#003087]">
          <div className="flex items-center gap-3">
            <img
              src={ZAMTO_LOGO_URL}
              alt="Zamto Africa"
              className="h-10 w-auto object-contain bg-white rounded-lg px-2 py-1 shrink-0"
            />
            <div>
              <p className="text-[11px] font-semibold uppercase tracking-wider text-[#fda4af]">
                {COMPANY_LEGAL_NAME} · Contract Record
              </p>
              <h2 className="text-lg sm:text-xl font-semibold text-white">
                Signed Rental Agreement — {booking.id}
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-2 print:hidden">
            <button
              type="button"
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 rounded-lg bg-white text-[#003087] hover:bg-[#eff6ff] text-xs font-bold px-3 py-2"
            >
              <Printer className="w-4 h-4" />
              <span>Print / Save PDF</span>
            </button>
            <a
              href={RENTAL_AGREEMENT_PDF}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 rounded-lg bg-[#e11d48] hover:bg-[#be123c] text-white text-xs font-bold px-3 py-2"
            >
              <Download className="w-4 h-4" />
              <span>Full Blank PDF</span>
            </a>
            <button
              type="button"
              onClick={onClose}
              aria-label="Close signed agreement"
              className="p-2 rounded-lg hover:bg-white/10"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div className="p-5 sm:p-7 space-y-6 text-xs text-[#334155]">
          {/* Header Status Strip */}
          <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl bg-[#f8fafc] border border-[#cbd5e1] p-4">
            <div className="space-y-1">
              <p className="font-bold text-[#003087] text-sm">{COMPANY_LEGAL_NAME}</p>
              <p className="text-[#475569]">{HEAD_OFFICE_ADDRESS}</p>
              <p className="text-[#475569]">
                Tel: {SUPPORT_PHONE_DISPLAY} · Email: {SUPPORT_EMAIL}
              </p>
            </div>
            <div className="text-left sm:text-right space-y-1 tabular-nums">
              <p className="font-mono font-bold text-[#e11d48] text-sm">{booking.id}</p>
              <p className="font-semibold text-[#003087]">
                {booking.paymentStatus || 'Confirmed'}
                {booking.paymentTransactionRef ? ` · ${booking.paymentTransactionRef}` : ''}
              </p>
              <p className="text-[11px] text-[#64748b]">Executed: {formattedSignedDate}</p>
            </div>
          </div>

          {/* Parties & Driver Credentials */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="rounded-xl border border-[#e2e8f0] p-4 space-y-2">
              <h3 className="text-xs font-bold uppercase tracking-wider text-[#003087]">
                Renter &amp; Identification
              </h3>
              <div className="space-y-1">
                <p>
                  <span className="text-[#64748b]">Contract Type:</span>{' '}
                  <strong className="text-[#0f172a]">
                    {booking.hireKind || 'Personal'} Hire
                    {booking.companyName ? ` (${booking.companyName})` : ''}
                  </strong>
                </p>
                <p>
                  <span className="text-[#64748b]">Full Name:</span>{' '}
                  <strong className="text-[#0f172a]">{booking.customerName}</strong>
                </p>
                <p>
                  <span className="text-[#64748b]">NRC / Passport No:</span>{' '}
                  <strong className="text-[#0f172a]">{booking.nrcOrPassport || 'Verify at handover'}</strong>
                </p>
                <p>
                  <span className="text-[#64748b]">Date of Birth:</span>{' '}
                  <strong className="text-[#0f172a]">{booking.dateOfBirth || '22+ Verified'}</strong>
                </p>
                <p>
                  <span className="text-[#64748b]">Licence No / Issue:</span>{' '}
                  <strong className="text-[#0f172a]">
                    {booking.licenceNumber || 'Present original'}
                    {booking.licenceIssueDate ? ` (Issued ${booking.licenceIssueDate})` : ''}
                  </strong>
                </p>
                <p>
                  <span className="text-[#64748b]">Address / Stay:</span>{' '}
                  <strong className="text-[#0f172a]">{booking.physicalAddress || 'Lusaka'}</strong>
                </p>
                <p>
                  <span className="text-[#64748b]">Phone / Email:</span>{' '}
                  <strong className="text-[#0f172a]">
                    {booking.customerPhone} · {booking.customerEmail}
                  </strong>
                </p>
              </div>
            </div>

            <div className="rounded-xl border border-[#e2e8f0] p-4 space-y-2">
              <h3 className="text-xs font-bold uppercase tracking-wider text-[#003087]">
                Vehicle, Scope &amp; Financial Terms
              </h3>
              <div className="space-y-1 tabular-nums">
                <p>
                  <span className="text-[#64748b]">Vehicle:</span>{' '}
                  <strong className="text-[#0f172a]">{booking.vehicleName}</strong>
                </p>
                <p>
                  <span className="text-[#64748b]">Package &amp; Insurance:</span>{' '}
                  <strong className="text-[#0f172a]">
                    {booking.packageTier || 'Premium'} ({booking.packageTier === 'Basic' ? 'Option A Base' : 'Option B Inclusive'})
                  </strong>
                </p>
                <p>
                  <span className="text-[#64748b]">Authorised Area:</span>{' '}
                  <strong className="text-[#0f172a]">
                    {booking.tripZone || 'Within City'} (
                    {booking.tripZone === 'Outside City'
                      ? '180 km/day · K20/km excess'
                      : '120 km/day · K15/km excess'}
                    )
                  </strong>
                </p>
                <p>
                  <span className="text-[#64748b]">Rental Period:</span>{' '}
                  <strong className="text-[#0f172a]">
                    {booking.startDate} to {booking.endDate || booking.startDate}
                  </strong>
                </p>
                <p>
                  <span className="text-[#64748b]">Pickup / Return:</span>{' '}
                  <strong className="text-[#0f172a]">
                    {booking.pickupLocation || 'Rhodes Park HQ'} →{' '}
                    {booking.dropoffLocation || booking.pickupLocation || 'Rhodes Park HQ'}
                  </strong>
                </p>
                <p>
                  <span className="text-[#64748b]">Total Contract Value (16% VAT Incl.):</span>{' '}
                  <strong className="text-[#e11d48]">{formatDualUsdFirst(booking.totalZmw)}</strong>{' '}
                  <span className="text-[#64748b]">
                    (incl. 16% VAT {formatDualUsdFirst(includedVatZmw)})
                  </span>
                </p>
                <p>
                  <span className="text-[#64748b]">Payment Settled:</span>{' '}
                  <strong className="text-[#003087]">
                    {booking.paidAmountZmw
                      ? `${formatDualUsdFirst(booking.paidAmountZmw)} via ${booking.paymentMethod}`
                      : `Pending online (${booking.paymentMethod})`}
                  </strong>
                </p>
              </div>
            </div>
          </div>

          {booking.addons && booking.addons.length > 0 && (
            <div className="rounded-xl border border-[#e2e8f0] p-4">
              <p className="font-bold text-[#003087] mb-1.5 uppercase tracking-wider text-[11px]">
                Selected Add-ons &amp; Driver Provisions
              </p>
              <p className="text-[#334155]">{booking.addons.join(' · ')}</p>
            </div>
          )}

          {/* Statutory Clauses & Handover Checklist */}
          <div className="rounded-xl border border-[#e2e8f0] p-4 space-y-2.5 bg-[#f8fafc]">
            <h3 className="text-xs font-bold uppercase tracking-wider text-[#003087] flex items-center gap-1.5">
              <FileText className="w-4 h-4 text-[#e11d48]" />
              <span>Executed Agreement Summary &amp; Handover Checklist</span>
            </h3>
            <ul className="list-disc pl-5 space-y-1 leading-relaxed text-[#475569]">
              <li>
                Governed by the Laws of the Republic of Zambia (Companies Act No. 10 of 2017).
              </li>
              <li>
                Renter &amp; any operator must hold a valid licence (2+ years) and be 22+ years old,
                or operate with a Zamto Assigned Driver (+K150/day).
              </li>
              <li>
                No unauthorised repairs or alterations without Rhodes Park office approval (ZMW
                500.00 minimum penalty). Report accidents or theft immediately to{' '}
                <strong>{SUPPORT_PHONE_DISPLAY}</strong> and Zambia Police.
              </li>
              <li>
                Joint Physical Handover Inspection completed at delivery covering: Bodywork &amp;
                Glass · Tyres &amp; Spare Wheel · Fuel Level · Jack &amp; Warning Triangle · First
                Aid Kit · Odometer Reading.
              </li>
            </ul>
          </div>

          {/* Electronic Signature Verification */}
          <div className="rounded-xl border border-[#bfdbfe] bg-[#eff6ff] p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-start gap-2.5">
              <CheckCircle2 className="w-5 h-5 text-[#003087] shrink-0 mt-0.5" />
              <div>
                <p className="font-bold text-[#003087]">
                  Digitally Executed by {booking.customerName}
                </p>
                <p className="text-[11px] text-[#475569]">
                  Accepted terms electronically on {formattedSignedDate} · Docs on file:{' '}
                  {booking.licenceFileName || 'Verify at handover'} /{' '}
                  {booking.residenceFileName || 'Verify at handover'}
                </p>
              </div>
            </div>
            <div className="inline-flex items-center gap-1.5 text-[11px] font-semibold text-[#003087] whitespace-nowrap">
              <ShieldCheck className="w-4 h-4 text-[#e11d48]" />
              <span>Countersigned: Zamto Africa Dispatch</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
