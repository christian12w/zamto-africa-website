import React, { useEffect, useRef, useState } from 'react';
import {
  CalendarCheck,
  Car,
  ChevronDown,
  Facebook,
  FileText,
  Home,
  Instagram,
  MessageCircle,
  Phone,
  Search,
  ShieldCheck,
  ShoppingBag,
  Video,
} from 'lucide-react';
import type { CurrencyMode, LanguageCode, PageRoute } from '../types';
import { useI18n } from '../i18n/I18nContext';
import { FlagIcon, INTERNATIONAL_LANGUAGES } from './FlagIcon';
import { PWAInstallButton } from './PWAInstallBanner';
import {
  buildWhatsAppUrl,
  COMPANY_LEGAL_NAME,
  getZmwPerUsd,
  HEAD_OFFICE_ADDRESS,
  RENTAL_AGREEMENT_PDF,
  SOCIAL_LINKS,
  SUPPORT_EMAIL,
  SUPPORT_PHONE_DISPLAY,
  ZAMTO_LOGO_URL,
} from '../utils/format';

interface HeaderFooterProps {
  route: PageRoute;
  onNavigate: (route: PageRoute) => void;
  currency: CurrencyMode;
  onCurrencyChange: (c: CurrencyMode) => void;
  lang: LanguageCode;
  onLangChange: (l: LanguageCode) => void;
  bookingCount: number;
  compareCount: number;
  onOpenCompare: () => void;
  onOpenSellTab: () => void;
}

export const SiteHeader: React.FC<HeaderFooterProps> = ({
  route,
  onNavigate,
  currency,
  onCurrencyChange,
  lang,
  onLangChange,
  bookingCount,
  compareCount,
  onOpenCompare,
  onOpenSellTab,
}) => {
  const { t } = useI18n();
  const [langMenuOpen, setLangMenuOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const onDocClick = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setLangMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', onDocClick);
    return () => document.removeEventListener('mousedown', onDocClick);
  }, []);

  const activeLangMeta =
    INTERNATIONAL_LANGUAGES.find((item) => item.code === lang) || INTERNATIONAL_LANGUAGES[0];

  const primaryNav: { route: PageRoute; label: string }[] = [
    { route: 'home', label: t.nav.home },
    { route: 'hire', label: t.nav.hire },
    { route: 'sales', label: t.nav.sales },
    { route: 'locations', label: t.nav.locations },
    { route: 'services', label: t.nav.services },
  ];

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur border-b border-[#e2e8f0]">
      {/* Strict 3-zone top bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-8">
        {/* Zone 1: Official Zamto Africa Logo */}
        <button
          type="button"
          onClick={() => onNavigate('home')}
          aria-label="Zamto Africa Home"
          className="text-left whitespace-nowrap shrink-0 flex items-center focus:outline-none"
        >
          <img
            src={ZAMTO_LOGO_URL}
            alt="Zamto Africa"
            className="h-11 sm:h-12 w-auto object-contain"
          />
        </button>

        {/* Zone 2: 5 Concise Single-Line Nav Links */}
        <nav className="hidden md:flex items-center gap-7" aria-label="Primary navigation">
          {primaryNav.map((item) => {
            const active = route === item.route;
            return (
              <button
                key={item.route}
                type="button"
                onClick={() => onNavigate(item.route)}
                className={`whitespace-nowrap shrink-0 text-sm font-semibold transition-colors pb-1 border-b-2 ${
                  active
                    ? 'text-[#003087] border-[#e11d48]'
                    : 'text-[#475569] border-transparent hover:text-[#003087]'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: Single Primary Action */}
        <div className="shrink-0">
          <button
            type="button"
            onClick={() => onNavigate('bookings')}
            className="whitespace-nowrap shrink-0 inline-flex items-center gap-2 rounded-lg bg-[#003087] hover:bg-[#002266] text-white text-sm font-semibold px-4 py-2 transition-colors"
          >
            <CalendarCheck className="w-4 h-4 text-[#fda4af]" />
            <span>{t.nav.bookings}</span>
            {bookingCount > 0 && (
              <span className="tabular-nums bg-[#e11d48] text-white text-xs font-bold px-1.5 py-0.5 rounded">
                {bookingCount}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* Compact Utility Bar: Secondary Links, Socials, Currency & Professional Flag Language Selector */}
      <div className="bg-[#f1f5f9] border-t border-[#e2e8f0]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-1.5 flex items-center justify-between gap-3 text-xs text-[#475569]">
          <div className="flex items-center gap-3.5 overflow-x-auto no-scrollbar">
            <button
              type="button"
              onClick={onOpenSellTab}
              className="whitespace-nowrap shrink-0 font-medium hover:text-[#003087] transition-colors"
            >
              {t.nav.sellCar}
            </button>
            <button
              type="button"
              onClick={() => onNavigate('about')}
              className={`whitespace-nowrap shrink-0 hover:text-[#003087] ${
                route === 'about' ? 'font-semibold text-[#003087]' : ''
              }`}
            >
              {t.nav.about}
            </button>
            <button
              type="button"
              onClick={() => onNavigate('faq')}
              className={`whitespace-nowrap shrink-0 hover:text-[#003087] ${
                route === 'faq' ? 'font-semibold text-[#003087]' : ''
              }`}
            >
              {t.nav.faq}
            </button>
            <button
              type="button"
              onClick={() => onNavigate('blog')}
              className={`whitespace-nowrap shrink-0 hover:text-[#003087] ${
                route === 'blog' ? 'font-semibold text-[#003087]' : ''
              }`}
            >
              {t.nav.tips}
            </button>
            <button
              type="button"
              onClick={() => onNavigate('contact')}
              className={`whitespace-nowrap shrink-0 hover:text-[#003087] ${
                route === 'contact' ? 'font-semibold text-[#003087]' : ''
              }`}
            >
              {t.nav.contact}
            </button>
            <button
              type="button"
              onClick={() => onNavigate('admin')}
              className={`whitespace-nowrap shrink-0 hover:text-[#003087] ${
                route === 'admin' ? 'font-semibold text-[#003087]' : ''
              }`}
            >
              {t.nav.admin}
            </button>
          </div>

          <div className="flex items-center gap-2.5 ml-auto shrink-0">
            <PWAInstallButton variant="compact" />
            {compareCount > 0 && (
              <button
                type="button"
                onClick={onOpenCompare}
                className="whitespace-nowrap shrink-0 font-semibold text-[#003087] hover:text-[#e11d48] underline underline-offset-2"
              >
                {t.nav.compare} ({compareCount}/3)
              </button>
            )}

            {/* Direct Social Links */}
            <div className="hidden sm:flex items-center gap-2 border-r border-[#cbd5e1] pr-2.5">
              <a
                href={SOCIAL_LINKS.facebook}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Zamto Africa on Facebook"
                title="Facebook"
                className="text-[#003087] hover:text-[#e11d48] transition-colors inline-flex items-center gap-1 font-medium"
              >
                <Facebook className="w-3.5 h-3.5" />
                <span className="hidden 2xl:inline">Facebook</span>
              </a>
              <a
                href={SOCIAL_LINKS.instagram}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Zamto Africa on Instagram"
                title="Instagram"
                className="text-[#003087] hover:text-[#e11d48] transition-colors inline-flex items-center gap-1 font-medium"
              >
                <Instagram className="w-3.5 h-3.5" />
                <span className="hidden 2xl:inline">Instagram</span>
              </a>
              <a
                href={SOCIAL_LINKS.tiktok}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Zamto Africa on TikTok"
                title="TikTok"
                className="text-[#003087] hover:text-[#e11d48] transition-colors inline-flex items-center gap-1 font-medium"
              >
                <Video className="w-3.5 h-3.5" />
                <span className="hidden 2xl:inline">TikTok</span>
              </a>
            </div>

            {/* Currency Toggle */}
            <div className="inline-flex items-center rounded-md border border-[#cbd5e1] bg-white p-0.5">
              {(['USD', 'ZMW'] as CurrencyMode[]).map((mode) => (
                <button
                  key={mode}
                  type="button"
                  onClick={() => onCurrencyChange(mode)}
                  className={`px-2 py-0.5 rounded text-[11px] font-semibold transition-colors whitespace-nowrap ${
                    currency === mode
                      ? 'bg-[#003087] text-white'
                      : 'text-[#475569] hover:bg-[#f1f5f9]'
                  }`}
                >
                  {mode}
                </button>
              ))}
            </div>

            {/* Desktop Horizontal Flag Language Selection Bar */}
            <div
              className="hidden lg:inline-flex items-center gap-0.5 rounded-md border border-[#cbd5e1] bg-white p-0.5 shadow-2xs"
              role="group"
              aria-label={t.nav.languageLabel}
            >
              {INTERNATIONAL_LANGUAGES.map((item) => {
                const active = lang === item.code;
                return (
                  <button
                    key={item.code}
                    type="button"
                    onClick={() => onLangChange(item.code)}
                    title={`${item.nativeName} (${item.englishName})`}
                    aria-pressed={active}
                    className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-[11px] font-semibold transition-colors whitespace-nowrap shrink-0 ${
                      active
                        ? 'bg-[#003087] text-white shadow-2xs'
                        : 'text-[#475569] hover:bg-[#f1f5f9] hover:text-[#003087]'
                    }`}
                  >
                    <FlagIcon code={item.code} className="w-3.5 h-2.5" />
                    <span>{item.short}</span>
                  </button>
                );
              })}
            </div>

            {/* Mobile & Tablet Flag Dropdown Selector */}
            <div className="relative lg:hidden" ref={dropdownRef}>
              <button
                type="button"
                onClick={() => setLangMenuOpen((open) => !open)}
                aria-expanded={langMenuOpen}
                aria-label={t.nav.languageLabel}
                className="inline-flex items-center gap-1.5 rounded-md border border-[#cbd5e1] bg-white px-2.5 py-1 text-[11px] font-semibold text-[#003087] hover:border-[#003087] whitespace-nowrap shrink-0"
              >
                <FlagIcon code={activeLangMeta.code} className="w-4 h-2.5" />
                <span>{activeLangMeta.short}</span>
                <ChevronDown className="w-3.5 h-3.5 text-[#64748b]" />
              </button>

              {langMenuOpen && (
                <div className="absolute right-0 mt-1.5 w-48 rounded-xl bg-white border border-[#cbd5e1] shadow-xl py-1.5 z-50">
                  {INTERNATIONAL_LANGUAGES.map((item) => {
                    const active = lang === item.code;
                    return (
                      <button
                        key={item.code}
                        type="button"
                        onClick={() => {
                          onLangChange(item.code);
                          setLangMenuOpen(false);
                        }}
                        className={`w-full px-3 py-2 text-left text-xs flex items-center justify-between gap-2 transition-colors ${
                          active
                            ? 'bg-[#eff6ff] text-[#003087] font-bold'
                            : 'text-[#334155] hover:bg-[#f8fafc]'
                        }`}
                      >
                        <span className="inline-flex items-center gap-2">
                          <FlagIcon code={item.code} className="w-4 h-3" />
                          <span>{item.nativeName}</span>
                        </span>
                        <span className="text-[10px] text-[#64748b] uppercase">{item.short}</span>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export const SiteFooter: React.FC<{
  onNavigate: (route: PageRoute) => void;
  onOpenSellTab: () => void;
  onOpenAgreement: () => void;
}> = ({ onNavigate, onOpenSellTab, onOpenAgreement }) => {
  const { t } = useI18n();

  return (
    <footer className="bg-[#003087] text-[#e2e8f0] pt-14 pb-24 md:pb-12 border-t border-[#1e40af]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-10">
        <div>
          <div className="mb-3">
            <div className="inline-flex items-center rounded-xl bg-white px-3.5 py-2 shadow-sm">
              <img
                src={ZAMTO_LOGO_URL}
                alt="Zamto Africa Company Limited"
                className="h-10 w-auto object-contain"
              />
            </div>
          </div>
          <p className="text-sm text-[#cbd5e1] leading-relaxed mb-4">{t.footer.tagline}</p>
          <div className="flex items-center gap-2 text-xs text-[#fda4af] font-medium mb-5">
            <ShieldCheck className="w-4 h-4 shrink-0" />
            <span>{t.footer.trustLine}</span>
          </div>

          <div>
            <p className="text-xs font-semibold uppercase tracking-wider text-[#fda4af] mb-2.5">
              {t.footer.followUs}
            </p>
            <div className="flex flex-wrap gap-2">
              <a
                href={SOCIAL_LINKS.facebook}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 rounded-lg bg-white/10 hover:bg-[#e11d48] text-white text-xs font-semibold px-3 py-2 transition-colors"
              >
                <Facebook className="w-4 h-4" />
                <span>Facebook</span>
              </a>
              <a
                href={SOCIAL_LINKS.instagram}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 rounded-lg bg-white/10 hover:bg-[#e11d48] text-white text-xs font-semibold px-3 py-2 transition-colors"
              >
                <Instagram className="w-4 h-4" />
                <span>Instagram</span>
              </a>
              <a
                href={SOCIAL_LINKS.tiktok}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 rounded-lg bg-white/10 hover:bg-[#e11d48] text-white text-xs font-semibold px-3 py-2 transition-colors"
              >
                <Video className="w-4 h-4" />
                <span>TikTok</span>
              </a>
            </div>
          </div>
        </div>

        <div>
          <h3 className="text-sm font-semibold uppercase tracking-wider text-[#fda4af] mb-3">
            {t.footer.hireSalesHeading}
          </h3>
          <ul className="space-y-2 text-sm text-[#e2e8f0]">
            <li>
              <button type="button" onClick={() => onNavigate('hire')} className="hover:text-white text-left">
                {t.footer.hirePackagesLink}
              </button>
            </li>
            <li>
              <button type="button" onClick={() => onNavigate('sales')} className="hover:text-white text-left">
                {t.footer.salesLink}
              </button>
            </li>
            <li>
              <button type="button" onClick={onOpenSellTab} className="hover:text-white text-left">
                {t.footer.sellTradeLink}
              </button>
            </li>
            <li>
              <button type="button" onClick={onOpenAgreement} className="hover:text-white text-left">
                {t.footer.viewAgreementLink}
              </button>
            </li>
            <li>
              <a
                href={RENTAL_AGREEMENT_PDF}
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-white inline-flex items-center gap-1.5 text-[#fda4af]"
              >
                <FileText className="w-3.5 h-3.5" />
                <span>{t.footer.downloadPdfLink}</span>
              </a>
            </li>
          </ul>
        </div>

        <div>
          <h3 className="text-sm font-semibold uppercase tracking-wider text-[#fda4af] mb-3">
            {t.footer.lusakaDeliveryHeading}
          </h3>
          <ul className="space-y-2 text-sm text-[#e2e8f0]">
            <li>
              <button type="button" onClick={() => onNavigate('locations')} className="hover:text-white text-left">
                {t.footer.headOfficeMapLink}
              </button>
            </li>
            <li>
              <button type="button" onClick={() => onNavigate('services')} className="hover:text-white text-left">
                {t.footer.airportTransferLink}
              </button>
            </li>
            <li>
              <button type="button" onClick={() => onNavigate('about')} className="hover:text-white text-left">
                {t.footer.aboutLink}
              </button>
            </li>
            <li>
              <button type="button" onClick={() => onNavigate('faq')} className="hover:text-white text-left">
                {t.footer.faqLink}
              </button>
            </li>
            <li>
              <button type="button" onClick={() => onNavigate('blog')} className="hover:text-white text-left">
                {t.footer.tipsLink}
              </button>
            </li>
          </ul>
        </div>

        <div>
          <h3 className="text-sm font-semibold uppercase tracking-wider text-[#fda4af] mb-3">
            {t.footer.headOfficeHeading}
          </h3>
          <p className="text-sm text-[#e2e8f0] mb-2">{HEAD_OFFICE_ADDRESS}</p>
          <p className="text-sm font-medium text-white mb-1">{SUPPORT_PHONE_DISPLAY}</p>
          <p className="text-sm text-[#cbd5e1] mb-4">{SUPPORT_EMAIL}</p>
          <div className="flex flex-wrap gap-2">
            <a
              href={buildWhatsAppUrl('Hello Zamto Africa, I would like assistance with a vehicle.')}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 rounded-lg bg-[#e11d48] hover:bg-[#be123c] text-white text-xs font-bold px-3.5 py-2 transition-colors"
            >
              <MessageCircle className="w-4 h-4" />
              {t.footer.whatsappDeskBtn}
            </a>
            <button
              type="button"
              onClick={() => onNavigate('admin')}
              className="inline-flex items-center rounded-lg border border-white/30 hover:border-white text-xs font-medium px-3 py-2 text-white"
            >
              {t.footer.fleetAdminBtn}
            </button>
            <PWAInstallButton variant="footer" />
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 mt-10 pt-6 border-t border-[#1e40af] flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-[#cbd5e1] tabular-nums">
        <p>
          © {new Date().getFullYear()} {COMPANY_LEGAL_NAME}. {t.footer.rightsReserved}
        </p>
        <p>
          {t.footer.liveRateFooter} · USD 1 = ZMW {getZmwPerUsd().toFixed(2)}
        </p>
      </div>
    </footer>
  );
};

export const MobileBottomNav: React.FC<{
  route: PageRoute;
  onNavigate: (route: PageRoute) => void;
}> = ({ route, onNavigate }) => {
  const { t } = useI18n();
  return (
    <nav
      className="md:hidden fixed bottom-0 inset-x-0 z-40 bg-white border-t border-[#e2e8f0] h-16 px-2 grid grid-cols-5 items-center"
      aria-label="Mobile navigation"
    >
      <button
        type="button"
        onClick={() => onNavigate('home')}
        className={`flex flex-col items-center justify-center gap-0.5 text-[11px] font-medium ${
          route === 'home' ? 'text-[#003087] font-semibold' : 'text-[#64748b]'
        }`}
      >
        <Home className="w-4 h-4" />
        <span className="truncate max-w-full">{t.mobileNav.home}</span>
      </button>
      <button
        type="button"
        onClick={() => onNavigate('hire')}
        className={`flex flex-col items-center justify-center gap-0.5 text-[11px] font-medium ${
          route === 'hire' ? 'text-[#003087] font-semibold' : 'text-[#64748b]'
        }`}
      >
        <Car className="w-4 h-4" />
        <span className="truncate max-w-full">{t.mobileNav.hire}</span>
      </button>
      <button
        type="button"
        onClick={() => onNavigate('sales')}
        className={`flex flex-col items-center justify-center gap-0.5 text-[11px] font-medium ${
          route === 'sales' ? 'text-[#003087] font-semibold' : 'text-[#64748b]'
        }`}
      >
        <ShoppingBag className="w-4 h-4" />
        <span className="truncate max-w-full">{t.mobileNav.buy}</span>
      </button>
      <button
        type="button"
        onClick={() => onNavigate('bookings')}
        className={`flex flex-col items-center justify-center gap-0.5 text-[11px] font-medium ${
          route === 'bookings' ? 'text-[#003087] font-semibold' : 'text-[#64748b]'
        }`}
      >
        <Search className="w-4 h-4" />
        <span className="truncate max-w-full">{t.mobileNav.bookings}</span>
      </button>
      <a
        href={buildWhatsAppUrl('Hello Zamto Africa, I need quick help with a vehicle.')}
        target="_blank"
        rel="noopener noreferrer"
        className="flex flex-col items-center justify-center gap-0.5 text-[11px] font-semibold text-[#003087]"
      >
        <Phone className="w-4 h-4 text-[#e11d48]" />
        <span className="truncate max-w-full">{t.mobileNav.whatsapp}</span>
      </a>
    </nav>
  );
};

export const FloatingWhatsAppButton: React.FC = () => {
  const { t } = useI18n();
  return (
    <a
      href={buildWhatsAppUrl('Hello Zamto Africa! I would like to book or enquire about a vehicle.')}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Chat on WhatsApp with Zamto Africa"
      className="hidden md:inline-flex fixed bottom-6 right-6 z-40 items-center gap-2 rounded-full bg-[#003087] hover:bg-[#002266] text-white border border-[#e11d48] shadow-lg px-4 py-3 text-sm font-semibold transition-transform hover:-translate-y-0.5"
    >
      <MessageCircle className="w-5 h-5 text-[#fda4af]" />
      <span>{t.mobileNav.whatsappSupport}</span>
    </a>
  );
};
