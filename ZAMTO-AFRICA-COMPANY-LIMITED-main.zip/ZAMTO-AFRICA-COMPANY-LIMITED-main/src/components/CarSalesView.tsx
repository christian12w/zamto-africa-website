import React, { useMemo, useState } from 'react';
import {
  BadgeCheck,
  Calculator,
  Check,
  CheckCircle2,
  GitCompare,
  MessageCircle,
  RotateCcw,
  Search,
  SlidersHorizontal,
  X,
} from 'lucide-react';
import type {
  CurrencyMode,
  CustomerBooking,
  SaleVehicle,
  SellCarSubmission,
  VehicleCategory,
} from '../types';
import { ZAMBIA_LOCATIONS } from '../data/zambiaData';
import { useI18n } from '../i18n/I18nContext';
import { dispatchZamtoNotification } from '../utils/dispatch';
import type { DispatchResult } from '../utils/dispatchTypes';
import { buildWhatsAppUrl, formatMoney } from '../utils/format';
import { VehicleImage } from './VehicleImage';

interface CarSalesViewProps {
  inventory: SaleVehicle[];
  currency: CurrencyMode;
  activeTab: 'buy' | 'sell';
  onTabChange: (tab: 'buy' | 'sell') => void;
  compareIds: string[];
  onToggleCompare: (id: string) => void;
  showCompareModal: boolean;
  onSetShowCompareModal: (show: boolean) => void;
  selectedSaleVehicle: SaleVehicle | null;
  onSelectSaleVehicle: (v: SaleVehicle | null) => void;
  onCreateBooking: (booking: CustomerBooking) => void;
  onSubmitSellCar: (lead: SellCarSubmission) => void;
}

const ZAMBIAN_BANKS = [
  { name: 'Zanaco Auto Finance', ratePct: 19.5 },
  { name: 'Stanbic Bank Zambia', ratePct: 18.8 },
  { name: 'Absa Bank Zambia', ratePct: 19.2 },
  { name: 'FNB Zambia Vehicle Finance', ratePct: 18.5 },
];

export const CarSalesView: React.FC<CarSalesViewProps> = ({
  inventory,
  currency,
  activeTab,
  onTabChange,
  compareIds,
  onToggleCompare,
  showCompareModal,
  onSetShowCompareModal,
  selectedSaleVehicle,
  onSelectSaleVehicle,
  onCreateBooking,
  onSubmitSellCar,
}) => {
  const { t } = useI18n();
  const [query, setQuery] = useState('');
  const [makeFilter, setMakeFilter] = useState('All');
  const [bodyFilter, setBodyFilter] = useState<VehicleCategory | 'All'>('All');
  const [fuelFilter, setFuelFilter] = useState<'All' | 'Diesel' | 'Petrol'>('All');
  const [transmissionFilter, setTransmissionFilter] = useState<'All' | 'Automatic' | 'Manual'>('All');
  const [conditionFilter, setConditionFilter] = useState('All');
  const [locationFilter, setLocationFilter] = useState('All');
  const maxInventoryPrice = useMemo(
    () => Math.max(1500000, ...inventory.map((v) => v.priceZmw)),
    [inventory]
  );
  const [minYear, setMinYear] = useState(2010);
  const [maxPriceZmw, setMaxPriceZmw] = useState(1500000);
  const [maxMileageKm, setMaxMileageKm] = useState(250000);
  const [showFiltersMobile, setShowFiltersMobile] = useState(false);
  const [photoIndexes, setPhotoIndexes] = useState<Record<string, number>>({});

  React.useEffect(() => {
    setMaxPriceZmw((prev) => (prev < maxInventoryPrice ? maxInventoryPrice : prev));
  }, [maxInventoryPrice]);

  const makes = useMemo(
    () => ['All', ...Array.from(new Set(inventory.map((v) => v.make)))],
    [inventory]
  );

  const filteredSales = useMemo(() => {
    return inventory.filter((car) => {
      if (
        query.trim() &&
        !`${car.name} ${car.make} ${car.model} ${car.engine}`
          .toLowerCase()
          .includes(query.toLowerCase())
      ) {
        return false;
      }
      if (makeFilter !== 'All' && car.make !== makeFilter) return false;
      if (bodyFilter !== 'All' && car.bodyType !== bodyFilter) return false;
      if (fuelFilter !== 'All' && car.fuel !== fuelFilter) return false;
      if (transmissionFilter !== 'All' && car.transmission !== transmissionFilter) return false;
      if (conditionFilter !== 'All' && car.condition !== conditionFilter) return false;
      if (locationFilter !== 'All' && car.location !== locationFilter) return false;
      if (car.year < minYear) return false;
      if (car.priceZmw > maxPriceZmw) return false;
      if (car.mileageKm > maxMileageKm) return false;
      return true;
    });
  }, [
    inventory,
    query,
    makeFilter,
    bodyFilter,
    fuelFilter,
    transmissionFilter,
    conditionFilter,
    locationFilter,
    minYear,
    maxPriceZmw,
    maxMileageKm,
  ]);

  const compareVehicles = useMemo(
    () => inventory.filter((v) => compareIds.includes(v.id)),
    [inventory, compareIds]
  );

  const resetFilters = () => {
    setQuery('');
    setMakeFilter('All');
    setBodyFilter('All');
    setFuelFilter('All');
    setTransmissionFilter('All');
    setConditionFilter('All');
    setLocationFilter('All');
    setMinYear(2010);
    setMaxPriceZmw(maxInventoryPrice);
    setMaxMileageKm(250000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 sm:py-12">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-6">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.16em] text-[#e11d48] mb-1">
            {t.sales.kicker}
          </p>
          <h1 className="text-3xl sm:text-4xl font-semibold text-[#003087]">
            {activeTab === 'buy' ? t.sales.buyTitle : t.sales.sellTitle}
          </h1>
          <p className="text-sm text-[#475569] mt-1">{t.sales.subline}</p>
        </div>

        <div className="inline-flex rounded-xl bg-[#f1f5f9] p-1 border border-[#e2e8f0]">
          <button
            type="button"
            onClick={() => onTabChange('buy')}
            className={`px-4 py-2 rounded-lg text-xs sm:text-sm font-semibold transition-colors ${
              activeTab === 'buy'
                ? 'bg-[#003087] text-white'
                : 'text-[#475569] hover:text-[#003087]'
            }`}
          >
            {t.sales.buyTab} ({inventory.filter((v) => v.status !== 'Sold').length})
          </button>
          <button
            type="button"
            onClick={() => onTabChange('sell')}
            className={`px-4 py-2 rounded-lg text-xs sm:text-sm font-semibold transition-colors ${
              activeTab === 'sell'
                ? 'bg-[#003087] text-white'
                : 'text-[#475569] hover:text-[#003087]'
            }`}
          >
            {t.sales.sellTab}
          </button>
        </div>
      </div>

      {activeTab === 'buy' ? (
        <>
          <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
            <div className="relative flex-1 min-w-[240px]">
              <Search className="w-4 h-4 text-[#64748b] absolute left-3 top-3" />
              <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder={t.sales.searchPlaceholder}
                className="w-full rounded-xl border border-[#cbd5e1] bg-white pl-9 pr-4 py-2.5 text-sm focus:border-[#003087] focus:outline-none"
              />
            </div>

            <div className="flex items-center gap-2">
              {compareIds.length > 0 && (
                <button
                  type="button"
                  onClick={() => onSetShowCompareModal(true)}
                  className="inline-flex items-center gap-2 rounded-xl bg-[#e11d48] text-white px-4 py-2.5 text-xs sm:text-sm font-bold"
                >
                  <GitCompare className="w-4 h-4" />
                  <span>
                    {t.sales.compareSelected} ({compareIds.length}/3)
                  </span>
                </button>
              )}

              <button
                type="button"
                onClick={() => setShowFiltersMobile((p) => !p)}
                className="lg:hidden inline-flex items-center gap-2 rounded-xl border border-[#cbd5e1] bg-white px-4 py-2.5 text-xs font-semibold"
              >
                <SlidersHorizontal className="w-4 h-4" />
                <span>{t.sales.filtersBtn}</span>
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-4 gap-8 items-start">
            <aside
              className={`${
                showFiltersMobile ? 'block' : 'hidden'
              } lg:block rounded-2xl bg-white border border-[#e2e8f0] p-5 space-y-4 lg:sticky lg:top-28`}
            >
              <div className="flex items-center justify-between">
                <h2 className="font-sans text-sm font-bold uppercase tracking-wider text-[#003087]">
                  {t.sales.inventoryFilters}
                </h2>
                <button
                  type="button"
                  onClick={resetFilters}
                  className="text-xs font-semibold text-[#64748b] hover:text-[#003087] inline-flex items-center gap-1"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  {t.sales.resetBtn}
                </button>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-semibold text-[#475569] mb-1">Make</label>
                  <select
                    value={makeFilter}
                    onChange={(e) => setMakeFilter(e.target.value)}
                    className="w-full rounded-lg border border-[#cbd5e1] bg-[#f8fafc] px-2.5 py-2 text-xs"
                  >
                    {makes.map((m) => (
                      <option key={m} value={m}>
                        {m}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#475569] mb-1">
                    Body Type
                  </label>
                  <select
                    value={bodyFilter}
                    onChange={(e) => setBodyFilter(e.target.value as VehicleCategory | 'All')}
                    className="w-full rounded-lg border border-[#cbd5e1] bg-[#f8fafc] px-2.5 py-2 text-xs"
                  >
                    {['All', 'Economy', 'Sedan', 'SUV / 4x4', 'Pickup', 'Luxury', 'Van / Bus'].map(
                      (b) => (
                        <option key={b} value={b}>
                          {b}
                        </option>
                      )
                    )}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-semibold text-[#475569] mb-1">Fuel</label>
                  <select
                    value={fuelFilter}
                    onChange={(e) => setFuelFilter(e.target.value as 'All' | 'Diesel' | 'Petrol')}
                    className="w-full rounded-lg border border-[#cbd5e1] bg-[#f8fafc] px-2.5 py-2 text-xs"
                  >
                    <option value="All">Any</option>
                    <option value="Diesel">Diesel</option>
                    <option value="Petrol">Petrol</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#475569] mb-1">
                    Transmission
                  </label>
                  <select
                    value={transmissionFilter}
                    onChange={(e) =>
                      setTransmissionFilter(e.target.value as 'All' | 'Automatic' | 'Manual')
                    }
                    className="w-full rounded-lg border border-[#cbd5e1] bg-[#f8fafc] px-2.5 py-2 text-xs"
                  >
                    <option value="All">Any</option>
                    <option value="Automatic">Automatic</option>
                    <option value="Manual">Manual</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#475569] mb-1">Condition</label>
                <select
                  value={conditionFilter}
                  onChange={(e) => setConditionFilter(e.target.value)}
                  className="w-full rounded-lg border border-[#cbd5e1] bg-[#f8fafc] px-2.5 py-2 text-xs"
                >
                  <option value="All">All Conditions</option>
                  <option value="Fresh Japanese Import">Fresh Japanese Import</option>
                  <option value="Certified Pre-Owned">Certified Pre-Owned</option>
                  <option value="Zambian Used">Zambian Used</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#475569] mb-1">Location</label>
                <select
                  value={locationFilter}
                  onChange={(e) => setLocationFilter(e.target.value)}
                  className="w-full rounded-lg border border-[#cbd5e1] bg-[#f8fafc] px-2.5 py-2 text-xs"
                >
                  <option value="All">All Locations</option>
                  {ZAMBIA_LOCATIONS.map((loc) => (
                    <option key={loc} value={loc}>
                      {loc}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <div className="flex justify-between text-xs font-semibold text-[#475569] mb-1">
                  <span>Min Year</span>
                  <span className="tabular-nums text-[#003087]">{minYear}+</span>
                </div>
                <input
                  type="range"
                  min={2010}
                  max={2023}
                  value={minYear}
                  onChange={(e) => setMinYear(Number(e.target.value))}
                  className="w-full accent-[#003087]"
                />
              </div>

              <div>
                <div className="flex justify-between text-xs font-semibold text-[#475569] mb-1">
                  <span>Max Price</span>
                  <span className="tabular-nums text-[#003087]">
                    {formatMoney(maxPriceZmw, currency)}
                  </span>
                </div>
                <input
                  type="range"
                  min={100000}
                  max={maxInventoryPrice}
                  step={20000}
                  value={maxPriceZmw}
                  onChange={(e) => setMaxPriceZmw(Number(e.target.value))}
                  className="w-full accent-[#003087]"
                />
              </div>

              <div>
                <div className="flex justify-between text-xs font-semibold text-[#475569] mb-1">
                  <span>Max Mileage</span>
                  <span className="tabular-nums text-[#003087]">
                    {maxMileageKm.toLocaleString('en-US')} km
                  </span>
                </div>
                <input
                  type="range"
                  min={40000}
                  max={250000}
                  step={10000}
                  value={maxMileageKm}
                  onChange={(e) => setMaxMileageKm(Number(e.target.value))}
                  className="w-full accent-[#003087]"
                />
              </div>
            </aside>

            <div className="lg:col-span-3 space-y-8">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {filteredSales.map((car) => {
                  const idx = photoIndexes[car.id] ?? 0;
                  const activePhoto = car.photos[idx] || car.photos[0];
                  const isSold = car.status === 'Sold';
                  const compared = compareIds.includes(car.id);

                  return (
                    <article
                      key={car.id}
                      className="rounded-2xl bg-white border border-[#e2e8f0] overflow-hidden flex flex-col hover:shadow-lg transition-shadow"
                    >
                      <div className="relative aspect-[4/3] bg-white border-b border-[#f1f5f9]">
                        <VehicleImage src={activePhoto?.url} alt={car.name} />
                        {isSold && (
                          <div className="absolute inset-0 bg-[#0f172a]/70 flex items-center justify-center">
                            <span className="bg-[#e11d48] text-white font-bold text-xs uppercase tracking-widest px-4 py-1.5 rounded">
                              SOLD
                            </span>
                          </div>
                        )}
                      </div>

                      <div className="px-4 pt-3 flex items-center justify-between gap-2">
                        <div className="flex items-center gap-1.5 overflow-x-auto">
                          {car.photos.map((p, i) => (
                            <button
                              key={p.label}
                              type="button"
                              onClick={() => setPhotoIndexes((prev) => ({ ...prev, [car.id]: i }))}
                              className={`text-[11px] px-2 py-0.5 rounded border whitespace-nowrap ${
                                idx === i
                                  ? 'border-[#003087] bg-[#eff6ff] text-[#003087] font-semibold'
                                  : 'border-[#e2e8f0] text-[#64748b]'
                              }`}
                            >
                              {p.label}
                            </button>
                          ))}
                        </div>
                        <label className="inline-flex items-center gap-1 text-[11px] font-semibold text-[#475569] shrink-0 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={compared}
                            onChange={() => onToggleCompare(car.id)}
                            className="accent-[#003087]"
                          />
                          <span>{t.sales.compareCheckbox}</span>
                        </label>
                      </div>

                      <div className="p-5 flex-1 flex flex-col">
                        <p className="text-xs font-medium text-[#64748b] mb-1 tabular-nums">
                          {car.year} · {car.mileageKm.toLocaleString('en-US')} km · {car.fuel} ·{' '}
                          {car.transmission}
                        </p>
                        <h3 className="text-lg font-semibold text-[#003087] mb-1">{car.name}</h3>
                        <p className="text-xs text-[#64748b] mb-3">
                          {car.condition} · {car.location}
                        </p>

                        <div className="mt-auto pt-4 border-t border-[#f1f5f9] flex items-center justify-between gap-2">
                          <div>
                            <p className="text-xl font-bold text-[#e11d48] tabular-nums">
                              {formatMoney(car.priceZmw, currency)}
                            </p>
                            <p className="text-[11px] text-[#64748b]">{car.warranty}</p>
                          </div>

                          <div className="flex items-center gap-2">
                            <a
                              href={buildWhatsAppUrl(
                                `Hello Zamto Africa, I am enquiring about purchasing the ${car.name} listed at ${formatMoney(
                                  car.priceZmw,
                                  currency
                                )}.`
                              )}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="rounded-lg border border-[#cbd5e1] hover:border-[#003087] p-2.5 text-[#003087]"
                              aria-label={`WhatsApp about ${car.name}`}
                            >
                              <MessageCircle className="w-4 h-4" />
                            </a>
                            <button
                              type="button"
                              onClick={() => onSelectSaleVehicle(car)}
                              className="rounded-lg bg-[#003087] hover:bg-[#002266] px-4 py-2.5 text-xs font-semibold text-white"
                            >
                              {t.sales.viewDetailsBtn}
                            </button>
                          </div>
                        </div>
                      </div>
                    </article>
                  );
                })}
              </div>

              <div className="rounded-2xl bg-white border border-[#e2e8f0] p-6">
                <p className="text-xs font-semibold uppercase tracking-wider text-[#e11d48] mb-1">
                  {t.sales.financeKicker}
                </p>
                <h3 className="text-lg font-semibold text-[#003087] mb-3">
                  {t.sales.financeHeading}
                </h3>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {ZAMBIAN_BANKS.map((bank) => (
                    <div
                      key={bank.name}
                      className="rounded-xl bg-[#f8fafc] border border-[#e2e8f0] p-3 text-xs"
                    >
                      <p className="font-semibold text-[#0f172a]">{bank.name}</p>
                      <p className="text-[#64748b] mt-0.5 tabular-nums">
                        Indicative {bank.ratePct}% p.a.
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </>
      ) : (
        <SellAndTradeInSection onSubmitSellCar={onSubmitSellCar} currency={currency} />
      )}

      {selectedSaleVehicle && (
        <SaleDetailModal
          vehicle={selectedSaleVehicle}
          currency={currency}
          onClose={() => onSelectSaleVehicle(null)}
          onCreateBooking={onCreateBooking}
        />
      )}

      {showCompareModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-5xl w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-[#e2e8f0]">
            <div className="px-6 py-4 border-b border-[#e2e8f0] flex items-center justify-between">
              <h2 className="text-xl font-semibold text-[#003087]">
                Side-by-Side Vehicle Comparison
              </h2>
              <button
                type="button"
                onClick={() => onSetShowCompareModal(false)}
                className="p-2 rounded-lg hover:bg-[#f1f5f9]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-6 overflow-x-auto">
              {compareVehicles.length === 0 ? (
                <p className="text-sm text-[#64748b]">
                  Tick &ldquo;Compare&rdquo; on 2 or 3 vehicles to compare specifications side by side.
                </p>
              ) : (
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="border-b border-[#e2e8f0]">
                      <th className="py-3 pr-4 font-semibold text-[#64748b]">Attribute</th>
                      {compareVehicles.map((v) => (
                        <th key={v.id} className="py-3 px-4 min-w-[200px]">
                          <div className="aspect-[4/3] rounded-lg overflow-hidden mb-2">
                            <VehicleImage src={v.photos[0]?.url} alt={v.name} />
                          </div>
                          <p className="font-semibold text-sm text-[#003087]">{v.name}</p>
                          <button
                            type="button"
                            onClick={() => onToggleCompare(v.id)}
                            className="text-[11px] text-[#e11d48] hover:underline mt-1"
                          >
                            Remove
                          </button>
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#f1f5f9] tabular-nums">
                    {[
                      { label: 'Price', fn: (v: SaleVehicle) => formatMoney(v.priceZmw, currency) },
                      { label: 'Status', fn: (v: SaleVehicle) => v.status },
                      { label: 'Year', fn: (v: SaleVehicle) => String(v.year) },
                      {
                        label: 'Mileage',
                        fn: (v: SaleVehicle) => `${v.mileageKm.toLocaleString('en-US')} km`,
                      },
                      { label: 'Engine', fn: (v: SaleVehicle) => v.engine },
                      { label: 'Fuel / Gear', fn: (v: SaleVehicle) => `${v.fuel} · ${v.transmission}` },
                      { label: 'Condition', fn: (v: SaleVehicle) => v.condition },
                      { label: 'Warranty', fn: (v: SaleVehicle) => v.warranty },
                      { label: 'Location', fn: (v: SaleVehicle) => v.location },
                    ].map((row) => (
                      <tr key={row.label}>
                        <td className="py-2.5 pr-4 font-semibold text-[#475569]">{row.label}</td>
                        {compareVehicles.map((v) => (
                          <td key={v.id} className="py-2.5 px-4 text-[#0f172a]">
                            {row.fn(v)}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

const SaleDetailModal: React.FC<{
  vehicle: SaleVehicle;
  currency: CurrencyMode;
  onClose: () => void;
  onCreateBooking: (b: CustomerBooking) => void;
}> = ({ vehicle, currency, onClose, onCreateBooking }) => {
  const { t } = useI18n();
  const [photoIdx, setPhotoIdx] = useState(0);
  const [depositPct, setDepositPct] = useState(25);
  const [months, setMonths] = useState(36);
  const [bankIdx, setBankIdx] = useState(0);
  const [actionMode, setActionMode] = useState<'none' | 'testdrive' | 'offer'>('none');
  const [custName, setCustName] = useState('');
  const [custPhone, setCustPhone] = useState('');
  const [custEmail, setCustEmail] = useState('');
  const [visitDate, setVisitDate] = useState('2026-11-26');
  const [offerZmw, setOfferZmw] = useState(Math.round(vehicle.priceZmw * 0.95));
  const [submittedNotice, setSubmittedNotice] = useState('');
  const [actionDispatch, setActionDispatch] = useState<DispatchResult | null>(null);

  const annualRate = ZAMBIAN_BANKS[bankIdx].ratePct / 100;
  const monthlyRate = annualRate / 12;
  const principal = vehicle.priceZmw * (1 - depositPct / 100);
  const monthlyPaymentZmw = Math.round(
    (principal * monthlyRate * Math.pow(1 + monthlyRate, months)) /
      (Math.pow(1 + monthlyRate, months) - 1)
  );

  const handleActionSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const id = `ZA-S${Math.floor(10000 + Math.random() * 90000)}`;
    const isOffer = actionMode === 'offer';
    onCreateBooking({
      id,
      type: isOffer ? 'Purchase Offer' : 'Test Drive',
      vehicleId: vehicle.id,
      vehicleName: vehicle.name,
      pickupLocation: vehicle.location,
      startDate: visitDate,
      totalZmw: isOffer ? offerZmw : vehicle.priceZmw,
      paymentMethod: isOffer ? 'Bank Finance / Cash Offer' : 'Showroom Viewing',
      customerName: custName,
      customerPhone: custPhone,
      customerEmail: custEmail || 'zamtoafrica@gmail.com',
      status: 'Pending Verification',
      createdAt: new Date().toISOString(),
    });
    const res = await dispatchZamtoNotification({
      kind: isOffer ? 'Purchase Offer' : 'Test Drive Request',
      reference: id,
      customerName: custName,
      customerPhone: custPhone,
      customerEmail: custEmail || undefined,
      topicOrVehicle: vehicle.name,
      pickupLocation: vehicle.location,
      dateRange: isOffer ? undefined : visitDate,
      totalDisplay: formatMoney(isOffer ? offerZmw : vehicle.priceZmw, currency),
      message: isOffer
        ? `Cash/Finance Offer submitted: ${formatMoney(offerZmw, currency)}`
        : `Showroom test drive / inspection scheduled for ${visitDate}`,
    });
    setActionDispatch(res);
    setSubmittedNotice(
      isOffer
        ? `Offer ${id} (${formatMoney(offerZmw, currency)}) dispatched to zamtoafrica@gmail.com & WhatsApp (+260 572 213 038).`
        : `Test Drive ${id} (${visitDate}) dispatched to zamtoafrica@gmail.com & WhatsApp (+260 572 213 038).`
    );
    setActionMode('none');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-4xl w-full max-h-[92vh] overflow-y-auto shadow-2xl border border-[#e2e8f0]">
        <div className="sticky top-0 z-10 bg-white border-b border-[#e2e8f0] px-5 py-4 flex items-center justify-between">
          <div>
            <p className="text-xs font-semibold uppercase tracking-wider text-[#e11d48]">
              Zamto Africa Stock · {vehicle.condition} · {vehicle.status}
            </p>
            <h2 className="text-xl sm:text-2xl font-semibold text-[#003087]">{vehicle.name}</h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-lg hover:bg-[#f1f5f9]"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 sm:p-6 space-y-6">
          {submittedNotice && (
            <div className="rounded-xl bg-[#eff6ff] border border-[#bfdbfe] p-4 text-xs font-semibold text-[#003087] flex flex-wrap items-center justify-between gap-2">
              <span className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>{submittedNotice}</span>
              </span>
              {actionDispatch && (
                <a
                  href={actionDispatch.whatsappUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="rounded-lg bg-[#e11d48] text-white px-3 py-1.5 text-[11px] font-bold inline-flex items-center gap-1"
                >
                  <MessageCircle className="w-3.5 h-3.5" />
                  <span>Open in WhatsApp</span>
                </a>
              )}
            </div>
          )}

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div>
              <div className="relative aspect-[4/3] rounded-xl overflow-hidden bg-white border border-[#e2e8f0]">
                <VehicleImage src={vehicle.photos[photoIdx]?.url} alt={vehicle.name} />
              </div>
              <div className="grid grid-cols-3 gap-2 mt-3">
                {vehicle.photos.map((p, idx) => (
                  <button
                    key={p.label}
                    type="button"
                    onClick={() => setPhotoIdx(idx)}
                    className={`rounded-lg overflow-hidden border-2 ${
                      photoIdx === idx ? 'border-[#e11d48]' : 'border-transparent opacity-75'
                    }`}
                  >
                    <div className="aspect-[4/3]">
                      <VehicleImage src={p.url} alt={p.label} />
                    </div>
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-4">
              <div className="flex items-baseline justify-between">
                <p className="text-3xl font-bold text-[#e11d48] tabular-nums">
                  {formatMoney(vehicle.priceZmw, currency)}
                </p>
                <span className="text-xs font-semibold text-[#64748b]">{vehicle.importOrigin}</span>
              </div>

              <div className="grid grid-cols-2 gap-3 rounded-xl bg-[#f8fafc] border border-[#e2e8f0] p-4 text-xs tabular-nums">
                <div>
                  <span className="text-[#64748b] block">Year &amp; Mileage</span>
                  <span className="font-semibold">
                    {vehicle.year} · {vehicle.mileageKm.toLocaleString('en-US')} km
                  </span>
                </div>
                <div>
                  <span className="text-[#64748b] block">Engine &amp; Fuel</span>
                  <span className="font-semibold">
                    {vehicle.engine} ({vehicle.fuel})
                  </span>
                </div>
                <div>
                  <span className="text-[#64748b] block">Transmission</span>
                  <span className="font-semibold">{vehicle.transmission}</span>
                </div>
                <div>
                  <span className="text-[#64748b] block">Warranty</span>
                  <span className="font-semibold">{vehicle.warranty}</span>
                </div>
              </div>

              <div className="text-xs space-y-2 text-[#334155]">
                <p>
                  <strong className="text-[#003087]">Condition Report:</strong>{' '}
                  {vehicle.conditionSummary}
                </p>
                <p>
                  <strong className="text-[#003087]">Service History:</strong>{' '}
                  {vehicle.serviceHistory}
                </p>
              </div>

              <div className="flex flex-wrap gap-2 text-xs text-[#334155]">
                {vehicle.features.map((f) => (
                  <span key={f} className="inline-flex items-center gap-1 mr-2">
                    <Check className="w-3.5 h-3.5 text-[#e11d48]" />
                    {f}
                  </span>
                ))}
              </div>

              {vehicle.status !== 'Sold' ? (
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setActionMode('testdrive')}
                    className="rounded-lg bg-[#003087] hover:bg-[#002266] text-white text-xs font-semibold py-2.5 px-3"
                  >
                    {t.sales.bookTestDrive}
                  </button>
                  <button
                    type="button"
                    onClick={() => setActionMode('offer')}
                    className="rounded-lg bg-[#e11d48] hover:bg-[#be123c] text-white text-xs font-bold py-2.5 px-3"
                  >
                    {t.sales.makeOffer}
                  </button>
                  <a
                    href={buildWhatsAppUrl(
                      `Hello Zamto Africa Sales, I want to arrange a viewing for the ${vehicle.name} (${formatMoney(
                        vehicle.priceZmw,
                        currency
                      )}).`
                    )}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="rounded-lg border border-[#003087] text-[#003087] text-xs font-semibold py-2.5 px-3 flex items-center justify-center gap-1.5"
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>{t.sales.contactDealer}</span>
                  </a>
                </div>
              ) : (
                <a
                  href={buildWhatsAppUrl(
                    `Hello Zamto Africa, I saw the sold ${vehicle.name}. Please notify me when similar stock arrives.`
                  )}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 rounded-lg bg-[#003087] text-white text-xs font-semibold px-4 py-2.5"
                >
                  <MessageCircle className="w-4 h-4 text-[#fda4af]" />
                  <span>Request Similar Stock via WhatsApp</span>
                </a>
              )}
            </div>
          </div>

          {actionMode !== 'none' && (
            <form
              onSubmit={handleActionSubmit}
              className="rounded-xl bg-[#f1f5f9] border border-[#cbd5e1] p-4 grid grid-cols-1 sm:grid-cols-5 gap-3 items-end"
            >
              <div>
                <label className="block text-xs font-semibold mb-1">Your Name *</label>
                <input
                  type="text"
                  required
                  value={custName}
                  onChange={(e) => setCustName(e.target.value)}
                  className="w-full rounded-lg border border-[#cbd5e1] bg-white px-3 py-2 text-xs"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold mb-1">Phone / WhatsApp *</label>
                <input
                  type="tel"
                  required
                  value={custPhone}
                  onChange={(e) => setCustPhone(e.target.value)}
                  className="w-full rounded-lg border border-[#cbd5e1] bg-white px-3 py-2 text-xs"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold mb-1">Email</label>
                <input
                  type="email"
                  value={custEmail}
                  onChange={(e) => setCustEmail(e.target.value)}
                  placeholder="Optional"
                  className="w-full rounded-lg border border-[#cbd5e1] bg-white px-3 py-2 text-xs"
                />
              </div>
              {actionMode === 'testdrive' ? (
                <div>
                  <label className="block text-xs font-semibold mb-1">Preferred Date</label>
                  <input
                    type="date"
                    value={visitDate}
                    onChange={(e) => setVisitDate(e.target.value)}
                    className="w-full rounded-lg border border-[#cbd5e1] bg-white px-3 py-2 text-xs"
                  />
                </div>
              ) : (
                <div>
                  <label className="block text-xs font-semibold mb-1">Your Offer (ZMW)</label>
                  <input
                    type="number"
                    value={offerZmw}
                    onChange={(e) => setOfferZmw(Number(e.target.value))}
                    className="w-full rounded-lg border border-[#cbd5e1] bg-white px-3 py-2 text-xs tabular-nums"
                  />
                </div>
              )}
              <button
                type="submit"
                className="rounded-lg bg-[#003087] text-white text-xs font-semibold py-2.5 px-4"
              >
                {actionMode === 'offer' ? t.sales.submitOffer : t.sales.confirmViewing}
              </button>
            </form>
          )}

          <div className="rounded-2xl bg-[#f8fafc] border border-[#e2e8f0] p-5">
            <h3 className="text-sm font-bold uppercase tracking-wider text-[#003087] mb-4 flex items-center gap-2">
              <Calculator className="w-4 h-4 text-[#e11d48]" />
              <span>Zambian Bank Financing Estimator</span>
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
              <div>
                <label className="block text-xs font-semibold text-[#475569] mb-1">
                  Partner Bank
                </label>
                <select
                  value={bankIdx}
                  onChange={(e) => setBankIdx(Number(e.target.value))}
                  className="w-full rounded-lg border border-[#cbd5e1] bg-white px-3 py-2 text-xs"
                >
                  {ZAMBIAN_BANKS.map((b, i) => (
                    <option key={b.name} value={i}>
                      {b.name} ({b.ratePct}%)
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <div className="flex justify-between text-xs font-semibold text-[#475569] mb-1">
                  <span>Deposit</span>
                  <span className="tabular-nums">{depositPct}%</span>
                </div>
                <input
                  type="range"
                  min={10}
                  max={50}
                  step={5}
                  value={depositPct}
                  onChange={(e) => setDepositPct(Number(e.target.value))}
                  className="w-full accent-[#003087]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#475569] mb-1">Repayment</label>
                <select
                  value={months}
                  onChange={(e) => setMonths(Number(e.target.value))}
                  className="w-full rounded-lg border border-[#cbd5e1] bg-white px-3 py-2 text-xs"
                >
                  {[12, 24, 36, 48].map((m) => (
                    <option key={m} value={m}>
                      {m} months
                    </option>
                  ))}
                </select>
              </div>

              <div className="rounded-xl bg-[#003087] text-white p-3.5 text-center tabular-nums">
                <p className="text-[11px] text-[#cbd5e1]">Estimated Monthly</p>
                <p className="text-lg font-bold text-[#fda4af]">
                  {formatMoney(monthlyPaymentZmw, currency)}/mo
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const SellAndTradeInSection: React.FC<{
  onSubmitSellCar: (lead: SellCarSubmission) => void;
  currency: CurrencyMode;
}> = ({ onSubmitSellCar, currency }) => {
  const { t } = useI18n();
  const [sellerType, setSellerType] = useState<'Private Seller' | 'Dealer Partner'>('Private Seller');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [city, setCity] = useState('Lusaka');
  const [makeModel, setMakeModel] = useState('Toyota Hilux Double Cab');
  const [year, setYear] = useState(2019);
  const [mileageKm, setMileageKm] = useState(85000);
  const [askingPriceZmw, setAskingPriceZmw] = useState(620000);
  const [condition, setCondition] = useState('Very Good');
  const [submitted, setSubmitted] = useState(false);
  const [sellDispatch, setSellDispatch] = useState<DispatchResult | null>(null);

  const baseFactor = Math.max(0.45, 1 - (2026 - year) * 0.065);
  const mileageFactor = mileageKm > 150000 ? 0.8 : mileageKm > 90000 ? 0.9 : 1;
  const estLow = Math.round((askingPriceZmw * 0.78 * baseFactor * mileageFactor) / 5000) * 5000;
  const estHigh = Math.round((askingPriceZmw * 0.9 * baseFactor * mileageFactor) / 5000) * 5000;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const id = `SELL-${Math.floor(1000 + Math.random() * 9000)}`;
    onSubmitSellCar({
      id,
      sellerType,
      name,
      phone,
      city,
      makeModel,
      year,
      mileageKm,
      askingPriceZmw,
      condition,
      createdAt: new Date().toISOString(),
    });
    const res = await dispatchZamtoNotification({
      kind: 'Sell / Trade-In Lead',
      reference: id,
      customerName: name,
      customerPhone: phone,
      customerEmail: email || undefined,
      topicOrVehicle: `${year} ${makeModel} (${sellerType})`,
      pickupLocation: city,
      totalDisplay: formatMoney(askingPriceZmw, currency),
      message: `Mileage: ${mileageKm.toLocaleString('en-US')} km | Condition: ${condition} | Est Trade-In: ${formatMoney(estLow, currency)} – ${formatMoney(estHigh, currency)}`,
    });
    setSellDispatch(res);
    setSubmitted(true);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
      <div className="lg:col-span-3 rounded-2xl bg-white border border-[#e2e8f0] p-6 sm:p-8">
        <div className="flex items-center justify-between gap-4 mb-5">
          <div>
            <h2 className="text-2xl font-semibold text-[#003087]">{t.sales.sellHeading}</h2>
            <p className="text-xs text-[#64748b] mt-1">{t.sales.sellSub}</p>
          </div>
          <div className="inline-flex rounded-lg bg-[#f1f5f9] p-1 text-xs font-semibold">
            {(['Private Seller', 'Dealer Partner'] as const).map((kind) => (
              <button
                key={kind}
                type="button"
                onClick={() => setSellerType(kind)}
                className={`px-3 py-1.5 rounded ${
                  sellerType === kind ? 'bg-[#003087] text-white' : 'text-[#475569]'
                }`}
              >
                {kind === 'Private Seller' ? t.sales.privateSeller : t.sales.dealerPartner}
              </button>
            ))}
          </div>
        </div>

        {submitted ? (
          <div className="rounded-xl bg-[#eff6ff] border border-[#bfdbfe] p-6 text-center space-y-3">
            <BadgeCheck className="w-8 h-8 text-[#003087] mx-auto" />
            <h3 className="text-lg font-semibold text-[#003087]">
              {t.sales.valuationReceived}
            </h3>
            <p className="text-sm text-[#475569]">
              Sent to <strong>zamtoafrica@gmail.com</strong> &amp; WhatsApp{' '}
              <strong>+260 572 213 038</strong>. Our acquisitions team will contact {phone}.
            </p>
            <div className="flex flex-wrap justify-center gap-2 pt-1">
              {sellDispatch && (
                <a
                  href={sellDispatch.whatsappUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="rounded-lg bg-[#e11d48] text-white text-xs font-bold px-4 py-2 inline-flex items-center gap-1.5"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>{t.sales.sendPhotosWhatsapp}</span>
                </a>
              )}
              <button
                type="button"
                onClick={() => setSubmitted(false)}
                className="rounded-lg bg-[#003087] text-white text-xs font-semibold px-4 py-2"
              >
                Submit Another Vehicle
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-semibold mb-1">Your Name *</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full rounded-lg border border-[#cbd5e1] px-3 py-2 text-sm"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold mb-1">Phone / WhatsApp *</label>
                <input
                  type="tel"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="+260..."
                  className="w-full rounded-lg border border-[#cbd5e1] px-3 py-2 text-sm"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold mb-1">City</label>
                <select
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  className="w-full rounded-lg border border-[#cbd5e1] px-3 py-2 text-sm"
                >
                  {['Lusaka', 'Livingstone', 'Ndola', 'Kitwe', 'Solwezi'].map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold mb-1">Make &amp; Model *</label>
                <input
                  type="text"
                  required
                  value={makeModel}
                  onChange={(e) => setMakeModel(e.target.value)}
                  className="w-full rounded-lg border border-[#cbd5e1] px-3 py-2 text-sm"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold mb-1">Condition</label>
                <select
                  value={condition}
                  onChange={(e) => setCondition(e.target.value)}
                  className="w-full rounded-lg border border-[#cbd5e1] px-3 py-2 text-sm"
                >
                  <option>Excellent / Low Mileage</option>
                  <option>Very Good</option>
                  <option>Good / Minor Wear</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-semibold mb-1">Year</label>
                <input
                  type="number"
                  min={2005}
                  max={2026}
                  value={year}
                  onChange={(e) => setYear(Number(e.target.value))}
                  className="w-full rounded-lg border border-[#cbd5e1] px-3 py-2 text-sm tabular-nums"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold mb-1">Mileage (km)</label>
                <input
                  type="number"
                  value={mileageKm}
                  onChange={(e) => setMileageKm(Number(e.target.value))}
                  className="w-full rounded-lg border border-[#cbd5e1] px-3 py-2 text-sm tabular-nums"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold mb-1">Target Price (ZMW)</label>
                <input
                  type="number"
                  value={askingPriceZmw}
                  onChange={(e) => setAskingPriceZmw(Number(e.target.value))}
                  className="w-full rounded-lg border border-[#cbd5e1] px-3 py-2 text-sm tabular-nums"
                />
              </div>
            </div>

            <button
              type="submit"
              className="rounded-lg bg-[#003087] hover:bg-[#002266] text-white font-semibold text-sm px-6 py-3"
            >
              {t.sales.submitListing} ({sellerType})
            </button>
          </form>
        )}
      </div>

      <div className="lg:col-span-2 rounded-2xl bg-[#003087] text-white p-6 sm:p-8 flex flex-col justify-between">
        <div>
          <p className="text-xs font-semibold uppercase tracking-wider text-[#fda4af] mb-2">
            {t.sales.tradeInTitle}
          </p>
          <h3 className="text-2xl font-semibold text-white mb-2">{makeModel}</h3>
          <p className="text-xs text-[#cbd5e1] mb-6 tabular-nums">
            {year} · {mileageKm.toLocaleString('en-US')} km · {condition}
          </p>

          <div className="rounded-xl bg-white/10 border border-white/15 p-5 mb-5 tabular-nums">
            <p className="text-xs text-[#e2e8f0] mb-1">{t.sales.estOfferRange}</p>
            <p className="text-2xl font-bold text-[#fda4af]">
              {formatMoney(estLow, currency)} – {formatMoney(estHigh, currency)}
            </p>
          </div>
          <p className="text-xs text-[#cbd5e1] leading-relaxed">
            Final valuation confirmed within 30 minutes of a physical mechanical &amp; ZRA document
            inspection at our Rhodes Park showroom.
          </p>
        </div>

        <a
          href={buildWhatsAppUrl(
            `Hello Zamto Africa Acquisitions, I want to sell/trade-in my ${year} ${makeModel} (${mileageKm.toLocaleString(
              'en-US'
            )} km) in ${city}.`
          )}
          target="_blank"
          rel="noopener noreferrer"
          className="mt-6 rounded-lg bg-[#e11d48] hover:bg-[#be123c] text-white font-bold text-sm py-3 px-4 flex items-center justify-center gap-2"
        >
          <MessageCircle className="w-4 h-4" />
          <span>{t.sales.sendPhotosWhatsapp}</span>
        </a>
      </div>
    </div>
  );
};
