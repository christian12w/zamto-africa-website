import React, { useMemo, useState } from 'react';
import {
  ArrowRight,
  CheckCircle2,
  Map as MapIcon,
  MapPin,
  MessageCircle,
  ShieldCheck,
  Truck,
} from 'lucide-react';
import type {
  CurrencyMode,
  HireSearchCriteria,
  HireVehicle,
  LanguageCode,
  PageRoute,
  SaleVehicle,
  VehicleCategory,
} from '../types';
import {
  IMG_STUDIO_ALPHARD,
  IMG_STUDIO_CX5,
  IMG_STUDIO_HILUX,
  IMG_STUDIO_PRADO,
  IMG_STUDIO_SEDAN,
  IMG_STUDIO_TRUCK,
  TESTIMONIALS,
  ZAMBIA_LOCATIONS,
} from '../data/zambiaData';
import { useI18n } from '../i18n/I18nContext';
import { buildWhatsAppUrl, formatMoney, getZmwPerUsd } from '../utils/format';
import { VehicleImage } from './VehicleImage';
import { LocationMapPicker } from './LocationMapPicker';

interface HomePageProps {
  currency: CurrencyMode;
  lang: LanguageCode;
  hireSearch: HireSearchCriteria;
  onUpdateHireSearch: (next: HireSearchCriteria) => void;
  onSubmitHireSearch: () => void;
  onSelectCategory: (cat: VehicleCategory) => void;
  allHireFleet: HireVehicle[];
  featuredSales: SaleVehicle[];
  onViewHireVehicle: (v: HireVehicle) => void;
  onBookHireVehicle: (v: HireVehicle) => void;
  onViewSaleVehicle: (v: SaleVehicle) => void;
  onNavigate: (route: PageRoute) => void;
}

const CATEGORY_CARDS: {
  category: 'Economy' | 'Sedan' | 'SUV / 4x4' | 'Pickup' | 'Van / Bus' | 'Small Truck';
  startingZmw: number;
  photo: string;
}[] = [
  { category: 'Economy', startingZmw: 800, photo: IMG_STUDIO_CX5 },
  { category: 'Sedan', startingZmw: 850, photo: IMG_STUDIO_SEDAN },
  { category: 'SUV / 4x4', startingZmw: 2000, photo: IMG_STUDIO_PRADO },
  { category: 'Pickup', startingZmw: 3000, photo: IMG_STUDIO_HILUX },
  { category: 'Van / Bus', startingZmw: 1800, photo: IMG_STUDIO_ALPHARD },
  { category: 'Small Truck', startingZmw: 2000, photo: IMG_STUDIO_TRUCK },
];

type FleetFilterTab = 'featured' | 'small' | 'suv' | 'pickup' | 'commercial';

export const HomePage: React.FC<HomePageProps> = ({
  currency,
  hireSearch,
  onUpdateHireSearch,
  onSubmitHireSearch,
  onSelectCategory,
  allHireFleet,
  featuredSales,
  onViewHireVehicle,
  onBookHireVehicle,
  onViewSaleVehicle,
  onNavigate,
}) => {
  const { t } = useI18n();
  const [showMap, setShowMap] = useState(false);
  const [fleetTab, setFleetTab] = useState<FleetFilterTab>('featured');
  const fxRate = getZmwPerUsd();

  const displayedHire = useMemo(() => {
    if (fleetTab === 'small') {
      return allHireFleet.filter((v) => v.category === 'Economy' || v.category === 'Sedan').slice(0, 6);
    }
    if (fleetTab === 'suv') {
      return allHireFleet.filter((v) => v.category === 'SUV / 4x4' || v.category === 'Luxury').slice(0, 6);
    }
    if (fleetTab === 'pickup') {
      return allHireFleet.filter((v) => v.category === 'Pickup');
    }
    if (fleetTab === 'commercial') {
      return allHireFleet.filter((v) => v.category === 'Van / Bus' || v.category === 'Small Truck').slice(0, 6);
    }
    const preferredIds = ['hire-passo', 'hire-cx5', 'hire-rav4', 'hire-prado', 'hire-hilux', 'hire-alphard-gen3'];
    const picks = preferredIds
      .map((id) => allHireFleet.find((v) => v.id === id))
      .filter((v): v is HireVehicle => Boolean(v));
    return picks.length > 0 ? picks : allHireFleet.slice(0, 6);
  }, [allHireFleet, fleetTab]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmitHireSearch();
  };

  return (
    <div>
      {/* 1. CLEAN SPLIT HERO + SINGLE SEARCH CARD */}
      <section className="bg-white border-b border-[#e2e8f0]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-10 lg:py-14">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            <div className="lg:col-span-6 space-y-5">
              <p className="text-xs font-semibold tracking-[0.14em] uppercase text-[#e11d48]">
                {t.home.kicker}
              </p>
              <h1
                className="font-semibold tracking-tight leading-[1.08] text-[#003087] max-w-xl"
                style={{ fontSize: 'clamp(2.2rem, 3.8vw, 3.35rem)' }}
              >
                {t.home.heroTitle}
              </h1>
              <p className="text-sm sm:text-base text-[#475569] leading-relaxed max-w-xl">
                {t.home.heroSub}
              </p>

              <div className="flex flex-wrap items-center gap-3 pt-1">
                <button
                  type="button"
                  onClick={() => onNavigate('hire')}
                  className="rounded-lg bg-[#e11d48] hover:bg-[#be123c] text-white font-semibold text-sm px-6 py-3 transition-colors inline-flex items-center gap-2 whitespace-nowrap"
                >
                  <span>{t.home.browseHireBtn}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() => onNavigate('sales')}
                  className="rounded-lg border border-[#003087] text-[#003087] hover:bg-[#eff6ff] font-semibold text-sm px-5 py-3 transition-colors whitespace-nowrap"
                >
                  {t.home.buyVehicleBtn}
                </button>
                <a
                  href={buildWhatsAppUrl('Hello Zamto Africa, I need quick help with a vehicle.')}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 text-sm font-semibold text-[#475569] hover:text-[#003087] px-2 py-2"
                >
                  <MessageCircle className="w-4 h-4 text-[#e11d48]" />
                  <span>{t.home.whatsappDesk}</span>
                </a>
              </div>
            </div>

            {/* Clean Studio Hero Vehicle Cutout Showcase */}
            <div className="lg:col-span-6 bg-white rounded-2xl border border-[#e2e8f0] p-4 sm:p-6 flex flex-col items-center">
              <div className="w-full aspect-[4/3] max-h-[320px]">
                <VehicleImage
                  src={IMG_STUDIO_PRADO}
                  alt="Toyota Land Cruiser Prado 4x4 studio showcase at Zamto Africa Lusaka"
                  mode="studio"
                />
              </div>
              <div className="w-full pt-3 border-t border-[#f1f5f9] flex flex-wrap items-center justify-between gap-2 text-xs text-[#475569] tabular-nums">
                <span className="font-semibold text-[#003087]">
                  1 USD = ZMW {fxRate.toFixed(2)} ({t.home.dailyRateLabel})
                </span>
                <span>{t.home.lunTransferNote}</span>
              </div>
            </div>
          </div>

          {/* Simple Quick Booking Search Row */}
          <form
            onSubmit={handleSearchSubmit}
            className="mt-8 bg-[#f8fafc] rounded-2xl border border-[#e2e8f0] p-4 sm:p-5 space-y-4"
          >
            <div className="grid grid-cols-1 md:grid-cols-12 gap-3 items-end">
              <div className="md:col-span-3">
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-semibold text-[#475569]">
                    {t.home.pickupPoint}
                  </label>
                  <button
                    type="button"
                    onClick={() => setShowMap((s) => !s)}
                    className="inline-flex items-center gap-1 text-[11px] font-semibold text-[#003087] hover:text-[#e11d48]"
                  >
                    <MapIcon className="w-3.5 h-3.5" />
                    <span>{showMap ? t.home.mapsPickerOpen : t.home.mapsPickerClosed}</span>
                  </button>
                </div>
                <div className="relative">
                  <MapPin className="w-4 h-4 text-[#e11d48] absolute left-3 top-3 pointer-events-none" />
                  <select
                    value={hireSearch.pickupLocation}
                    onChange={(e) =>
                      onUpdateHireSearch({ ...hireSearch, pickupLocation: e.target.value })
                    }
                    className="w-full rounded-lg border border-[#cbd5e1] bg-white pl-9 pr-3 py-2.5 text-sm font-medium focus:border-[#003087] focus:outline-none"
                  >
                    {Array.from(new Set([hireSearch.pickupLocation, ...ZAMBIA_LOCATIONS])).map(
                      (loc) => (
                        <option key={loc} value={loc}>
                          {loc}
                        </option>
                      )
                    )}
                  </select>
                </div>
              </div>

              <div className="md:col-span-3">
                <label className="block text-xs font-semibold text-[#475569] mb-1">
                  {t.home.dropoffPoint}
                </label>
                <div className="relative">
                  <MapPin className="w-4 h-4 text-[#003087] absolute left-3 top-3 pointer-events-none" />
                  <select
                    value={hireSearch.dropoffLocation}
                    onChange={(e) =>
                      onUpdateHireSearch({ ...hireSearch, dropoffLocation: e.target.value })
                    }
                    className="w-full rounded-lg border border-[#cbd5e1] bg-white pl-9 pr-3 py-2.5 text-sm font-medium focus:border-[#003087] focus:outline-none"
                  >
                    {Array.from(
                      new Set(['Same as pickup', hireSearch.dropoffLocation, ...ZAMBIA_LOCATIONS])
                    ).map((loc) => (
                      <option key={loc} value={loc}>
                        {loc === 'Same as pickup' ? t.mapPicker.sameAsPickup : loc}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="md:col-span-2">
                <label className="block text-xs font-semibold text-[#475569] mb-1">
                  {t.home.pickupDate}
                </label>
                <input
                  type="date"
                  value={hireSearch.pickupDate}
                  onChange={(e) =>
                    onUpdateHireSearch({ ...hireSearch, pickupDate: e.target.value })
                  }
                  className="w-full rounded-lg border border-[#cbd5e1] bg-white px-3 py-2.5 text-sm tabular-nums"
                />
              </div>

              <div className="md:col-span-2">
                <label className="block text-xs font-semibold text-[#475569] mb-1">
                  {t.home.returnDate}
                </label>
                <input
                  type="date"
                  value={hireSearch.returnDate}
                  onChange={(e) =>
                    onUpdateHireSearch({ ...hireSearch, returnDate: e.target.value })
                  }
                  className="w-full rounded-lg border border-[#cbd5e1] bg-white px-3 py-2.5 text-sm tabular-nums"
                />
              </div>

              <div className="md:col-span-2">
                <button
                  type="submit"
                  className="w-full rounded-lg bg-[#003087] hover:bg-[#002266] text-white font-semibold text-sm py-2.5 px-3 transition-colors flex items-center justify-center gap-1.5 whitespace-nowrap"
                >
                  <span>{t.home.searchBtn}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>

            {showMap && (
              <LocationMapPicker
                selectedLocation={hireSearch.pickupLocation}
                dropoffLocation={hireSearch.dropoffLocation}
                modeLabel={t.mapPicker.titleDefault}
                onSelectLocation={(label) =>
                  onUpdateHireSearch({ ...hireSearch, pickupLocation: label })
                }
                onSelectDropoffLocation={(label) =>
                  onUpdateHireSearch({ ...hireSearch, dropoffLocation: label })
                }
              />
            )}
          </form>
        </div>
      </section>

      {/* 2. VEHICLE CATEGORIES + STUDIO-CLEAN HIRE FLEET */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 py-12 sm:py-14 space-y-10">
        <div>
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3 mb-6">
            <div>
              <p className="text-xs font-semibold uppercase tracking-[0.14em] text-[#e11d48] mb-1">
                {t.home.classesKicker}
              </p>
              <h2 className="text-2xl sm:text-3xl font-semibold text-[#003087]">
                {t.home.classesTitle}
              </h2>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('hire')}
              className="text-sm font-semibold text-[#003087] hover:text-[#e11d48] inline-flex items-center gap-1"
            >
              <span>
                {t.home.seeAllFleetPrefix} {allHireFleet.length} {t.home.seeAllFleetSuffix}
              </span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
            {CATEGORY_CARDS.map((item) => {
              const catCopy = t.home.categories[item.category];
              return (
                <button
                  key={item.category}
                  type="button"
                  onClick={() => onSelectCategory(item.category)}
                  className="group text-left rounded-xl bg-white border border-[#e2e8f0] hover:border-[#003087] overflow-hidden transition-all duration-200 hover:shadow-md flex flex-col"
                >
                  <div className="aspect-[4/3] w-full bg-white border-b border-[#f1f5f9]">
                    <VehicleImage src={item.photo} alt={catCopy.title} mode="studio" />
                  </div>
                  <div className="p-3.5 flex-1 flex flex-col justify-between">
                    <div>
                      <p className="text-sm font-semibold text-[#0f172a]">{catCopy.title}</p>
                      <p className="text-[11px] text-[#64748b] mt-0.5">{catCopy.subtitle}</p>
                    </div>
                    <p className="text-xs font-bold text-[#e11d48] mt-2 tabular-nums">
                      {t.home.fromLabel} {formatMoney(item.startingZmw, currency)}
                    </p>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Clean Featured Hire Grid */}
        <div>
          <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4 mb-6">
            <div>
              <h2 className="text-2xl sm:text-3xl font-semibold text-[#003087]">
                {t.home.hireSectionTitle}
              </h2>
              <p className="text-xs sm:text-sm text-[#64748b] mt-1">{t.home.hireSectionSub}</p>
            </div>

            <div className="flex items-center gap-1 p-1 bg-[#e2e8f0]/70 rounded-xl overflow-x-auto">
              {(
                [
                  { id: 'featured', label: t.home.tabPopular },
                  { id: 'small', label: t.home.tabSmall },
                  { id: 'suv', label: t.home.tabSuv },
                  { id: 'pickup', label: t.home.tabPickup },
                  { id: 'commercial', label: t.home.tabCommercial },
                ] as const
              ).map((tab) => (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setFleetTab(tab.id)}
                  className={`whitespace-nowrap shrink-0 px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
                    fleetTab === tab.id
                      ? 'bg-white text-[#003087] shadow-sm'
                      : 'text-[#475569] hover:text-[#003087]'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {displayedHire.map((car) => {
              const premiumDaily = car.premiumRateZmw || car.dailyRateZmw;
              return (
                <article
                  key={car.id}
                  className="rounded-2xl bg-white border border-[#e2e8f0] overflow-hidden flex flex-col hover:shadow-lg transition-shadow"
                >
                  <div className="aspect-[4/3] bg-white border-b border-[#f1f5f9]">
                    <VehicleImage src={car.photos[0]?.url} alt={car.name} mode="studio" />
                  </div>
                  <div className="p-5 flex-1 flex flex-col">
                    <p className="text-xs font-medium text-[#64748b] mb-1">
                      {car.fleetClass || car.category} · {car.transmission} · {car.fuel}
                    </p>
                    <h3 className="text-lg font-semibold text-[#003087] mb-1">{car.name}</h3>
                    <p className="text-xs text-[#475569] mb-4 line-clamp-2">{car.description}</p>

                    <div className="mt-auto pt-4 border-t border-[#f1f5f9] flex items-center justify-between gap-2">
                      <div>
                        <p className="text-lg font-bold text-[#e11d48] tabular-nums">
                          {formatMoney(premiumDaily, currency)}
                          <span className="text-xs font-normal text-[#64748b]">
                            {' '}
                            {t.home.perDay}
                          </span>
                        </p>
                        <p className="text-[11px] text-[#64748b] tabular-nums">
                          {car.cityExitRateZmw
                            ? `${t.home.cityExitLabel} ${formatMoney(car.cityExitRateZmw, currency)}`
                            : t.home.withinLusakaOnly}
                        </p>
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => onViewHireVehicle(car)}
                          className="rounded-lg border border-[#cbd5e1] hover:border-[#003087] px-3 py-2 text-xs font-semibold text-[#0f172a]"
                        >
                          {t.home.detailsBtn}
                        </button>
                        <button
                          type="button"
                          onClick={() => onBookHireVehicle(car)}
                          className="rounded-lg bg-[#003087] hover:bg-[#002266] px-3.5 py-2 text-xs font-semibold text-white whitespace-nowrap"
                        >
                          {t.home.bookNowBtn}
                        </button>
                      </div>
                    </div>
                  </div>
                </article>
              );
            })}
          </div>
        </div>
      </section>

      {/* 3. FEATURED VEHICLES FOR SALE */}
      <section className="bg-white border-y border-[#e2e8f0] py-12 sm:py-14">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3 mb-7">
            <div>
              <p className="text-xs font-semibold uppercase tracking-[0.14em] text-[#e11d48] mb-1">
                {t.home.salesKicker}
              </p>
              <h2 className="text-2xl sm:text-3xl font-semibold text-[#003087]">
                {t.home.salesSectionTitle}
              </h2>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('sales')}
              className="text-sm font-semibold text-[#003087] hover:text-[#e11d48] inline-flex items-center gap-1"
            >
              <span>{t.home.viewAllSalesBtn}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {featuredSales.map((car) => (
              <article
                key={car.id}
                className="rounded-2xl bg-white border border-[#e2e8f0] overflow-hidden flex flex-col hover:shadow-lg transition-shadow"
              >
                <div className="aspect-[4/3] bg-white border-b border-[#f1f5f9]">
                  <VehicleImage src={car.photos[0]?.url} alt={car.name} mode="studio" />
                </div>
                <div className="p-5 flex-1 flex flex-col">
                  <p className="text-xs font-medium text-[#64748b] mb-1 tabular-nums">
                    {car.year} · {car.mileageKm.toLocaleString('en-US')} km · {car.fuel}
                  </p>
                  <h3 className="text-lg font-semibold text-[#003087] mb-1">{car.name}</h3>
                  <p className="text-xs text-[#64748b] mb-4">{car.condition}</p>

                  <div className="mt-auto pt-4 border-t border-[#f1f5f9] flex items-center justify-between gap-2">
                    <div>
                      <p className="text-lg font-bold text-[#e11d48] tabular-nums">
                        {formatMoney(car.priceZmw, currency)}
                      </p>
                      <p className="text-[11px] text-[#64748b]">{car.warranty}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <a
                        href={buildWhatsAppUrl(
                          `Hello Zamto Africa, I am interested in buying the ${car.name} (${formatMoney(
                            car.priceZmw,
                            currency
                          )}).`
                        )}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="rounded-lg border border-[#cbd5e1] hover:border-[#003087] p-2 text-[#003087]"
                        aria-label={`WhatsApp about ${car.name}`}
                      >
                        <MessageCircle className="w-4 h-4" />
                      </a>
                      <button
                        type="button"
                        onClick={() => onViewSaleVehicle(car)}
                        className="rounded-lg bg-[#003087] hover:bg-[#002266] px-3.5 py-2 text-xs font-semibold text-white"
                      >
                        {t.home.viewDetailsBtn}
                      </button>
                    </div>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* 4. WHY ZAMTO AFRICA & CLIENT REVIEWS */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 py-12 sm:py-14 space-y-10">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[Truck, ShieldCheck, CheckCircle2].map((Icon, index) => {
            const pillar = t.home.pillars[index];
            if (!pillar) return null;
            return (
              <div
                key={pillar.title}
                className="rounded-2xl bg-white border border-[#e2e8f0] p-6 space-y-2"
              >
                <Icon className="w-5 h-5 text-[#e11d48]" />
                <h3 className="text-base font-semibold text-[#003087]">{pillar.title}</h3>
                <p className="text-sm text-[#475569] leading-relaxed">{pillar.text}</p>
              </div>
            );
          })}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {TESTIMONIALS.map((item) => (
            <blockquote
              key={item.name}
              className="rounded-2xl bg-white border border-[#e2e8f0] p-6 flex flex-col justify-between"
            >
              <p className="text-sm text-[#334155] leading-relaxed mb-4">“{item.quote}”</p>
              <footer className="border-t border-[#f1f5f9] pt-3">
                <p className="text-sm font-semibold text-[#003087]">{item.name}</p>
                <p className="text-xs text-[#64748b]">
                  {item.role} · {item.city}
                </p>
              </footer>
            </blockquote>
          ))}
        </div>
      </section>
    </div>
  );
};
