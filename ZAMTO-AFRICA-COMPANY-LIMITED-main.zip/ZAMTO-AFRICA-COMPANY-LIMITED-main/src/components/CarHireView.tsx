import React, { useMemo, useState } from 'react';
import {
  Calendar,
  Check,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  Compass,
  Download,
  FileText,
  FileUp,
  Filter,
  Map as MapIcon,
  MessageCircle,
  RotateCcw,
  Shield,
  SlidersHorizontal,
  X,
} from 'lucide-react';
import type {
  CurrencyMode,
  CustomerBooking,
  HirePackageTier,
  HireSearchCriteria,
  HireVehicle,
  VehicleCategory,
} from '../types';
import { HIRE_ADDONS, ZAMBIA_LOCATIONS } from '../data/zambiaData';
import { useI18n } from '../i18n/I18nContext';
import { dispatchZamtoNotification } from '../utils/dispatch';
import type { DispatchResult } from '../utils/dispatchTypes';
import {
  buildWhatsAppUrl,
  calcIncludedZambiaVat,
  calculateDays,
  formatDualUsdFirst,
  formatMoney,
  getZmwPerUsd,
  RENTAL_AGREEMENT_PDF,
} from '../utils/format';
import { VehicleImage } from './VehicleImage';
import { LocationMapPicker } from './LocationMapPicker';
import { PaymentCheckoutWidget, type PaymentCompletionResult } from './PaymentCheckoutWidget';
import { SignedRentalContractModal } from './SignedRentalContractModal';

interface CarHireViewProps {
  fleet: HireVehicle[];
  currency: CurrencyMode;
  search: HireSearchCriteria;
  onUpdateSearch: (next: HireSearchCriteria) => void;
  initialCategory: VehicleCategory | 'All';
  selectedVehicle: HireVehicle | null;
  onSelectVehicle: (v: HireVehicle | null) => void;
  bookingVehicle: HireVehicle | null;
  onOpenBooking: (v: HireVehicle | null, selectedAddons?: string[], tier?: HirePackageTier) => void;
  preselectedAddons: string[];
  preselectedTier?: HirePackageTier;
  onCreateBooking: (booking: CustomerBooking) => void;
  onGoToBookings: () => void;
  onOpenAgreement: () => void;
}

const CATEGORIES: (VehicleCategory | 'All')[] = [
  'All',
  'Economy',
  'Sedan',
  'SUV / 4x4',
  'Pickup',
  'Luxury',
  'Van / Bus',
  'Small Truck',
];

function getRateForTier(vehicle: HireVehicle, tier: HirePackageTier): number {
  if (tier === 'City Exit' && vehicle.cityExitRateZmw) return vehicle.cityExitRateZmw;
  if (tier === 'Premium' && vehicle.premiumRateZmw) return vehicle.premiumRateZmw;
  if (tier === 'Basic' && vehicle.basicRateZmw) return vehicle.basicRateZmw;
  return vehicle.premiumRateZmw || vehicle.dailyRateZmw;
}

export const CarHireView: React.FC<CarHireViewProps> = ({
  fleet,
  currency,
  search,
  onUpdateSearch,
  initialCategory,
  selectedVehicle,
  onSelectVehicle,
  bookingVehicle,
  onOpenBooking,
  preselectedAddons,
  preselectedTier = 'Premium',
  onCreateBooking,
  onGoToBookings,
  onOpenAgreement,
}) => {
  const { t } = useI18n();
  const [category, setCategory] = useState<VehicleCategory | 'All'>(initialCategory);
  const [locationFilter, setLocationFilter] = useState<string>('All');
  const [showMapPicker, setShowMapPicker] = useState(false);
  const [transmission, setTransmission] = useState<'All' | 'Automatic' | 'Manual'>('All');
  const [fuel, setFuel] = useState<'All' | 'Diesel' | 'Petrol' | 'Hybrid'>('All');
  const fleetMaxRate = useMemo(
    () => Math.max(4000, ...fleet.map((f) => f.premiumRateZmw || f.dailyRateZmw)),
    [fleet]
  );
  const [minSeats, setMinSeats] = useState<number>(0);
  const [maxDailyZmw, setMaxDailyZmw] = useState<number>(5000);
  const [reqAc, setReqAc] = useState(false);
  const [req4x4, setReq4x4] = useState(false);
  const [reqGps, setReqGps] = useState(false);
  const [reqChildSeat, setReqChildSeat] = useState(false);
  const [reqUnlimitedKm, setReqUnlimitedKm] = useState(false);
  const [cityExitOnly, setCityExitOnly] = useState(false);
  const [cardPhotoIndex, setCardPhotoIndex] = useState<Record<string, number>>({});
  const [showMobileFilters, setShowMobileFilters] = useState(false);

  React.useEffect(() => {
    setCategory(initialCategory);
  }, [initialCategory]);

  React.useEffect(() => {
    setMaxDailyZmw((prev) => (prev < fleetMaxRate ? fleetMaxRate : prev));
  }, [fleetMaxRate]);

  const rentalDays = useMemo(
    () => calculateDays(search.pickupDate, search.returnDate),
    [search.pickupDate, search.returnDate]
  );

  const filteredFleet = useMemo(() => {
    return fleet.filter((car) => {
      if (category !== 'All' && car.category !== category) return false;
      if (
        locationFilter !== 'All' &&
        ZAMBIA_LOCATIONS.includes(locationFilter) &&
        !car.locations.includes(locationFilter)
      ) {
        return false;
      }
      if (cityExitOnly && !car.cityExitRateZmw) return false;
      if (transmission !== 'All' && car.transmission !== transmission) return false;
      if (fuel !== 'All' && car.fuel !== fuel) return false;
      if (minSeats > 0 && car.seats < minSeats) return false;
      if ((car.premiumRateZmw || car.dailyRateZmw) > maxDailyZmw) return false;
      if (reqAc && !car.hasAc) return false;
      if (req4x4 && !car.has4x4) return false;
      if (reqGps && !car.hasGps) return false;
      if (reqChildSeat && !car.hasChildSeatOption) return false;
      if (reqUnlimitedKm && !car.unlimitedMileage) return false;
      return true;
    });
  }, [
    fleet,
    category,
    locationFilter,
    cityExitOnly,
    transmission,
    fuel,
    minSeats,
    maxDailyZmw,
    reqAc,
    req4x4,
    reqGps,
    reqChildSeat,
    reqUnlimitedKm,
  ]);

  const resetFilters = () => {
    setCategory('All');
    setLocationFilter('All');
    setCityExitOnly(false);
    setTransmission('All');
    setFuel('All');
    setMinSeats(0);
    setMaxDailyZmw(fleetMaxRate);
    setReqAc(false);
    setReq4x4(false);
    setReqGps(false);
    setReqChildSeat(false);
    setReqUnlimitedKm(false);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 sm:py-12">
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4 mb-6">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.16em] text-[#e11d48] mb-1 tabular-nums">
            {t.hire.liveTariffPrefix} · USD 1 = ZMW {getZmwPerUsd().toFixed(2)}
          </p>
          <h1 className="text-3xl sm:text-4xl font-semibold text-[#003087]">
            {t.hire.pageTitle}
          </h1>
          <p className="text-sm text-[#475569] mt-1">
            {t.hire.pageSub} ·{' '}
            <span className="font-semibold text-[#003087] tabular-nums">
              {rentalDays} {t.hire.dayTripSelected}
            </span>
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => setShowMapPicker((prev) => !prev)}
            className={`inline-flex items-center justify-center gap-2 rounded-lg border px-4 py-2.5 text-xs sm:text-sm font-semibold transition-colors ${
              showMapPicker
                ? 'bg-[#003087] border-[#003087] text-white'
                : 'border-[#cbd5e1] bg-white text-[#003087] hover:border-[#003087]'
            }`}
          >
            <MapIcon className="w-4 h-4" />
            <span>{showMapPicker ? t.hire.hideMap : t.hire.selectOnMap}</span>
          </button>

          <button
            type="button"
            onClick={onOpenAgreement}
            className="inline-flex items-center justify-center gap-1.5 rounded-lg border border-[#cbd5e1] bg-white hover:border-[#003087] px-3.5 py-2.5 text-xs sm:text-sm font-semibold text-[#0f172a]"
          >
            <FileText className="w-4 h-4 text-[#e11d48]" />
            <span>{t.hire.rentalAgreementBtn}</span>
          </button>

          <button
            type="button"
            onClick={() => setShowMobileFilters((prev) => !prev)}
            className="lg:hidden inline-flex items-center justify-center gap-2 rounded-lg border border-[#cbd5e1] bg-white px-4 py-2.5 text-xs sm:text-sm font-semibold text-[#0f172a]"
          >
            <SlidersHorizontal className="w-4 h-4" />
            <span>{showMobileFilters ? t.hire.hideFilters : t.hire.filtersDatesBtn}</span>
          </button>
        </div>
      </div>

      {showMapPicker && (
        <div className="mb-6">
          <LocationMapPicker
            selectedLocation={
              locationFilter === 'All'
                ? search.pickupLocation || ZAMBIA_LOCATIONS[0]
                : locationFilter
            }
            dropoffLocation={search.dropoffLocation}
            onSelectLocation={(label, details) => {
              onUpdateSearch({ ...search, pickupLocation: label });
              setLocationFilter(ZAMBIA_LOCATIONS.includes(label) ? label : 'All');
              if (details?.isCityExit) {
                setCityExitOnly(true);
              }
            }}
            onSelectDropoffLocation={(label, details) => {
              onUpdateSearch({ ...search, dropoffLocation: label });
              if (details?.isCityExit) {
                setCityExitOnly(true);
              }
            }}
            modeLabel={t.mapPicker.titleDefault}
          />
        </div>
      )}

      {/* Category Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-3 mb-6">
        {CATEGORIES.map((cat) => (
          <button
            key={cat}
            type="button"
            onClick={() => setCategory(cat)}
            className={`whitespace-nowrap shrink-0 rounded-lg px-3.5 py-2 text-xs sm:text-sm font-semibold transition-colors ${
              category === cat
                ? 'bg-[#003087] text-white'
                : 'bg-white border border-[#cbd5e1] text-[#475569] hover:border-[#003087]'
            }`}
          >
            {cat === 'All' ? t.hire.allCat : cat}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8 items-start">
        <aside
          className={`${
            showMobileFilters ? 'block' : 'hidden'
          } lg:block rounded-2xl bg-white border border-[#e2e8f0] p-5 space-y-5 lg:sticky lg:top-28`}
        >
          <div className="flex items-center justify-between">
            <h2 className="font-sans text-sm font-bold uppercase tracking-wider text-[#003087] flex items-center gap-2">
              <Filter className="w-4 h-4 text-[#e11d48]" />
              <span>{t.hire.filterFleetHeading}</span>
            </h2>
            <button
              type="button"
              onClick={resetFilters}
              className="text-xs font-semibold text-[#64748b] hover:text-[#003087] inline-flex items-center gap-1"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              {t.hire.resetBtn}
            </button>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs font-semibold text-[#475569]">
                {t.hire.pickupZoneLabel}
              </label>
              <button
                type="button"
                onClick={() => setShowMapPicker((p) => !p)}
                className="text-[11px] font-semibold text-[#003087] hover:text-[#e11d48]"
              >
                {showMapPicker ? t.hire.hideMap : 'Map'}
              </button>
            </div>
            <select
              value={locationFilter}
              onChange={(e) => {
                const next = e.target.value;
                setLocationFilter(next);
                if (next !== 'All') {
                  onUpdateSearch({ ...search, pickupLocation: next });
                }
              }}
              className="w-full rounded-lg border border-[#cbd5e1] bg-[#f8fafc] px-3 py-2 text-xs font-medium"
            >
              <option value="All">{t.hire.allZonesOption}</option>
              {ZAMBIA_LOCATIONS.map((loc) => (
                <option key={loc} value={loc}>
                  {loc}
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="block text-xs font-semibold text-[#475569] mb-1">
                {t.hire.pickupLabel}
              </label>
              <input
                type="date"
                value={search.pickupDate}
                onChange={(e) => onUpdateSearch({ ...search, pickupDate: e.target.value })}
                className="w-full rounded-lg border border-[#cbd5e1] bg-[#f8fafc] px-2 py-1.5 text-xs tabular-nums"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-[#475569] mb-1">
                {t.hire.returnLabel}
              </label>
              <input
                type="date"
                value={search.returnDate}
                onChange={(e) => onUpdateSearch({ ...search, returnDate: e.target.value })}
                className="w-full rounded-lg border border-[#cbd5e1] bg-[#f8fafc] px-2 py-1.5 text-xs tabular-nums"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="block text-xs font-semibold text-[#475569] mb-1">
                {t.hire.transmissionLabel}
              </label>
              <select
                value={transmission}
                onChange={(e) =>
                  setTransmission(e.target.value as 'All' | 'Automatic' | 'Manual')
                }
                className="w-full rounded-lg border border-[#cbd5e1] bg-[#f8fafc] px-2.5 py-2 text-xs"
              >
                <option value="All">{t.hire.anyOption}</option>
                <option value="Automatic">Automatic</option>
                <option value="Manual">Manual</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#475569] mb-1">
                {t.hire.fuelLabel}
              </label>
              <select
                value={fuel}
                onChange={(e) =>
                  setFuel(e.target.value as 'All' | 'Diesel' | 'Petrol' | 'Hybrid')
                }
                className="w-full rounded-lg border border-[#cbd5e1] bg-[#f8fafc] px-2.5 py-2 text-xs"
              >
                <option value="All">{t.hire.anyOption}</option>
                <option value="Diesel">Diesel</option>
                <option value="Petrol">Petrol</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#475569] mb-1">
              {t.hire.minSeatsLabel}
            </label>
            <select
              value={minSeats}
              onChange={(e) => setMinSeats(Number(e.target.value))}
              className="w-full rounded-lg border border-[#cbd5e1] bg-[#f8fafc] px-3 py-2 text-xs"
            >
              <option value={0}>{t.hire.anySeats}</option>
              <option value={5}>5+ seats</option>
              <option value={7}>7+ seats</option>
              <option value={14}>14-seat Minibus</option>
            </select>
          </div>

          <div>
            <div className="flex items-center justify-between text-xs font-semibold text-[#475569] mb-1">
              <span>{t.hire.maxRateLabel}</span>
              <span className="text-[#003087] tabular-nums">
                {formatMoney(maxDailyZmw, currency)}
              </span>
            </div>
            <input
              type="range"
              min={800}
              max={fleetMaxRate}
              step={100}
              value={maxDailyZmw}
              onChange={(e) => setMaxDailyZmw(Number(e.target.value))}
              className="w-full accent-[#003087]"
            />
          </div>

          <div className="pt-2 border-t border-[#e2e8f0] space-y-2">
            <p className="text-xs font-semibold text-[#475569] mb-1">
              {t.hire.eligibilityHeading}
            </p>
            {[
              {
                label: 'City Exit Eligible (Out of Lusaka)',
                state: cityExitOnly,
                setter: setCityExitOnly,
              },
              { label: 'Air Conditioning (A/C)', state: reqAc, setter: setReqAc },
              { label: 'True 4×4 / AWD Drive', state: req4x4, setter: setReq4x4 },
              { label: 'Offline Zambia GPS', state: reqGps, setter: setReqGps },
              { label: 'Child Seat Compatible', state: reqChildSeat, setter: setReqChildSeat },
              {
                label: 'Unlimited Mileage Eligible',
                state: reqUnlimitedKm,
                setter: setReqUnlimitedKm,
              },
            ].map((item) => (
              <label key={item.label} className="flex items-center gap-2 text-xs text-[#334155] cursor-pointer">
                <input
                  type="checkbox"
                  checked={item.state}
                  onChange={(e) => item.setter(e.target.checked)}
                  className="rounded accent-[#003087]"
                />
                <span>{item.label}</span>
              </label>
            ))}
          </div>

          <div className="rounded-xl bg-[#eff6ff] border border-[#bfdbfe] p-3 text-[11px] text-[#334155] space-y-1">
            <p className="font-bold text-[#003087]">{t.hire.policyBoxTitle}</p>
            <p>{t.hire.policyBoxDriver}</p>
            <p>{t.hire.policyBoxMileage}</p>
          </div>
        </aside>

        <div className="lg:col-span-3">
          <div className="flex flex-wrap items-center justify-between gap-2 mb-4 text-xs text-[#64748b]">
            <span>
              {t.hire.showingVehicles} <strong className="text-[#003087]">{filteredFleet.length}</strong>{' '}
              ({rentalDays}d)
            </span>
            <span>
              LUN Airport Transfer: {formatMoney(500, currency)} · Van/SUV{' '}
              {formatMoney(800, currency)}
            </span>
          </div>

          {filteredFleet.length === 0 ? (
            <div className="rounded-2xl bg-white border border-[#e2e8f0] p-10 text-center">
              <p className="text-base font-semibold text-[#0f172a] mb-2">
                {t.hire.emptyTitle}
              </p>
              <p className="text-sm text-[#64748b] mb-5">{t.hire.emptySub}</p>
              <button
                type="button"
                onClick={resetFilters}
                className="rounded-lg bg-[#003087] text-white text-sm font-semibold px-5 py-2.5"
              >
                {t.hire.resetAllBtn}
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {filteredFleet.map((car) => {
                const activeIdx = cardPhotoIndex[car.id] ?? 0;
                const activePhoto = car.photos[activeIdx] || car.photos[0];
                const premiumDaily = car.premiumRateZmw || car.dailyRateZmw;
                const estTotal = premiumDaily * rentalDays;
                const unavailable = car.status !== 'Available';

                return (
                  <article
                    key={car.id}
                    className="rounded-2xl bg-white border border-[#e2e8f0] overflow-hidden flex flex-col hover:shadow-lg hover:-translate-y-0.5 transition-all duration-200"
                  >
                    <div className="relative aspect-[4/3] bg-white border-b border-[#f1f5f9]">
                      <VehicleImage src={activePhoto?.url} alt={`${car.name} — ${activePhoto?.label}`} />
                      {unavailable && (
                        <div className="absolute inset-0 bg-[#003087]/70 flex items-center justify-center">
                          <span className="bg-white text-[#003087] font-bold text-xs uppercase tracking-wider px-4 py-1.5 rounded">
                            {car.status}
                          </span>
                        </div>
                      )}
                    </div>

                    <div className="px-4 pt-3 flex items-center gap-2 overflow-x-auto">
                      {car.photos.map((photo, idx) => (
                        <button
                          key={photo.label}
                          type="button"
                          onClick={() =>
                            setCardPhotoIndex((prev) => ({ ...prev, [car.id]: idx }))
                          }
                          className={`text-[11px] font-medium px-2 py-1 rounded border transition-colors whitespace-nowrap ${
                            activeIdx === idx
                              ? 'border-[#003087] bg-[#eff6ff] text-[#003087] font-semibold'
                              : 'border-[#e2e8f0] text-[#64748b] hover:border-[#003087]/50'
                          }`}
                        >
                          {photo.label}
                        </button>
                      ))}
                    </div>

                    <div className="p-5 flex-1 flex flex-col">
                      <p className="text-xs font-medium text-[#64748b] mb-1">
                        {car.fleetClass || car.category}
                        {car.modelIntro ? ` · ${car.modelIntro}` : ` · ${car.year}`} ·{' '}
                        {car.transmission} · {car.fuel}
                      </p>
                      <h3 className="text-lg font-semibold text-[#003087] mb-1">{car.name}</h3>
                      <p className="text-xs text-[#64748b] mb-3">
                        {car.seats} seats · {car.bags} bags · {car.engine}
                      </p>
                      <p className="text-xs text-[#475569] mb-4 line-clamp-2">
                        {car.features.slice(0, 4).join(' · ')}
                      </p>

                      <div className="mt-auto pt-4 border-t border-[#f1f5f9]">
                        <div className="flex items-end justify-between gap-2 mb-2">
                          <div>
                            <p className="text-xl font-bold text-[#e11d48] tabular-nums">
                              {formatMoney(premiumDaily, currency)}
                              <span className="text-xs font-normal text-[#64748b]">
                                {' '}
                                {t.hire.perDayPremium}
                              </span>
                            </p>
                            <p className="text-[11px] text-[#475569] tabular-nums font-medium">
                              {car.cityExitRateZmw
                                ? `${t.home.cityExitLabel} ${formatMoney(car.cityExitRateZmw, currency)} / d`
                                : t.home.withinLusakaOnly}
                            </p>
                          </div>
                          <div className="text-right">
                            <p className="text-xs font-semibold text-[#0f172a] tabular-nums">
                              {rentalDays}d: {formatMoney(estTotal, currency)}
                            </p>
                            <p className="text-[11px] text-[#64748b] tabular-nums">
                              {t.hire.depositLabel} {formatMoney(car.depositZmw, currency)}
                            </p>
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-2 mt-3">
                          <button
                            type="button"
                            onClick={() => onSelectVehicle(car)}
                            className="rounded-lg border border-[#cbd5e1] hover:border-[#003087] py-2.5 text-xs font-semibold text-[#0f172a] transition-colors"
                          >
                            {t.hire.packagesSpecsBtn}
                          </button>
                          <button
                            type="button"
                            disabled={unavailable}
                            onClick={() => onOpenBooking(car, [], 'Premium')}
                            className="rounded-lg bg-[#003087] hover:bg-[#002266] disabled:opacity-45 py-2.5 text-xs font-semibold text-white transition-colors"
                          >
                            {unavailable ? car.status : t.hire.bookPayBtn}
                          </button>
                        </div>
                      </div>
                    </div>
                  </article>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {selectedVehicle && (
        <HireDetailModal
          vehicle={selectedVehicle}
          currency={currency}
          search={search}
          onClose={() => onSelectVehicle(null)}
          onOpenAgreement={onOpenAgreement}
          onProceedToBooking={(addons, tier) => {
            const target = selectedVehicle;
            onSelectVehicle(null);
            onOpenBooking(target, addons, tier);
          }}
        />
      )}

      {bookingVehicle && (
        <HireBookingModal
          vehicle={bookingVehicle}
          currency={currency}
          search={search}
          initialAddons={preselectedAddons}
          initialTier={preselectedTier}
          onClose={() => onOpenBooking(null)}
          onOpenAgreement={onOpenAgreement}
          onConfirm={(booking) => {
            onCreateBooking(booking);
          }}
          onGoToBookings={() => {
            onOpenBooking(null);
            onGoToBookings();
          }}
        />
      )}
    </div>
  );
};

const HireDetailModal: React.FC<{
  vehicle: HireVehicle;
  currency: CurrencyMode;
  search: HireSearchCriteria;
  onClose: () => void;
  onOpenAgreement: () => void;
  onProceedToBooking: (addons: string[], tier: HirePackageTier) => void;
}> = ({ vehicle, currency, search, onClose, onOpenAgreement, onProceedToBooking }) => {
  const { t } = useI18n();
  const [photoIdx, setPhotoIdx] = useState(0);
  const [selectedTier, setSelectedTier] = useState<HirePackageTier>('Premium');
  const [selectedAddons, setSelectedAddons] = useState<string[]>([]);
  const [policyTab, setPolicyTab] = useState<'insurance' | 'deposit' | 'fuel' | 'driver'>(
    'insurance'
  );

  const days = calculateDays(search.pickupDate, search.returnDate);
  const dailyRate = getRateForTier(vehicle, selectedTier);
  const baseTotal = dailyRate * days;
  const addonsTotal = selectedAddons.reduce((sum, id) => {
    const addon = HIRE_ADDONS.find((a) => a.id === id);
    if (!addon) return sum;
    return sum + (addon.billing === 'per_day' ? addon.priceZmw * days : addon.priceZmw);
  }, 0);
  const clearTotal = baseTotal + addonsTotal;

  const calendarDays = useMemo(() => {
    const start = new Date(search.pickupDate || '2026-11-26');
    return Array.from({ length: 14 }, (_, i) => {
      const d = new Date(start);
      d.setDate(start.getDate() + i);
      const iso = d.toISOString().split('T')[0];
      return {
        iso,
        label: d.toLocaleDateString('en-ZM', { month: 'short', day: 'numeric' }),
        booked: vehicle.bookedDates.includes(iso),
      };
    });
  }, [search.pickupDate, vehicle.bookedDates]);

  const toggleAddon = (id: string) => {
    setSelectedAddons((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const tierOptions: {
    tier: HirePackageTier;
    rate: number;
    desc: string;
    available: boolean;
  }[] = [
    {
      tier: 'Premium',
      rate: vehicle.premiumRateZmw || vehicle.dailyRateZmw,
      desc: 'Option B Inclusive · Deductible waived · Within Lusaka (120 km/day)',
      available: true,
    },
    {
      tier: 'City Exit',
      rate: vehicle.cityExitRateZmw || 0,
      desc: 'Out of Lusaka travel · 180 km/day (K20/km excess)',
      available: Boolean(vehicle.cityExitRateZmw),
    },
    {
      tier: 'Basic',
      rate: vehicle.basicRateZmw || vehicle.dailyRateZmw,
      desc: 'Option A Base Rate · Standard excess · Within city only',
      available: Boolean(vehicle.basicRateZmw && vehicle.basicRateZmw < (vehicle.premiumRateZmw || vehicle.dailyRateZmw)),
    },
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-4xl w-full max-h-[92vh] overflow-y-auto shadow-2xl border border-[#e2e8f0]">
        <div className="sticky top-0 z-10 bg-white border-b border-[#e2e8f0] px-5 py-4 flex items-center justify-between">
          <div>
            <p className="text-xs font-semibold uppercase tracking-wider text-[#e11d48]">
              Zamto Africa · {vehicle.fleetClass || vehicle.category}
              {vehicle.modelIntro ? ` · ${vehicle.modelIntro}` : ` · ${vehicle.year}`}
            </p>
            <h2 className="text-xl sm:text-2xl font-semibold text-[#003087]">{vehicle.name}</h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close vehicle details"
            className="rounded-lg p-2 hover:bg-[#f1f5f9] text-[#475569]"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 sm:p-6 space-y-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div>
              <div className="relative aspect-[4/3] rounded-xl overflow-hidden bg-white border border-[#e2e8f0]">
                <VehicleImage
                  src={vehicle.photos[photoIdx]?.url}
                  alt={vehicle.photos[photoIdx]?.label || vehicle.name}
                />
                <div className="absolute bottom-3 left-3 bg-[#003087]/90 text-white text-xs px-2.5 py-1 rounded flex items-center gap-1.5">
                  <Compass className="w-3.5 h-3.5 text-[#fda4af]" />
                  <span>{vehicle.photos[photoIdx]?.label}</span>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-2 mt-3">
                {vehicle.photos.map((photo, idx) => (
                  <button
                    key={photo.label}
                    type="button"
                    onClick={() => setPhotoIdx(idx)}
                    className={`rounded-lg overflow-hidden border-2 text-left transition-all ${
                      photoIdx === idx ? 'border-[#e11d48]' : 'border-transparent opacity-75'
                    }`}
                  >
                    <div className="aspect-[4/3]">
                      <VehicleImage src={photo.url} alt={photo.label} />
                    </div>
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-4">
              <p className="text-sm text-[#334155] leading-relaxed">{vehicle.description}</p>

              {/* Hire Package Selector */}
              <div>
                <p className="text-xs font-bold uppercase tracking-wider text-[#003087] mb-2">
                  Select Hire Package Tier
                </p>
                <div className="grid grid-cols-1 gap-2">
                  {tierOptions
                    .filter((t) => t.available)
                    .map((t) => {
                      const active = selectedTier === t.tier;
                      return (
                        <button
                          key={t.tier}
                          type="button"
                          onClick={() => setSelectedTier(t.tier)}
                          className={`rounded-xl border p-3 text-left flex items-center justify-between gap-2 transition-colors ${
                            active
                              ? 'border-[#003087] bg-[#eff6ff]'
                              : 'border-[#e2e8f0] hover:border-[#003087]/50'
                          }`}
                        >
                          <div>
                            <p className="text-xs font-bold text-[#003087]">{t.tier} Package</p>
                            <p className="text-[11px] text-[#64748b]">{t.desc}</p>
                          </div>
                          <span className="text-sm font-bold text-[#e11d48] tabular-nums whitespace-nowrap">
                            {formatMoney(t.rate, currency)} / day
                          </span>
                        </button>
                      );
                    })}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3 rounded-xl bg-[#f8fafc] border border-[#e2e8f0] p-4 text-xs">
                <div>
                  <span className="text-[#64748b] block">Engine</span>
                  <span className="font-semibold text-[#0f172a]">{vehicle.engine}</span>
                </div>
                <div>
                  <span className="text-[#64748b] block">Transmission</span>
                  <span className="font-semibold text-[#0f172a]">{vehicle.transmission}</span>
                </div>
                <div>
                  <span className="text-[#64748b] block">Capacity</span>
                  <span className="font-semibold text-[#0f172a]">
                    {vehicle.seats} seats · {vehicle.bags} bags
                  </span>
                </div>
                <div>
                  <span className="text-[#64748b] block">Mileage Allowance</span>
                  <span className="font-semibold text-[#0f172a]">
                    {selectedTier === 'City Exit' ? '180 km/day (K20/km)' : '120 km/day (K15/km)'}
                  </span>
                </div>
              </div>

              <div>
                <h3 className="text-xs font-bold uppercase tracking-wider text-[#003087] mb-2">
                  Included Features
                </h3>
                <div className="flex flex-wrap gap-2 text-xs text-[#334155]">
                  {vehicle.features.map((feat) => (
                    <span key={feat} className="inline-flex items-center gap-1 mr-2">
                      <Check className="w-3.5 h-3.5 text-[#e11d48]" />
                      {feat}
                    </span>
                  ))}
                </div>
              </div>

              <div>
                <h3 className="text-xs font-bold uppercase tracking-wider text-[#003087] mb-2 flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-[#e11d48]" />
                  <span>14-Day Availability Calendar</span>
                </h3>
                <div className="grid grid-cols-7 gap-1.5 text-[11px] tabular-nums">
                  {calendarDays.map((day) => (
                    <div
                      key={day.iso}
                      className={`rounded py-1.5 px-1 text-center font-medium border ${
                        day.booked
                          ? 'bg-[#fff1f2] border-[#fecdd3] text-[#be123c] line-through'
                          : 'bg-[#eff6ff] border-[#bfdbfe] text-[#003087]'
                      }`}
                    >
                      {day.label}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-5 gap-6 pt-4 border-t border-[#e2e8f0]">
            <div className="lg:col-span-3 space-y-3">
              <h3 className="text-sm font-bold uppercase tracking-wider text-[#003087]">
                Drivers, Airport Transfers &amp; Add-ons
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {HIRE_ADDONS.map((addon) => {
                  const checked = selectedAddons.includes(addon.id);
                  return (
                    <label
                      key={addon.id}
                      className={`rounded-xl border p-3 cursor-pointer transition-colors flex items-start gap-2.5 ${
                        checked
                          ? 'border-[#003087] bg-[#eff6ff]'
                          : 'border-[#e2e8f0] hover:border-[#003087]/50'
                      }`}
                    >
                      <input
                        type="checkbox"
                        checked={checked}
                        onChange={() => toggleAddon(addon.id)}
                        className="mt-1 accent-[#003087]"
                      />
                      <div className="flex-1">
                        <p className="text-xs font-semibold text-[#0f172a]">{addon.label}</p>
                        <p className="text-[11px] text-[#64748b] mt-0.5">{addon.description}</p>
                        <p className="text-xs font-bold text-[#e11d48] mt-1 tabular-nums">
                          +{formatMoney(addon.priceZmw, currency)}{' '}
                          {addon.billing === 'per_day' ? '/ day' : 'flat'}
                        </p>
                      </div>
                    </label>
                  );
                })}
              </div>
            </div>

            <div className="lg:col-span-2 rounded-2xl bg-[#f8fafc] border border-[#e2e8f0] p-5 flex flex-col justify-between">
              <div>
                <h3 className="text-sm font-bold uppercase tracking-wider text-[#003087] mb-3">
                  Clear Price Breakdown ({selectedTier})
                </h3>
                <div className="space-y-2 text-xs text-[#334155] tabular-nums">
                  <div className="flex justify-between">
                    <span>
                      {selectedTier} Hire ({days} {days === 1 ? 'day' : 'days'} ×{' '}
                      {formatMoney(dailyRate, currency)})
                    </span>
                    <span className="font-semibold">{formatMoney(baseTotal, currency)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Coverage</span>
                    <span className="font-semibold text-[#003087]">
                      {selectedTier === 'Basic'
                        ? 'Option A (Standard Excess)'
                        : 'Option B (Deductible Waived)'}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span>Selected Extras ({selectedAddons.length})</span>
                    <span className="font-semibold">{formatMoney(addonsTotal, currency)}</span>
                  </div>
                  <div className="flex justify-between text-[11px] text-[#64748b]">
                    <span>Zambian VAT (16% Included)</span>
                    <span>{formatDualUsdFirst(calcIncludedZambiaVat(clearTotal))}</span>
                  </div>
                  <div className="flex justify-between pt-2 border-t border-[#e2e8f0] text-sm font-bold text-[#e11d48]">
                    <span>Total Hire Estimate (16% VAT Incl.)</span>
                    <span>{formatDualUsdFirst(clearTotal)}</span>
                  </div>
                  <div className="flex justify-between text-[11px] text-[#64748b]">
                    <span>Refundable Security Deposit</span>
                    <span>{formatDualUsdFirst(vehicle.depositZmw)}</span>
                  </div>
                </div>
              </div>

              <div className="mt-5 space-y-2">
                <button
                  type="button"
                  disabled={vehicle.status !== 'Available'}
                  onClick={() => onProceedToBooking(selectedAddons, selectedTier)}
                  className="w-full rounded-lg bg-[#003087] hover:bg-[#002266] disabled:opacity-45 text-white font-semibold text-sm py-3 transition-colors"
                >
                  {t.hire.continueCheckoutBtn}
                </button>
                <a
                  href={buildWhatsAppUrl(
                    `Hello Zamto Africa, I would like to book the ${vehicle.name} (${selectedTier} Package) for ${days} days (${search.pickupDate} to ${search.returnDate}). Estimated hire: ${formatMoney(
                      clearTotal,
                      currency
                    )}.`
                  )}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full rounded-lg border border-[#003087] text-[#003087] hover:bg-[#eff6ff] font-semibold text-xs py-2.5 flex items-center justify-center gap-1.5"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>{t.hire.requestWhatsappBtn}</span>
                </a>
              </div>
            </div>
          </div>

          <div className="rounded-xl border border-[#e2e8f0] p-4 bg-white">
            <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
              <div className="flex flex-wrap gap-2">
                {(
                  [
                    { id: 'insurance', label: 'Option A vs Option B' },
                    { id: 'deposit', label: 'Deposit & Repairs' },
                    { id: 'fuel', label: 'Fuel & Mileage' },
                    { id: 'driver', label: '22+ Driver Rule' },
                  ] as const
                ).map((tab) => (
                  <button
                    key={tab.id}
                    type="button"
                    onClick={() => setPolicyTab(tab.id)}
                    className={`text-xs font-semibold px-3 py-1.5 rounded-lg ${
                      policyTab === tab.id
                        ? 'bg-[#003087] text-white'
                        : 'bg-[#f1f5f9] text-[#475569]'
                    }`}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>
              <button
                type="button"
                onClick={onOpenAgreement}
                className="text-xs font-semibold text-[#e11d48] hover:underline inline-flex items-center gap-1"
              >
                <FileText className="w-3.5 h-3.5" />
                View Official Contract Terms
              </button>
            </div>
            <p className="text-xs text-[#475569] leading-relaxed">
              {policyTab === 'insurance' &&
                'Per Section 4.1 of Zamto Africa Car Rental Agreement: Option A carries standard comprehensive insurance deductible; Option B (Premium & City Exit) waives the deductible/excess for covered damage or theft.'}
              {policyTab === 'deposit' &&
                `A refundable security deposit of ${formatMoney(
                  vehicle.depositZmw,
                  currency
                )} is held and returned cleanly after joint inspection. Unauthorised repairs without Rhodes Park office approval attract a minimum ZMW 500 penalty.`}
              {policyTab === 'fuel' &&
                `${vehicle.mileagePolicy}. Full-to-Full fuel policy applies; vehicles depart Rhodes Park or LUN with verified fuel gauge reading on the Inspection Report.`}
              {policyTab === 'driver' &&
                'All drivers must be at least 22 years old with a valid driving licence held for 2+ years. If unmet or preferred, a Zamto Africa driver is assigned at ZMW 150/day within city (meals included).'}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

const HireBookingModal: React.FC<{
  vehicle: HireVehicle;
  currency: CurrencyMode;
  search: HireSearchCriteria;
  initialAddons: string[];
  initialTier?: HirePackageTier;
  onClose: () => void;
  onOpenAgreement: () => void;
  onConfirm: (booking: CustomerBooking) => void;
  onGoToBookings: () => void;
}> = ({
  vehicle,
  currency,
  search,
  initialAddons,
  initialTier = 'Premium',
  onClose,
  onOpenAgreement,
  onConfirm,
  onGoToBookings,
}) => {
  const { t } = useI18n();
  const [step, setStep] = useState<1 | 2 | 3 | 4>(1);
  const [hireKind, setHireKind] = useState<'Personal' | 'Company'>('Personal');
  const [companyName, setCompanyName] = useState('');
  const [name, setName] = useState('');
  const [dateOfBirth, setDateOfBirth] = useState('');
  const [nrcOrPassport, setNrcOrPassport] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [physicalAddress, setPhysicalAddress] = useState('');
  const [flightOrNotes, setFlightOrNotes] = useState('');

  const [pickupLocation, setPickupLocation] = useState(
    search.pickupLocation || vehicle.locations[0] || ZAMBIA_LOCATIONS[0]
  );
  const [dropoffLocation, setDropoffLocation] = useState(
    search.dropoffLocation === 'Same as pickup' ? pickupLocation : search.dropoffLocation
  );
  const [showMapInModal, setShowMapInModal] = useState(false);

  const [packageTier, setPackageTier] = useState<HirePackageTier>(initialTier);
  const [tripZone, setTripZone] = useState<'Within City' | 'Outside City'>(
    initialTier === 'City Exit' ? 'Outside City' : 'Within City'
  );
  const [licenceNumber, setLicenceNumber] = useState('');
  const [licenceIssueDate, setLicenceIssueDate] = useState('');
  const [licenceFileName, setLicenceFileName] = useState('');
  const [residenceFileName, setResidenceFileName] = useState('');

  const needsDriverFromSearch = search.driverAge.toLowerCase().includes('driver');
  const [addons, setAddons] = useState<string[]>(() => {
    if (needsDriverFromSearch && !initialAddons.includes('assigned-driver')) {
      return [...initialAddons, 'assigned-driver'];
    }
    return initialAddons;
  });
  const [agreementAccepted, setAgreementAccepted] = useState(false);
  const [completedBooking, setCompletedBooking] = useState<CustomerBooking | null>(null);
  const [dispatchResult, setDispatchResult] = useState<DispatchResult | null>(null);
  const [showSignedContract, setShowSignedContract] = useState(false);
  const [draftBookingRef] = useState(
    () => `ZA-${Math.floor(100000 + Math.random() * 900000)}`
  );

  const days = calculateDays(search.pickupDate, search.returnDate);
  const dailyRate = getRateForTier(vehicle, packageTier);
  const addonsCost = addons.reduce((sum, id) => {
    const a = HIRE_ADDONS.find((x) => x.id === id);
    if (!a) return sum;
    return sum + (a.billing === 'per_day' ? a.priceZmw * days : a.priceZmw);
  }, 0);
  const totalZmw = dailyRate * days + addonsCost;
  const vatZmw = calcIncludedZambiaVat(totalZmw);

  const handleTripZoneChange = (nextZone: 'Within City' | 'Outside City') => {
    setTripZone(nextZone);
    if (nextZone === 'Outside City' && vehicle.cityExitRateZmw) {
      setPackageTier('City Exit');
    } else if (nextZone === 'Within City' && packageTier === 'City Exit') {
      setPackageTier('Premium');
    }
  };

  const buildBookingRecord = (
    id: string,
    paymentResult: PaymentCompletionResult
  ): CustomerBooking => {
    const nowIso = new Date().toISOString();
    return {
      id,
      type: 'Car Hire',
      vehicleId: vehicle.id,
      vehicleName: vehicle.name,
      pickupLocation,
      dropoffLocation,
      startDate: search.pickupDate,
      endDate: search.returnDate,
      totalZmw,
      paymentMethod: paymentResult.paymentMethod,
      paymentStatus: paymentResult.paymentStatus,
      paymentTransactionRef: paymentResult.transactionRef,
      paidAmountZmw: paymentResult.paidAmountZmw,
      paidAt: paymentResult.paidAt,
      includeVat: true,
      vatAmountZmw: vatZmw,
      customerName: name || 'Valued Guest',
      customerPhone: phone || '+260',
      customerEmail: email || 'zamtoafrica@gmail.com',
      nrcOrPassport: nrcOrPassport.trim() || 'Verify at handover',
      dateOfBirth: dateOfBirth || undefined,
      licenceNumber: licenceNumber.trim() || 'Verify at handover',
      licenceIssueDate: licenceIssueDate || undefined,
      physicalAddress: physicalAddress.trim() || flightOrNotes.trim() || 'Lusaka Delivery',
      hireKind,
      companyName: hireKind === 'Company' ? companyName.trim() : undefined,
      packageTier,
      tripZone,
      licenceFileName: licenceFileName || 'Provide prior to handover',
      residenceFileName: residenceFileName || 'Provide prior to handover',
      agreementAccepted: true,
      contractSignedAt: nowIso,
      addons: addons.map((idItem) => HIRE_ADDONS.find((x) => x.id === idItem)?.label || idItem),
      status:
        paymentResult.paymentStatus === 'Pending Online Verification'
          ? 'Pending Verification'
          : 'Confirmed',
      createdAt: nowIso,
    };
  };

  const handlePaymentComplete = (paymentResult: PaymentCompletionResult) => {
    const record = buildBookingRecord(draftBookingRef, paymentResult);
    onConfirm(record);
    setCompletedBooking(record);
    setStep(4);

    void dispatchZamtoNotification({
      kind: 'Car Hire Booking',
      reference: record.id,
      customerName: record.customerName,
      customerPhone: record.customerPhone,
      customerEmail: record.customerEmail,
      topicOrVehicle: `${record.vehicleName} (${record.packageTier || 'Premium'})`,
      pickupLocation: record.pickupLocation,
      dropoffLocation: record.dropoffLocation,
      dateRange: `${record.startDate} to ${record.endDate || ''}`,
      totalDisplay: formatDualUsdFirst(record.totalZmw),
      paymentSummary: `${record.paymentStatus} via ${record.paymentMethod} (Ref: ${record.paymentTransactionRef || 'Online'})`,
      message: `ID/Passport: ${record.nrcOrPassport} | Licence: ${record.licenceNumber} | Zone: ${record.tripZone}`,
    }).then((res) => setDispatchResult(res));
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-5 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[92vh] overflow-y-auto shadow-2xl border border-[#e2e8f0]">
        <div className="sticky top-0 z-10 bg-[#003087] text-white px-5 py-4 flex items-center justify-between">
          <div>
            <p className="text-[11px] uppercase tracking-wider text-[#fda4af] font-semibold">
              {t.hire.checkoutTitlePrefix} · {vehicle.name}
            </p>
            <h2 className="text-lg font-semibold text-white">
              {step < 4 ? `${t.hire.stepOf3} ${step} / 3` : t.hire.completedTitle}
            </h2>
          </div>
          <button type="button" onClick={onClose} className="p-1.5 rounded hover:bg-white/10">
            <X className="w-5 h-5" />
          </button>
        </div>

        {step < 4 && (
          <div className="grid grid-cols-3 bg-[#f1f5f9] text-[11px] font-semibold text-center border-b border-[#e2e8f0]">
            {[t.hire.step1Title, t.hire.step2Title, t.hire.step3Title].map(
              (lbl, i) => (
                <div
                  key={lbl}
                  className={`py-2 px-1 ${
                    step === i + 1
                      ? 'bg-white text-[#003087] border-b-2 border-[#e11d48]'
                      : step > i + 1
                      ? 'text-[#003087]'
                      : 'text-[#64748b]'
                  }`}
                >
                  {lbl}
                </div>
              )
            )}
          </div>
        )}

        <div className="p-5 sm:p-6">
          {step === 1 && (
            <div className="space-y-4">
              <div className="flex items-center gap-3 text-xs">
                <span className="font-semibold text-[#475569]">Contract Type:</span>
                {(['Personal', 'Company'] as const).map((kind) => (
                  <button
                    key={kind}
                    type="button"
                    onClick={() => setHireKind(kind)}
                    className={`rounded-lg px-3 py-1.5 font-semibold border ${
                      hireKind === kind
                        ? 'bg-[#003087] text-white border-[#003087]'
                        : 'bg-white text-[#475569] border-[#cbd5e1]'
                    }`}
                  >
                    {kind} Hire
                  </button>
                ))}
              </div>

              {hireKind === 'Company' && (
                <div>
                  <label className="block text-xs font-semibold text-[#475569] mb-1">
                    Company / Organisation Name *
                  </label>
                  <input
                    type="text"
                    value={companyName}
                    onChange={(e) => setCompanyName(e.target.value)}
                    placeholder="e.g. Lusaka Infrastructure Ltd"
                    className="w-full rounded-lg border border-[#cbd5e1] px-3 py-2 text-sm"
                  />
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-[#475569] mb-1">
                    Full Name (Per NRC / Passport) *
                  </label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Chanda Mulenga"
                    className="w-full rounded-lg border border-[#cbd5e1] px-3 py-2 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-[#475569] mb-1">
                    Date of Birth (Must be 22+ or Driver Assigned)
                  </label>
                  <input
                    type="date"
                    value={dateOfBirth}
                    onChange={(e) => setDateOfBirth(e.target.value)}
                    className="w-full rounded-lg border border-[#cbd5e1] px-3 py-2 text-sm tabular-nums"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-[#475569] mb-1">
                    NRC / Passport Number *
                  </label>
                  <input
                    type="text"
                    required
                    value={nrcOrPassport}
                    onChange={(e) => setNrcOrPassport(e.target.value)}
                    placeholder="e.g. 245189/10/1 or Passport No."
                    className="w-full rounded-lg border border-[#cbd5e1] px-3 py-2 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-[#475569] mb-1">
                    Mobile / WhatsApp Number *
                  </label>
                  <input
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="+260 97..."
                    className="w-full rounded-lg border border-[#cbd5e1] px-3 py-2 text-sm"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-[#475569] mb-1">
                    Email Address *
                  </label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="you@company.co.zm"
                    className="w-full rounded-lg border border-[#cbd5e1] px-3 py-2 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-[#475569] mb-1">
                    Physical Address / Hotel Stay
                  </label>
                  <input
                    type="text"
                    value={physicalAddress}
                    onChange={(e) => setPhysicalAddress(e.target.value)}
                    placeholder="e.g. Plot 44 Kabulonga or Radisson Blu"
                    className="w-full rounded-lg border border-[#cbd5e1] px-3 py-2 text-sm"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#475569] mb-1">
                  Flight Number (for LUN Transfers) or Delivery Instructions
                </label>
                <input
                  type="text"
                  value={flightOrNotes}
                  onChange={(e) => setFlightOrNotes(e.target.value)}
                  placeholder="e.g. ET863 arriving 14:20 — deliver to Terminal 2 arrivals"
                  className="w-full rounded-lg border border-[#cbd5e1] px-3 py-2 text-sm"
                />
              </div>

              <div className="flex justify-end pt-2">
                <button
                  type="button"
                  disabled={!name.trim() || !phone.trim() || !nrcOrPassport.trim()}
                  onClick={() => setStep(2)}
                  className="rounded-lg bg-[#003087] hover:bg-[#002266] disabled:opacity-40 text-white text-sm font-semibold px-6 py-2.5 inline-flex items-center gap-1.5"
                >
                  <span>Next: Licence &amp; Zone</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-xs font-semibold text-[#475569]">
                      Pickup / Delivery Zone
                    </label>
                    <button
                      type="button"
                      onClick={() => setShowMapInModal((m) => !m)}
                      className="text-[11px] font-semibold text-[#003087] hover:text-[#e11d48]"
                    >
                      {showMapInModal ? 'Close Map' : 'Pick on Map'}
                    </button>
                  </div>
                  <select
                    value={pickupLocation}
                    onChange={(e) => setPickupLocation(e.target.value)}
                    className="w-full rounded-lg border border-[#cbd5e1] px-3 py-2 text-xs"
                  >
                    {Array.from(new Set([pickupLocation, ...ZAMBIA_LOCATIONS])).map((loc) => (
                      <option key={loc} value={loc}>
                        {loc}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-[#475569] mb-1">
                    Drop-off Point
                  </label>
                  <select
                    value={dropoffLocation}
                    onChange={(e) => setDropoffLocation(e.target.value)}
                    className="w-full rounded-lg border border-[#cbd5e1] px-3 py-2 text-xs"
                  >
                    {Array.from(new Set([dropoffLocation, ...ZAMBIA_LOCATIONS])).map((loc) => (
                      <option key={loc} value={loc}>
                        {loc}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {showMapInModal && (
                <LocationMapPicker
                  selectedLocation={pickupLocation}
                  dropoffLocation={dropoffLocation}
                  onSelectLocation={(label, details) => {
                    setPickupLocation(label);
                    if (details?.isCityExit && vehicle.cityExitRateZmw) {
                      handleTripZoneChange('Outside City');
                    }
                  }}
                  onSelectDropoffLocation={(label, details) => {
                    setDropoffLocation(label);
                    if (details?.isCityExit && vehicle.cityExitRateZmw) {
                      handleTripZoneChange('Outside City');
                    }
                  }}
                  modeLabel="Google Maps Pickup & Drop-off Pin Selector"
                />
              )}

              {/* Trip Scope & Package Tier */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-[#475569] mb-1">
                    Travel Area (Agreement Section 4.1)
                  </label>
                  <select
                    value={tripZone}
                    onChange={(e) =>
                      handleTripZoneChange(e.target.value as 'Within City' | 'Outside City')
                    }
                    className="w-full rounded-lg border border-[#cbd5e1] px-3 py-2 text-xs font-medium"
                  >
                    <option value="Within City">Within City (Lusaka · 120 km/day)</option>
                    <option value="Outside City" disabled={!vehicle.cityExitRateZmw}>
                      {vehicle.cityExitRateZmw
                        ? 'Outside City (City Exit · 180 km/day)'
                        : 'Outside City (Unavailable on Passo)'}
                    </option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#475569] mb-1">
                    Package Rate
                  </label>
                  <select
                    value={packageTier}
                    onChange={(e) => {
                      const next = e.target.value as HirePackageTier;
                      setPackageTier(next);
                      setTripZone(next === 'City Exit' ? 'Outside City' : 'Within City');
                    }}
                    className="w-full rounded-lg border border-[#cbd5e1] px-3 py-2 text-xs font-semibold text-[#003087]"
                  >
                    {vehicle.premiumRateZmw && (
                      <option value="Premium">
                        Premium (Option B) —{' '}
                        {formatMoney(vehicle.premiumRateZmw, currency)}/d
                      </option>
                    )}
                    {vehicle.cityExitRateZmw && (
                      <option value="City Exit">
                        City Exit (Out of Lusaka) —{' '}
                        {formatMoney(vehicle.cityExitRateZmw, currency)}/d
                      </option>
                    )}
                    {vehicle.basicRateZmw &&
                      vehicle.basicRateZmw < (vehicle.premiumRateZmw || vehicle.dailyRateZmw) && (
                        <option value="Basic">
                          Basic (Option A) — {formatMoney(vehicle.basicRateZmw, currency)}/d
                        </option>
                      )}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-[#475569] mb-1">
                    Driver&apos;s Licence Number
                  </label>
                  <input
                    type="text"
                    value={licenceNumber}
                    onChange={(e) => setLicenceNumber(e.target.value)}
                    placeholder="RTSA / Int'l Licence No."
                    className="w-full rounded-lg border border-[#cbd5e1] px-3 py-2 text-xs"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-[#475569] mb-1">
                    Date of First Issue (2+ yrs required)
                  </label>
                  <input
                    type="date"
                    value={licenceIssueDate}
                    onChange={(e) => setLicenceIssueDate(e.target.value)}
                    className="w-full rounded-lg border border-[#cbd5e1] px-3 py-2 text-xs tabular-nums"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="rounded-xl border border-dashed border-[#003087]/40 bg-[#f8fafc] p-3">
                  <label className="block text-xs font-semibold text-[#003087] mb-1">
                    Upload Driving Licence
                  </label>
                  <label className="inline-flex items-center gap-2 rounded-lg bg-white border border-[#cbd5e1] hover:border-[#003087] px-3 py-1.5 text-xs font-semibold text-[#0f172a] cursor-pointer">
                    <FileUp className="w-3.5 h-3.5 text-[#e11d48]" />
                    <span className="truncate max-w-[160px]">
                      {licenceFileName || 'Photo / PDF'}
                    </span>
                    <input
                      type="file"
                      accept="image/*,.pdf"
                      onChange={(e) => setLicenceFileName(e.target.files?.[0]?.name || '')}
                      className="hidden"
                    />
                  </label>
                </div>

                <div className="rounded-xl border border-dashed border-[#003087]/40 bg-[#f8fafc] p-3">
                  <label className="block text-xs font-semibold text-[#003087] mb-1">
                    Proof of Residence / Hotel Booking
                  </label>
                  <label className="inline-flex items-center gap-2 rounded-lg bg-white border border-[#cbd5e1] hover:border-[#003087] px-3 py-1.5 text-xs font-semibold text-[#0f172a] cursor-pointer">
                    <FileUp className="w-3.5 h-3.5 text-[#e11d48]" />
                    <span className="truncate max-w-[160px]">
                      {residenceFileName || 'Utility / Hotel PDF'}
                    </span>
                    <input
                      type="file"
                      accept="image/*,.pdf"
                      onChange={(e) => setResidenceFileName(e.target.files?.[0]?.name || '')}
                      className="hidden"
                    />
                  </label>
                </div>
              </div>

              <div>
                <p className="text-xs font-semibold text-[#475569] mb-2">
                  Assigned Driver (+K150/day if under 22 or &lt;2 yrs licence) &amp; Add-ons
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {HIRE_ADDONS.map((addon) => {
                    const active = addons.includes(addon.id);
                    return (
                      <label
                        key={addon.id}
                        className="flex items-center justify-between gap-2 rounded-lg border border-[#e2e8f0] px-3 py-2 text-xs cursor-pointer"
                      >
                        <span className="flex items-center gap-2">
                          <input
                            type="checkbox"
                            checked={active}
                            onChange={() =>
                              setAddons((prev) =>
                                prev.includes(addon.id)
                                  ? prev.filter((x) => x !== addon.id)
                                  : [...prev, addon.id]
                              )
                            }
                            className="accent-[#003087]"
                          />
                          <span className="line-clamp-1">{addon.label}</span>
                        </span>
                        <span className="font-semibold tabular-nums whitespace-nowrap">
                          +{formatMoney(addon.priceZmw, currency)}
                        </span>
                      </label>
                    );
                  })}
                </div>
              </div>

              <div className="flex items-center justify-between pt-2">
                <button
                  type="button"
                  onClick={() => setStep(1)}
                  className="text-xs font-semibold text-[#475569] inline-flex items-center gap-1"
                >
                  <ChevronLeft className="w-4 h-4" /> Back
                </button>
                <button
                  type="button"
                  onClick={() => setStep(3)}
                  className="rounded-lg bg-[#003087] hover:bg-[#002266] text-white text-sm font-semibold px-6 py-2.5 inline-flex items-center gap-1.5"
                >
                  <span>Next: Payment &amp; Agreement</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-4">
              <div className="rounded-xl bg-[#f8fafc] border border-[#e2e8f0] p-4 text-xs space-y-1.5 tabular-nums">
                <div className="flex justify-between gap-3">
                  <span className="text-[#64748b] shrink-0">Pickup → Drop-off</span>
                  <span className="font-semibold text-[#003087] text-right">
                    {pickupLocation} → {dropoffLocation}
                  </span>
                </div>
                <div className="flex justify-between gap-2">
                  <span className="text-[#64748b]">
                    {vehicle.name} · {packageTier} ({days} {days === 1 ? 'day' : 'days'})
                  </span>
                  <span className="font-semibold text-right">
                    {formatDualUsdFirst(dailyRate * days)}
                  </span>
                </div>
                <div className="flex justify-between gap-2">
                  <span className="text-[#64748b]">Extras &amp; Driver ({addons.length})</span>
                  <span className="font-semibold text-right">{formatDualUsdFirst(addonsCost)}</span>
                </div>
                <div className="flex justify-between gap-2 text-[#475569]">
                  <span>Zambian VAT (16% VAT-Inclusive)</span>
                  <span className="font-semibold text-right">{formatDualUsdFirst(vatZmw)}</span>
                </div>
                <div className="flex justify-between gap-2 pt-2 border-t border-[#e2e8f0] text-sm font-bold text-[#e11d48]">
                  <span>Total Payable (16% VAT Incl.)</span>
                  <span className="text-right">{formatDualUsdFirst(totalZmw)}</span>
                </div>
              </div>

              {/* Digital Car Rental Agreement Sign-off */}
              <div className="rounded-xl bg-[#eff6ff] border border-[#bfdbfe] p-3.5 space-y-2 text-xs">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <button
                    type="button"
                    onClick={onOpenAgreement}
                    className="inline-flex items-center gap-1.5 font-bold text-[#003087] hover:text-[#e11d48]"
                  >
                    <FileText className="w-4 h-4" />
                    <span>Review Zamto Africa Car Rental Agreement</span>
                  </button>
                  <a
                    href={RENTAL_AGREEMENT_PDF}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 font-semibold text-[#e11d48] hover:underline"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Blank PDF (11 Pages)</span>
                  </a>
                </div>
                <label className="flex items-start gap-2 cursor-pointer text-[#334155]">
                  <input
                    type="checkbox"
                    checked={agreementAccepted}
                    onChange={(e) => setAgreementAccepted(e.target.checked)}
                    className="mt-0.5 accent-[#003087]"
                  />
                  <span>
                    I confirm the driver satisfies the <strong>22+ age &amp; 2+ years licence</strong>{' '}
                    rule (or Zamto Assigned Driver is added), accept the{' '}
                    <strong>Zamto Africa Company Limited Car Rental Agreement</strong>, and will
                    co-sign the joint handover Vehicle Inspection Report.
                  </span>
                </label>
              </div>

              <PaymentCheckoutWidget
                totalZmw={totalZmw}
                depositZmw={vehicle.depositZmw}
                currency={currency}
                defaultPhone={phone}
                defaultName={name}
                defaultEmail={email}
                bookingRef={draftBookingRef}
                vehicleName={vehicle.name}
                requireAgreementBeforePay={true}
                agreementAccepted={agreementAccepted}
                onBeforeRedirect={(pendingMeta) => {
                  try {
                    const draft = buildBookingRecord(draftBookingRef, {
                      paymentMethod: pendingMeta.paymentMethod,
                      paymentStatus: 'Pending Online Verification',
                      transactionRef: pendingMeta.txRef,
                      paidAmountZmw: 0,
                      paidAt: new Date().toISOString(),
                    });
                    sessionStorage.setItem(
                      'zamto_pending_checkout_v1',
                      JSON.stringify({
                        mode: 'create',
                        booking: draft,
                        payOption: pendingMeta.payOption,
                        amountDueZmw: pendingMeta.amountDueZmw,
                      })
                    );
                  } catch {
                    // Ignore session storage errors
                  }
                }}
                onPaymentCompleted={handlePaymentComplete}
              />

              <div className="flex items-center justify-start pt-1">
                <button
                  type="button"
                  onClick={() => setStep(2)}
                  className="text-xs font-semibold text-[#475569] inline-flex items-center gap-1"
                >
                  <ChevronLeft className="w-4 h-4" /> {t.hire.backLabel}
                </button>
              </div>
            </div>
          )}

          {step === 4 && completedBooking && (
            <div className="space-y-5 py-2">
              <div className="text-center space-y-2">
                <div className="w-12 h-12 rounded-full bg-[#eff6ff] text-[#003087] flex items-center justify-center mx-auto">
                  <CheckCircle2 className="w-7 h-7" />
                </div>
                <p className="font-mono text-xs font-bold text-[#e11d48]">{completedBooking.id}</p>
                <h3 className="text-xl font-semibold text-[#003087]">
                  {t.hire.completedTitle}
                </h3>
                <p className="text-sm text-[#475569]">
                  {completedBooking.vehicleName} · {completedBooking.packageTier} ·{' '}
                  {completedBooking.paymentStatus} ({completedBooking.paymentMethod})
                </p>
                {completedBooking.paymentTransactionRef && (
                  <p className="font-mono text-xs text-[#003087]">
                    Transaction Ref: {completedBooking.paymentTransactionRef}
                  </p>
                )}
              </div>

              <div className="rounded-xl border border-[#bfdbfe] bg-[#f8fafc] p-3.5 text-xs space-y-1 text-left">
                <p className="font-bold text-[#003087]">{t.hire.dispatchConfirmedTitle}</p>
                <p className="text-[#475569]">
                  Email (zamtoafrica@gmail.com):{' '}
                  <strong>
                    {dispatchResult?.emailSent
                      ? 'Delivered via Mail Server'
                      : 'Ready / Queued via Desk Dispatch'}
                  </strong>{' '}
                  · WhatsApp (+260 572 213 038):{' '}
                  <strong>
                    {dispatchResult?.whatsappCloudSent
                      ? 'Delivered via WhatsApp API'
                      : 'Instant Link Ready'}
                  </strong>
                </p>
              </div>

              {/* Post-Checkout Rental Agreement & Download Box */}
              <div className="rounded-xl border border-[#003087]/25 bg-[#eff6ff] p-4 space-y-3 text-left">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="text-xs font-bold uppercase tracking-wider text-[#003087] flex items-center gap-1.5">
                      <FileText className="w-4 h-4 text-[#e11d48]" />
                      <span>{t.hire.reviewAgreement}</span>
                    </p>
                    <p className="text-xs text-[#334155] mt-1">
                      Signed by <strong>{completedBooking.customerName}</strong> (ID:{' '}
                      {completedBooking.nrcOrPassport}) ·{' '}
                      <strong>{completedBooking.pickupLocation}</strong>.
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <button
                    type="button"
                    onClick={() => setShowSignedContract(true)}
                    className="rounded-lg bg-[#e11d48] hover:bg-[#be123c] text-white text-xs font-bold py-2.5 px-3 inline-flex items-center justify-center gap-1.5"
                  >
                    <FileText className="w-4 h-4" />
                    <span>{t.hire.openSignedAgreement}</span>
                  </button>
                  <a
                    href={RENTAL_AGREEMENT_PDF}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="rounded-lg bg-white border border-[#003087] text-[#003087] hover:bg-[#f8fafc] text-xs font-bold py-2.5 px-3 inline-flex items-center justify-center gap-1.5"
                  >
                    <Download className="w-4 h-4" />
                    <span>{t.hire.downloadOfficialPdf}</span>
                  </a>
                </div>
              </div>

              <div className="rounded-xl bg-[#f8fafc] border border-[#e2e8f0] p-4 text-xs text-[#475569] text-left space-y-1">
                <p className="flex items-center gap-1.5 font-semibold text-[#003087]">
                  <Shield className="w-4 h-4 text-[#e11d48]" />
                  <span>{t.hire.policyBoxTitle}</span>
                </p>
                <p>{t.hire.policyBoxDriver}</p>
              </div>

              <div className="flex flex-col sm:flex-row gap-2.5 justify-center pt-1">
                <button
                  type="button"
                  onClick={onGoToBookings}
                  className="rounded-lg bg-[#003087] text-white text-sm font-semibold px-5 py-2.5"
                >
                  {t.hire.openMyBookings}
                </button>
                <a
                  href={
                    dispatchResult?.whatsappUrl ||
                    buildWhatsAppUrl(
                      `Hello Zamto Africa, my booking reference is ${completedBooking.id} (${completedBooking.paymentStatus}, Ref: ${completedBooking.paymentTransactionRef || 'Desk'}) for ${vehicle.name} (${search.pickupDate} - ${search.returnDate}).`
                    )
                  }
                  target="_blank"
                  rel="noopener noreferrer"
                  className="rounded-lg border border-[#003087] text-[#003087] text-sm font-semibold px-5 py-2.5 inline-flex items-center justify-center gap-1.5"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>{t.hire.sendRefWhatsapp}</span>
                </a>
              </div>
            </div>
          )}
        </div>
      </div>

      {showSignedContract && completedBooking && (
        <SignedRentalContractModal
          booking={completedBooking}
          currency={currency}
          onClose={() => setShowSignedContract(false)}
        />
      )}
    </div>
  );
};
