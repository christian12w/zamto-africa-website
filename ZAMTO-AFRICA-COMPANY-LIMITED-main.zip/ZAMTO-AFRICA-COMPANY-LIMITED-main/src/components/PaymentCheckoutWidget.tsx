import React, { useEffect, useState } from 'react';
import {
  Building2,
  CheckCircle2,
  CreditCard,
  Loader2,
  Lock,
  Smartphone,
} from 'lucide-react';
import type { CurrencyMode } from '../types';
import { useI18n } from '../i18n/I18nContext';
import {
  calcIncludedZambiaVat,
  formatDualUsdFirst,
  formatMoney,
  getZmwPerUsd,
} from '../utils/format';

export type PaymentRailId =
  | 'Airtel Money'
  | 'MTN Mobile Money'
  | 'Zamtel Kwacha'
  | 'Visa / Mastercard'
  | 'Bank EFT / Zanaco';

type ChannelGroup = 'momo' | 'card' | 'eft';
type MomoOperatorRail = 'Airtel Money' | 'MTN Mobile Money' | 'Zamtel Kwacha';

export interface PaymentCompletionResult {
  paymentMethod: PaymentRailId;
  paymentStatus: 'Paid' | 'Deposit Paid' | 'Pending Online Verification';
  transactionRef: string;
  paidAmountZmw: number;
  paidAt: string;
}

interface GatewayConfigStatus {
  lencoConfigured: boolean;
  lencoPublicConfigured: boolean;
  lencoEnv?: 'sandbox' | 'production';
  livePaymentsReady: boolean;
}

interface LencoInlineOptions {
  key: string;
  reference: string;
  email: string;
  amount: number;
  currency: string;
  channels?: string[];
  customer?: {
    firstName?: string;
    lastName?: string;
    phone?: string;
  };
  onSuccess?: (response: { reference?: string }) => void;
  onConfirmationPending?: () => void;
  onClose?: () => void;
}

declare global {
  interface Window {
    LencoPay?: {
      getPaid: (options: LencoInlineOptions) => void;
    };
  }
}

function loadLencoInlineScript(env: 'sandbox' | 'production'): Promise<void> {
  if (typeof window !== 'undefined' && window.LencoPay?.getPaid) {
    return Promise.resolve();
  }
  const scriptSrc =
    env === 'sandbox'
      ? 'https://pay.sandbox.lenco.co/js/v1/inline.js'
      : 'https://pay.lenco.co/js/v1/inline.js';

  return new Promise((resolve, reject) => {
    const existing = document.querySelector(`script[src="${scriptSrc}"]`) as HTMLScriptElement | null;
    if (existing) {
      if (window.LencoPay?.getPaid) {
        resolve();
        return;
      }
      existing.addEventListener('load', () => resolve(), { once: true });
      existing.addEventListener('error', () => reject(new Error('Failed to load Lenco checkout')), {
        once: true,
      });
      return;
    }

    const script = document.createElement('script');
    script.src = scriptSrc;
    script.async = true;
    script.onload = () => resolve();
    script.onerror = () => reject(new Error('Failed to load Lenco checkout'));
    document.head.appendChild(script);
  });
}

function detectOperatorFromPhone(raw: string): MomoOperatorRail | null {
  const digits = raw.replace(/\D/g, '');
  let national = digits;
  if (digits.startsWith('260')) national = digits.slice(3);
  else if (digits.startsWith('0')) national = digits.slice(1);

  if (national.startsWith('97') || national.startsWith('77')) return 'Airtel Money';
  if (national.startsWith('96') || national.startsWith('76')) return 'MTN Mobile Money';
  if (national.startsWith('95') || national.startsWith('75') || national.startsWith('55')) {
    return 'Zamtel Kwacha';
  }
  return null;
}

const MOMO_OPERATORS: {
  id: MomoOperatorRail;
  label: string;
  prefixes: string;
  accentText: string;
}[] = [
  {
    id: 'Airtel Money',
    label: 'Airtel Money',
    prefixes: '097 · 077',
    accentText: 'text-[#e11d48]',
  },
  {
    id: 'MTN Mobile Money',
    label: 'MTN MoMo',
    prefixes: '096 · 076',
    accentText: 'text-[#92400e]',
  },
  {
    id: 'Zamtel Kwacha',
    label: 'Zamtel Money',
    prefixes: '095 · 075',
    accentText: 'text-[#166534]',
  },
];

interface PaymentCheckoutWidgetProps {
  totalZmw: number;
  depositZmw?: number;
  currency: CurrencyMode;
  defaultPhone?: string;
  defaultName?: string;
  defaultEmail?: string;
  bookingRef?: string;
  vehicleName?: string;
  requireAgreementBeforePay?: boolean;
  agreementAccepted?: boolean;
  onBeforeRedirect?: (pendingMeta: {
    txRef: string;
    paymentMethod: PaymentRailId;
    payOption: 'full' | 'deposit';
    amountDueZmw: number;
  }) => void;
  onPaymentCompleted: (result: PaymentCompletionResult) => void;
  submitLabel?: string;
}

export const PaymentCheckoutWidget: React.FC<PaymentCheckoutWidgetProps> = ({
  totalZmw,
  depositZmw,
  currency,
  defaultPhone = '',
  defaultName = '',
  defaultEmail = '',
  bookingRef,
  vehicleName,
  requireAgreementBeforePay = false,
  agreementAccepted = true,
  onPaymentCompleted,
  submitLabel,
}) => {
  const { t } = useI18n();
  const initialOp = detectOperatorFromPhone(defaultPhone) || 'Airtel Money';

  const [channelGroup, setChannelGroup] = useState<ChannelGroup>('momo');
  const [momoOperator, setMomoOperator] = useState<MomoOperatorRail>(initialOp);
  const [payOption, setPayOption] = useState<'full' | 'deposit'>('full');
  const [mobileNumber, setMobileNumber] = useState(defaultPhone || '097');
  const [bankRef, setBankRef] = useState('');
  const [gatewayConfig, setGatewayConfig] = useState<GatewayConfigStatus | null>(null);
  const [processingState, setProcessingState] = useState<
    'idle' | 'awaiting_pin' | 'verifying' | 'error'
  >('idle');
  const [statusMessage, setStatusMessage] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [pendingTx, setPendingTx] = useState<{
    txRef: string;
    transactionId?: string;
  } | null>(null);

  useEffect(() => {
    let active = true;
    fetch('/api/payments/config')
      .then((res) => (res.ok ? res.json() : null))
      .then((data: GatewayConfigStatus | null) => {
        if (active && data) setGatewayConfig(data);
      })
      .catch(() => undefined);
    return () => {
      active = false;
    };
  }, []);

  const selectedRail: PaymentRailId =
    channelGroup === 'momo'
      ? momoOperator
      : channelGroup === 'card'
      ? 'Visa / Mastercard'
      : 'Bank EFT / Zanaco';

  const minDeposit = depositZmw && depositZmw < totalZmw ? depositZmw : Math.round(totalZmw * 0.3);
  const amountDueNow = payOption === 'full' ? totalZmw : minDeposit;
  const includedVatZmw = calcIncludedZambiaVat(amountDueNow);

  const resetTransientState = () => {
    setProcessingState('idle');
    setErrorMsg('');
    setStatusMessage('');
    setPendingTx(null);
  };

  const handlePhoneChange = (nextPhone: string) => {
    setMobileNumber(nextPhone);
    const detected = detectOperatorFromPhone(nextPhone);
    if (detected) {
      setMomoOperator(detected);
    }
  };

  const verifyLencoTransaction = async (
    txRef: string,
    transactionId?: string
  ): Promise<'verified' | 'failed' | 'pending'> => {
    try {
      const qs = new URLSearchParams({ provider: 'lenco', txRef });
      if (transactionId) qs.set('transactionId', transactionId);
      const res = await fetch(`/api/payments/verify?${qs.toString()}`);
      if (!res.ok) return 'pending';
      const data = (await res.json()) as {
        verified?: boolean;
        transactionRef?: string;
        status?: string;
        reasonForFailure?: string | null;
      };
      if (data.verified) {
        onPaymentCompleted({
          paymentMethod: selectedRail,
          paymentStatus: payOption === 'full' ? 'Paid' : 'Deposit Paid',
          transactionRef: data.transactionRef || txRef,
          paidAmountZmw: amountDueNow,
          paidAt: new Date().toISOString(),
        });
        setProcessingState('idle');
        return 'verified';
      }
      if (data.status === 'failed') {
        setProcessingState('error');
        setErrorMsg(
          data.reasonForFailure ||
            'Payment was declined or expired. Check your balance and PIN and try again.'
        );
        return 'failed';
      }
      return 'pending';
    } catch {
      return 'pending';
    }
  };

  const triggerPayment = async () => {
    setErrorMsg('');
    setStatusMessage('');

    if (requireAgreementBeforePay && !agreementAccepted) {
      setProcessingState('error');
      setErrorMsg('Please accept the Rental Agreement checkbox above before continuing.');
      return;
    }

    if (channelGroup === 'momo') {
      const cleanDigits = mobileNumber.replace(/\D/g, '');
      if (cleanDigits.length < 9) {
        setProcessingState('error');
        setErrorMsg('Enter a valid Zambian Mobile Money number (e.g. 097, 096, or 095).');
        return;
      }
    }

    setProcessingState('verifying');

    try {
      const res = await fetch('/api/payments/initiate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          rail: selectedRail,
          amountZmw: amountDueNow,
          currency,
          exchangeRate: getZmwPerUsd(),
          customerName: defaultName || 'Zamto Guest',
          customerPhone: mobileNumber || defaultPhone || '+260',
          customerEmail: defaultEmail || '',
          bookingRef: bookingRef || `ZA-${Date.now().toString().slice(-6)}`,
          vehicleName: vehicleName || 'Zamto Africa Vehicle Hire',
          bankRef,
        }),
      });

      const data = (await res.json()) as {
        error?: string;
        mode?: string;
        txRef?: string;
        transactionId?: string;
        publicKey?: string;
        env?: 'sandbox' | 'production';
        amount?: number;
        currency?: string;
        channels?: string[];
        customer?: {
          email: string;
          phone?: string;
          firstName?: string;
          lastName?: string;
        };
        paymentStatus?: 'Paid' | 'Deposit Paid' | 'Pending Online Verification';
        paidAmountZmw?: number;
        message?: string;
      };

      if (!res.ok) {
        setProcessingState('error');
        setErrorMsg(data.error || 'Could not initiate payment. Please verify your details.');
        return;
      }

      if (data.mode === 'lenco_inline' && data.publicKey && data.txRef) {
        try {
          await loadLencoInlineScript(data.env === 'sandbox' ? 'sandbox' : 'production');
          if (!window.LencoPay?.getPaid) {
            throw new Error('Lenco checkout window could not be opened.');
          }
          const txRef = data.txRef;
          setPendingTx({ txRef });
          setProcessingState('awaiting_pin');
          setStatusMessage('Complete your card or online payment in the Lenco window...');

          window.LencoPay.getPaid({
            key: data.publicKey,
            reference: txRef,
            email: data.customer?.email || defaultEmail || 'zamtoafrica@gmail.com',
            amount: data.amount || Math.round(amountDueNow * 100) / 100,
            currency: data.currency || 'ZMW',
            channels: data.channels || ['card', 'mobile-money'],
            customer: {
              firstName: data.customer?.firstName,
              lastName: data.customer?.lastName,
              phone: data.customer?.phone,
            },
            onSuccess: (response) => {
              const verifiedRef = response?.reference || txRef;
              setProcessingState('verifying');
              void verifyLencoTransaction(verifiedRef).then((outcome) => {
                if (outcome === 'pending') {
                  setProcessingState('awaiting_pin');
                  setStatusMessage(
                    `Payment submitted (${verifiedRef}). Click "Check Payment Status" to confirm settlement.`
                  );
                }
              });
            },
            onConfirmationPending: () => {
              setProcessingState('awaiting_pin');
              setStatusMessage(
                `Confirmation pending (${txRef}). Click "Check Payment Status" once completed.`
              );
            },
            onClose: () => {
              setProcessingState((curr) => (curr === 'awaiting_pin' ? 'idle' : curr));
            },
          });
          return;
        } catch (err) {
          setProcessingState('error');
          setErrorMsg(
            err instanceof Error
              ? err.message
              : 'Could not launch Lenco card checkout. Try Mobile Money or Zanaco EFT.'
          );
          return;
        }
      }

      if (data.mode === 'live_momo_pending' && data.txRef) {
        setProcessingState('awaiting_pin');
        setStatusMessage(data.message || t.payment.awaitingPinMsg);
        setPendingTx({ txRef: data.txRef, transactionId: data.transactionId });

        let finalOutcome: 'verified' | 'failed' | 'pending' = 'pending';
        for (let attempt = 0; attempt < 8; attempt++) {
          await new Promise((r) => setTimeout(r, 3000));
          finalOutcome = await verifyLencoTransaction(data.txRef, data.transactionId);
          if (finalOutcome === 'verified' || finalOutcome === 'failed') break;
        }
        if (finalOutcome === 'pending') {
          setStatusMessage(
            `Prompt sent (${data.txRef}). Enter your Mobile Money PIN on your phone, then click "Check Payment Status".`
          );
        }
        return;
      }

      onPaymentCompleted({
        paymentMethod: selectedRail,
        paymentStatus: data.paymentStatus || 'Pending Online Verification',
        transactionRef: data.txRef || `REQ-${Date.now().toString().slice(-6)}`,
        paidAmountZmw: Number(data.paidAmountZmw || 0),
        paidAt: new Date().toISOString(),
      });
      setProcessingState('idle');
    } catch {
      setProcessingState('error');
      setErrorMsg('Network error reaching payment server. Try again or use another online method.');
    }
  };

  const tabs: { id: ChannelGroup; label: string; sub: string; icon: React.ElementType }[] = [
    { id: 'momo', label: 'Mobile Money', sub: 'Airtel · MTN · Zamtel', icon: Smartphone },
    { id: 'card', label: 'Visa / Mastercard', sub: 'Lenco Online Card', icon: CreditCard },
    { id: 'eft', label: 'Zanaco EFT', sub: 'Online Bank Transfer', icon: Building2 },
  ];

  const isActionBusy = processingState === 'awaiting_pin' || processingState === 'verifying';
  const cardReady = Boolean(gatewayConfig?.lencoConfigured && gatewayConfig?.lencoPublicConfigured);

  return (
    <div className="space-y-4">
      {/* Amount Summary (USD First, then ZMW) & Full / 30% Deposit Switch */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#e2e8f0]">
        <div>
          <p className="text-xs font-medium text-[#64748b]">
            {payOption === 'full' ? 'Total payable online' : '30% online booking deposit'}
          </p>
          <div className="flex flex-wrap items-baseline gap-2 mt-0.5 tabular-nums">
            <span className="text-xl font-bold text-[#003087]">
              {formatMoney(amountDueNow, 'USD')}
            </span>
            <span className="text-sm font-semibold text-[#475569]">
              / {formatMoney(amountDueNow, 'ZMW')}
            </span>
          </div>
          <p className="text-[11px] text-[#64748b] mt-0.5 tabular-nums">
            16% Zambian VAT inclusive ({formatDualUsdFirst(includedVatZmw)})
          </p>
        </div>

        <div className="inline-flex rounded-lg bg-[#f1f5f9] p-1 self-start sm:self-auto">
          <button
            type="button"
            onClick={() => setPayOption('full')}
            className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-colors tabular-nums ${
              payOption === 'full'
                ? 'bg-white text-[#003087] shadow-sm'
                : 'text-[#475569] hover:text-[#0f172a]'
            }`}
          >
            Full: {formatMoney(totalZmw, 'USD')} ({formatMoney(totalZmw, 'ZMW')})
          </button>
          <button
            type="button"
            onClick={() => setPayOption('deposit')}
            className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-colors tabular-nums ${
              payOption === 'deposit'
                ? 'bg-white text-[#003087] shadow-sm'
                : 'text-[#475569] hover:text-[#0f172a]'
            }`}
          >
            30%: {formatMoney(minDeposit, 'USD')} ({formatMoney(minDeposit, 'ZMW')})
          </button>
        </div>
      </div>

      {/* 3 Online Payment Channel Tabs */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const active = channelGroup === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => {
                setChannelGroup(tab.id);
                resetTransientState();
              }}
              className={`rounded-xl border px-3 py-2.5 text-left transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#003087] ${
                active
                  ? 'border-[#003087] bg-[#eff6ff] ring-1 ring-[#003087]'
                  : 'border-[#e2e8f0] bg-white hover:border-[#94a3b8]'
              }`}
            >
              <div className="flex items-center gap-2">
                <Icon className={`w-4 h-4 shrink-0 ${active ? 'text-[#e11d48]' : 'text-[#003087]'}`} />
                <span className="text-xs font-bold text-[#0f172a] truncate">{tab.label}</span>
              </div>
              <p className="text-[11px] text-[#64748b] mt-1 truncate">{tab.sub}</p>
            </button>
          );
        })}
      </div>

      {/* Active Online Payment Workspace */}
      <div className="rounded-xl border border-[#e2e8f0] bg-white p-4 sm:p-5 space-y-4">
        {channelGroup === 'momo' && (
          <div className="space-y-4">
            <div>
              <p className="text-xs font-semibold text-[#334155] mb-2">Select Mobile Network</p>
              <div className="grid grid-cols-3 gap-2">
                {MOMO_OPERATORS.map((op) => {
                  const selected = momoOperator === op.id;
                  return (
                    <button
                      key={op.id}
                      type="button"
                      onClick={() => {
                        setMomoOperator(op.id);
                        setErrorMsg('');
                      }}
                      className={`rounded-lg border px-2.5 py-2 text-left transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#003087] ${
                        selected
                          ? 'border-[#003087] bg-[#eff6ff] ring-1 ring-[#003087]'
                          : 'border-[#e2e8f0] bg-white hover:border-[#cbd5e1]'
                      }`}
                    >
                      <span className="block text-xs font-bold text-[#0f172a] truncate">
                        {op.label}
                      </span>
                      <p
                        className={`text-[11px] font-medium mt-0.5 tabular-nums ${
                          selected ? op.accentText : 'text-[#64748b]'
                        }`}
                      >
                        {op.prefixes}
                      </p>
                    </button>
                  );
                })}
              </div>
            </div>

            <div>
              <label
                htmlFor="lenco-momo-phone"
                className="block text-xs font-semibold text-[#334155] mb-1.5"
              >
                {momoOperator} Phone Number
              </label>
              <input
                id="lenco-momo-phone"
                type="tel"
                value={mobileNumber}
                onChange={(e) => handlePhoneChange(e.target.value)}
                placeholder="097 / 096 / 095..."
                className="w-full rounded-lg border border-[#cbd5e1] bg-[#f8fafc] focus:bg-white focus:border-[#003087] focus:outline-none px-3.5 py-2.5 text-sm font-medium tabular-nums text-[#0f172a]"
              />
              <p className="text-xs text-[#64748b] mt-1.5">
                {gatewayConfig?.lencoConfigured
                  ? `You will receive an instant ${momoOperator} PIN approval prompt on this handset via Lenco.`
                  : `Submits your booking for ${momoOperator} online settlement via Lenco Zambia.`}
              </p>
            </div>
          </div>
        )}

        {channelGroup === 'card' && (
          <div className="space-y-2.5">
            <div className="flex items-center justify-between gap-2">
              <p className="text-sm font-bold text-[#003087]">Visa &amp; Mastercard Checkout</p>
              <span className="text-xs font-semibold text-[#475569] tabular-nums">
                {formatDualUsdFirst(amountDueNow)}
              </span>
            </div>
            <p className="text-xs text-[#475569] leading-relaxed">
              {cardReady
                ? 'Opens the encrypted Lenco checkout window supporting Visa, Mastercard, and local mobile wallets with instant verification.'
                : 'Online card checkout activates once Lenco card checkout keys are enabled. You can pay immediately online via Airtel/MTN/Zamtel Mobile Money or Zanaco EFT.'}
            </p>
          </div>
        )}

        {channelGroup === 'eft' && (
          <div className="space-y-3">
            <div className="text-xs text-[#334155] space-y-1">
              <p className="font-bold text-[#003087]">Zamto Africa Company Limited — Zanaco EFT</p>
              <p className="text-[#475569]">
                Rhodes Park Branch · Online USD &amp; ZMW bank transfers accepted (16% VAT inclusive).
              </p>
            </div>
            <div>
              <label
                htmlFor="zamto-eft-ref"
                className="block text-xs font-semibold text-[#334155] mb-1.5"
              >
                {t.payment.bankRefLabel}
              </label>
              <input
                id="zamto-eft-ref"
                type="text"
                value={bankRef}
                onChange={(e) => setBankRef(e.target.value)}
                placeholder="e.g. ZNC-9021844"
                className="w-full rounded-lg border border-[#cbd5e1] bg-[#f8fafc] focus:bg-white focus:border-[#003087] focus:outline-none px-3.5 py-2 text-xs text-[#0f172a]"
              />
            </div>
          </div>
        )}

        {processingState === 'awaiting_pin' && (
          <div className="rounded-lg bg-[#eff6ff] border border-[#bfdbfe] p-3.5 space-y-2.5 text-[#003087]">
            <div className="flex items-start gap-2 text-xs font-semibold">
              <Loader2 className="w-4 h-4 animate-spin text-[#e11d48] shrink-0 mt-0.5" />
              <span>{statusMessage || t.payment.awaitingPinMsg}</span>
            </div>
            {pendingTx && (
              <div className="flex flex-wrap gap-2">
                <button
                  type="button"
                  onClick={() =>
                    void verifyLencoTransaction(pendingTx.txRef, pendingTx.transactionId)
                  }
                  className="rounded-lg bg-[#003087] hover:bg-[#002266] text-white text-xs font-semibold px-3.5 py-2"
                >
                  Check Payment Status
                </button>
                <button
                  type="button"
                  onClick={resetTransientState}
                  className="rounded-lg border border-[#cbd5e1] bg-white hover:border-[#003087] text-[#003087] text-xs font-semibold px-3.5 py-2"
                >
                  Change Method / Retry
                </button>
              </div>
            )}
          </div>
        )}

        {processingState === 'verifying' && (
          <div className="rounded-lg bg-[#f8fafc] border border-[#cbd5e1] p-3 flex items-center gap-2 text-xs font-semibold text-[#003087]">
            <Loader2 className="w-4 h-4 animate-spin text-[#003087]" />
            <span>{t.payment.verifyingMsg}</span>
          </div>
        )}

        {processingState === 'error' && errorMsg && (
          <p className="text-xs font-semibold text-[#be123c] bg-[#fff1f2] border border-[#fecdd3] rounded-lg px-3.5 py-2.5">
            {errorMsg}
          </p>
        )}

        <button
          type="button"
          onClick={triggerPayment}
          disabled={isActionBusy}
          className="w-full rounded-lg bg-[#e11d48] hover:bg-[#be123c] disabled:opacity-55 text-white text-sm font-bold py-3 px-4 inline-flex items-center justify-center gap-2 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#003087] tabular-nums"
        >
          {isActionBusy ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              <span>{t.payment.processingBtn}</span>
            </>
          ) : (
            <>
              <CheckCircle2 className="w-4 h-4" />
              <span>
                {submitLabel ||
                  `Pay ${formatMoney(amountDueNow, 'USD')} (${formatMoney(amountDueNow, 'ZMW')}) via ${
                    channelGroup === 'momo'
                      ? momoOperator
                      : channelGroup === 'card'
                      ? 'Lenco Card'
                      : 'Zanaco EFT'
                  }`}
              </span>
            </>
          )}
        </button>

        <div className="flex items-center justify-between text-[11px] text-[#64748b] pt-1">
          <span className="inline-flex items-center gap-1">
            <Lock className="w-3 h-3 text-[#003087]" />
            <span>
              {gatewayConfig?.lencoConfigured
                ? `Secured by Lenco Zambia${gatewayConfig.lencoEnv === 'sandbox' ? ' (Sandbox)' : ''}`
                : 'Secured by Zamto Africa · Lenco Zambia'}
            </span>
          </span>
          <span>16% VAT INCLUSIVE</span>
        </div>
      </div>
    </div>
  );
};
