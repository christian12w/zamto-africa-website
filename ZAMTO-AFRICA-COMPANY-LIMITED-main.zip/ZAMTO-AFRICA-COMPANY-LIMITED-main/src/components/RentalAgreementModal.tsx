import React from 'react';
import { Download, FileText, ShieldCheck, X } from 'lucide-react';
import {
  HEAD_OFFICE_ADDRESS,
  RENTAL_AGREEMENT_PDF,
  SUPPORT_PHONE_DISPLAY,
  ZAMTO_LOGO_URL,
} from '../utils/format';

interface RentalAgreementModalProps {
  onClose: () => void;
}

export const RentalAgreementModal: React.FC<RentalAgreementModalProps> = ({ onClose }) => {
  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-[#e2e8f0]">
        <div className="sticky top-0 z-10 bg-[#003087] text-white px-5 py-4 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <img
              src={ZAMTO_LOGO_URL}
              alt="Zamto Africa"
              className="h-10 w-auto object-contain bg-white rounded-lg px-2 py-1 shrink-0"
            />
            <div>
              <p className="text-[11px] font-semibold uppercase tracking-wider text-[#fda4af]">
                Zamto Africa Company Limited
              </p>
              <h2 className="text-lg sm:text-xl font-semibold text-white">
                Official Car Rental Agreement &amp; Inspection Terms
              </h2>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close rental agreement"
            className="p-2 rounded-lg hover:bg-white/10"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 sm:p-6 space-y-5 text-xs sm:text-sm text-[#334155]">
          <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl bg-[#eff6ff] border border-[#bfdbfe] p-4">
            <div className="flex items-start gap-2.5">
              <FileText className="w-5 h-5 text-[#003087] shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold text-[#003087]">
                  Download Official PDF Form (11 Pages incl. Inspection Report)
                </p>
                <p className="text-xs text-[#475569]">
                  Incorporated under Companies Act No. 10 of 2017 · {HEAD_OFFICE_ADDRESS}
                </p>
              </div>
            </div>
            <a
              href={RENTAL_AGREEMENT_PDF}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 rounded-lg bg-[#e11d48] hover:bg-[#be123c] text-white text-xs font-bold px-4 py-2.5"
            >
              <Download className="w-4 h-4" />
              <span>Open / Download PDF</span>
            </a>
          </div>

          <section className="space-y-2">
            <h3 className="font-bold text-[#003087] uppercase tracking-wider text-xs">
              1. Supporting Documents &amp; Driver Eligibility
            </h3>
            <ul className="list-disc pl-5 space-y-1 text-xs leading-relaxed">
              <li>Valid Government ID (Passport for international visitors or Zambian NRC).</li>
              <li>Proof of residence (utility bill receipt, hotel booking, or signed tenant agreement).</li>
              <li>Full, valid driving licence held for at least 2 years (expired or provisional licences are not accepted).</li>
              <li>
                Renter &amp; operators must be aged <strong>22 years and above</strong>. If unmet (or
                upon request for international guests), a Zamto Africa driver is assigned at{' '}
                <strong>ZMW 150/day</strong> within city (driver&apos;s meals included).
              </li>
            </ul>
          </section>

          <section className="space-y-2">
            <h3 className="font-bold text-[#003087] uppercase tracking-wider text-xs">
              2. Mileage Allowance &amp; Package Insurance Options (Section 4.1)
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="rounded-xl border border-[#e2e8f0] p-3.5 bg-[#f8fafc]">
                <p className="font-semibold text-[#003087] mb-1">
                  Option A — Base Rate (Basic Package)
                </p>
                <p className="text-[#475569]">
                  Within Lusaka (120 km/day allowance; ZMW 15/km excess). Renter assumes standard
                  comprehensive insurance deductible/excess.
                </p>
              </div>
              <div className="rounded-xl border border-[#e2e8f0] p-3.5 bg-[#f8fafc]">
                <p className="font-semibold text-[#003087] mb-1">
                  Option B — Inclusive Rate (Premium / City Exit)
                </p>
                <p className="text-[#475569]">
                  Owner waives insurance deductible/excess for covered damage or theft. City Exit
                  allows out-of-town travel (180 km/day allowance; ZMW 20/km excess).
                </p>
              </div>
            </div>
          </section>

          <section className="space-y-2">
            <h3 className="font-bold text-[#003087] uppercase tracking-wider text-xs">
              3. Vehicle Inspection, Repairs, Accidents &amp; Jurisdiction
            </h3>
            <ul className="list-disc pl-5 space-y-1 text-xs leading-relaxed">
              <li>
                Both parties complete and sign the <strong>Vehicle Inspection Report</strong> at
                handover and return covering exterior, interior, tyres, fluid levels, spare wheel,
                triangle, first aid kit, and fuel level.
              </li>
              <li>
                Unauthorised repairs or replacements without office approval attract a minimum
                penalty of <strong>ZMW 500.00</strong>. In case of breakdown, accident, or theft,
                notify Zamto Africa immediately at <strong>{SUPPORT_PHONE_DISPLAY}</strong> and the
                Zambia Police.
              </li>
              <li>
                Governed by and construed in accordance with the Laws of the Republic of Zambia.
              </li>
            </ul>
          </section>

          <div className="flex items-center justify-between pt-3 border-t border-[#e2e8f0]">
            <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#003087]">
              <ShieldCheck className="w-4 h-4 text-[#e11d48]" />
              Accepted electronically during online checkout
            </span>
            <button
              type="button"
              onClick={onClose}
              className="rounded-lg bg-[#003087] text-white text-xs font-semibold px-4 py-2"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
