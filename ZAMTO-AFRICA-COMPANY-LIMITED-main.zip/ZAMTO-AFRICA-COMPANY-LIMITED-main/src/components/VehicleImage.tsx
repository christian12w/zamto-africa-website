import React, { useEffect, useState } from 'react';
import { CarFront } from 'lucide-react';

interface VehicleImageProps {
  src: string;
  alt: string;
  className?: string;
  mode?: 'auto' | 'studio' | 'cover';
}

export const VehicleImage: React.FC<VehicleImageProps> = ({
  src,
  alt,
  className = '',
  mode = 'auto',
}) => {
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    setFailed(false);
  }, [src]);

  const isStudioCutout =
    mode === 'studio' ||
    (mode === 'auto' &&
      (src?.includes('studio_') || src?.startsWith('data:image/png')));

  if (failed || !src) {
    return (
      <div
        className={`flex flex-col items-center justify-center bg-[#f8fafc] border border-[#e2e8f0] text-[#003087] w-full h-full ${className}`}
        role="img"
        aria-label={alt}
      >
        <CarFront className="w-10 h-10 mb-2 text-[#e11d48]" />
        <span className="text-xs font-semibold tracking-wider uppercase text-[#475569]">
          Zamto Africa
        </span>
      </div>
    );
  }

  if (isStudioCutout) {
    return (
      <div className="w-full h-full bg-white flex items-center justify-center overflow-hidden p-2 sm:p-3">
        <img
          src={src}
          alt={alt}
          referrerPolicy="no-referrer"
          onError={() => setFailed(true)}
          className={`w-full h-full object-contain object-center mix-blend-multiply transition-transform duration-300 ${className}`}
        />
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={alt}
      referrerPolicy="no-referrer"
      onError={() => setFailed(true)}
      className={`w-full h-full object-cover ${className}`}
    />
  );
};
