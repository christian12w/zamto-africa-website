import React, { useState } from 'react';
import {
  ArrowRight,
  Briefcase,
  CheckCircle2,
  ChevronDown,
  Facebook,
  FileText,
  Globe,
  Instagram,
  MapPin,
  MessageCircle,
  Phone,
  PlaneLanding,
  ShieldCheck,
  UserCheck,
  Video,
  X,
} from 'lucide-react';
import type { BlogArticle, CurrencyMode, PageRoute } from '../types';
import {
  AIRPORT_TRANSFER_RATES,
  ZAMBIA_BLOG_POSTS,
  ZAMBIA_BRANCHES,
} from '../data/zambiaData';
import { useI18n } from '../i18n/I18nContext';
import { dispatchZamtoNotification } from '../utils/dispatch';
import type { DispatchResult } from '../utils/dispatchTypes';
import {
  buildWhatsAppUrl,
  formatMoney,
  getZmwPerUsd,
  HEAD_OFFICE_ADDRESS,
  RENTAL_AGREEMENT_PDF,
  SOCIAL_LINKS,
  SUPPORT_EMAIL,
  SUPPORT_PHONE_DISPLAY,
} from '../utils/format';
import { VehicleImage } from './VehicleImage';
import { LocationMapPicker } from './LocationMapPicker';

/* ---------------- LOCATIONS PAGE: SINGLE LUSAKA HQ + ALL-LUSAKA DELIVERY MAP ---------------- */

export const LocationsPage: React.FC<{
  onHireFromBranch: (pickupLabel: string, dropoffLabel?: string) => void;
}> = ({ onHireFromBranch }) => {
  const { t } = useI18n();
  const [pickupZoneLabel, setPickupZoneLabel] = useState(
    'Rhodes Park Head Office (Katapola Rd & Great East Rd)'
  );
  const [dropoffZoneLabel, setDropoffZoneLabel] = useState(
    "Lusaka — Kenneth Kaunda Int'l Airport (LUN)"
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-10 sm:py-14 space-y-10">
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.16em] text-[#e11d48] mb-1">
            {t.locations.kicker}
          </p>
          <h1 className="text-3xl sm:text-4xl font-semibold text-[#003087]">
            {t.locations.title}
          </h1>
          <p className="text-sm text-[#475569] mt-1 max-w-3xl">
            <strong>{HEAD_OFFICE_ADDRESS}</strong> — {t.locations.subtitle}
          </p>
        </div>

        <button
          type="button"
          onClick={() => onHireFromBranch(pickupZoneLabel, dropoffZoneLabel)}
          className="rounded-lg bg-[#e11d48] hover:bg-[#be123c] text-white text-xs sm:text-sm font-bold px-5 py-3 inline-flex items-center gap-2 shrink-0"
        >
          <span>{t.locations.hireSelectedBtn}</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

      {/* Embedded Google Maps Pickup & Drop-off Route Planner */}
      <LocationMapPicker
        selectedLocation={pickupZoneLabel}
        dropoffLocation={dropoffZoneLabel}
        onSelectLocation={setPickupZoneLabel}
        onSelectDropoffLocation={setDropoffZoneLabel}
        modeLabel={t.mapPicker.titleDefault}
      />

      {/* Zone Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {ZAMBIA_BRANCHES.map((branch) => (
          <article
            key={branch.id}
            className="rounded-2xl bg-white border border-[#e2e8f0] p-5 flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-semibold uppercase tracking-wider text-[#e11d48]">
                  {branch.kind}
                </span>
                <MapPin className="w-4 h-4 text-[#003087]" />
              </div>
              <h2 className="text-base font-semibold text-[#003087] mb-1">{branch.name}</h2>
              <p className="text-xs text-[#64748b] mb-2">{branch.address}</p>
              <p className="text-xs text-[#475569] font-medium mb-3">{branch.hours}</p>
              <ul className="text-xs text-[#475569] space-y-1 mb-4">
                {branch.services.map((srv) => (
                  <li key={srv}>· {srv}</li>
                ))}
              </ul>
            </div>
            <div className="flex items-center justify-between pt-3 border-t border-[#f1f5f9]">
              <span className="text-xs font-semibold text-[#003087]">{branch.phone}</span>
              <button
                type="button"
                onClick={() => onHireFromBranch(pickupZoneLabel, dropoffZoneLabel)}
                className="text-xs font-semibold text-[#003087] hover:text-[#e11d48]"
              >
                {t.locations.bookDeliveryBtn} →
              </button>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
};

/* ---------------- SERVICES PAGE WITH OFFICIAL AIRPORT TRANSFER RATES ---------------- */

export const ServicesPage: React.FC<{
  onNavigate: (route: PageRoute) => void;
  currency: CurrencyMode;
  onOpenAgreement: () => void;
}> = ({ onNavigate, currency, onOpenAgreement }) => {
  const { t } = useI18n();
  const icons = [PlaneLanding, Briefcase, UserCheck, Globe];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-10 sm:py-14 space-y-10">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.16em] text-[#e11d48] mb-1">
            {t.services.kicker}
          </p>
          <h1 className="text-3xl sm:text-4xl font-semibold text-[#003087]">
            {t.services.title}
          </h1>
        </div>
        <button
          type="button"
          onClick={onOpenAgreement}
          className="inline-flex items-center gap-2 rounded-lg border border-[#003087] text-[#003087] hover:bg-[#eff6ff] text-xs font-semibold px-4 py-2.5"
        >
          <FileText className="w-4 h-4" />
          <span>{t.services.viewPdfBtn}</span>
        </button>
      </div>

      {/* Airport Transfer Table */}
      <div className="rounded-2xl bg-[#003087] text-white p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
        {AIRPORT_TRANSFER_RATES.map((rate) => (
          <div key={rate.tier} className="rounded-xl bg-white/10 border border-white/15 p-5">
            <p className="text-xs uppercase tracking-wider font-semibold text-[#fda4af]">
              {t.services.airportBannerTag}
            </p>
            <div className="flex items-baseline justify-between gap-2 mt-1 mb-2">
              <h2 className="text-xl font-semibold text-white">{rate.tier}</h2>
              <span className="text-xl font-bold text-[#fda4af] tabular-nums">
                {formatMoney(rate.priceZmw, currency)}
              </span>
            </div>
            <p className="text-xs text-[#e2e8f0] mb-1">{rate.includes}</p>
            <p className="text-xs text-[#cbd5e1]">
              {rate.overtimeDay} · {rate.overtimeNight}
            </p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {t.services.cards.map((srv, idx) => {
          const Icon = icons[idx] || Globe;
          return (
            <article
              key={srv.title}
              className="rounded-2xl bg-white border border-[#e2e8f0] p-6 flex flex-col justify-between"
            >
              <div>
                <div className="w-10 h-10 rounded-xl bg-[#eff6ff] text-[#003087] flex items-center justify-center mb-4">
                  <Icon className="w-5 h-5" />
                </div>
                <h2 className="text-xl font-semibold text-[#003087] mb-2">{srv.title}</h2>
                <p className="text-sm text-[#475569] leading-relaxed mb-4">{srv.desc}</p>
                <ul className="space-y-1.5 text-xs text-[#334155] mb-6">
                  {srv.points.map((p) => (
                    <li key={p} className="flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-[#e11d48] shrink-0" />
                      <span>{p}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <div className="flex flex-wrap gap-2 pt-4 border-t border-[#f1f5f9]">
                <button
                  type="button"
                  onClick={() => onNavigate('hire')}
                  className="rounded-lg bg-[#003087] text-white text-xs font-semibold px-4 py-2.5"
                >
                  {t.services.browseFleetBtn}
                </button>
                <a
                  href={buildWhatsAppUrl(`Hello Zamto Africa, I want a quote for ${srv.title}.`)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="rounded-lg border border-[#003087] text-[#003087] text-xs font-semibold px-4 py-2.5 inline-flex items-center gap-1.5"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>{t.services.requestQuoteBtn}</span>
                </a>
              </div>
            </article>
          );
        })}
      </div>
    </div>
  );
};

/* ---------------- ABOUT US PAGE ---------------- */

export const AboutPage: React.FC<{ onNavigate: (route: PageRoute) => void }> = ({
  onNavigate,
}) => {
  const { t } = useI18n();
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-10 sm:py-14 space-y-12">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 items-center">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.16em] text-[#e11d48] mb-2">
            {t.about.kicker}
          </p>
          <h1 className="text-3xl sm:text-4xl font-semibold text-[#003087] mb-4">
            {t.about.title}
          </h1>
          <p className="text-sm sm:text-base text-[#334155] leading-relaxed mb-4">
            {t.about.p1} ({HEAD_OFFICE_ADDRESS})
          </p>
          <p className="text-sm text-[#475569] leading-relaxed mb-6">
            {t.about.p2} (1 USD = K{getZmwPerUsd().toFixed(2)})
          </p>
          <div className="flex flex-wrap gap-3">
            <button
              type="button"
              onClick={() => onNavigate('hire')}
              className="rounded-lg bg-[#003087] text-white text-sm font-semibold px-5 py-2.5"
            >
              {t.about.exploreFleetBtn}
            </button>
            <a
              href={RENTAL_AGREEMENT_PDF}
              target="_blank"
              rel="noopener noreferrer"
              className="rounded-lg border border-[#003087] text-[#003087] text-sm font-semibold px-5 py-2.5 inline-flex items-center gap-1.5"
            >
              <FileText className="w-4 h-4" />
              <span>{t.about.agreementPdfBtn}</span>
            </a>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          {t.about.stats.map((stat, idx) => (
            <div key={stat.kpi} className="rounded-2xl bg-white border border-[#e2e8f0] p-6">
              <p className="text-2xl sm:text-3xl font-bold text-[#003087] tabular-nums mb-1">
                {idx === 3 ? `K${getZmwPerUsd().toFixed(2)} = $1` : stat.kpi}
              </p>
              <p className="text-xs text-[#64748b] leading-relaxed">{stat.label}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="rounded-2xl bg-[#003087] text-white p-8 grid grid-cols-1 md:grid-cols-3 gap-6">
        {t.about.values.map((val) => (
          <div key={val.title} className="space-y-2">
            <ShieldCheck className="w-5 h-5 text-[#fda4af]" />
            <h2 className="text-lg font-semibold text-white">{val.title}</h2>
            <p className="text-xs text-[#cbd5e1] leading-relaxed">{val.text}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

/* ---------------- FAQ PAGE ---------------- */

export const FaqPage: React.FC = () => {
  const { t } = useI18n();
  const [openIndex, setOpenIndex] = useState<number | null>(0);
  const [selectedCat, setSelectedCat] = useState<string>('__all__');

  const categories = ['__all__', ...Array.from(new Set(t.faq.items.map((f) => f.category)))];
  const visibleFaqs =
    selectedCat === '__all__'
      ? t.faq.items
      : t.faq.items.filter((f) => f.category === selectedCat);

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-10 sm:py-14 space-y-8">
      <div>
        <p className="text-xs font-semibold uppercase tracking-[0.16em] text-[#e11d48] mb-1">
          {t.faq.kicker}
        </p>
        <h1 className="text-3xl sm:text-4xl font-semibold text-[#003087]">{t.faq.title}</h1>
      </div>

      <div className="flex flex-wrap gap-2">
        {categories.map((cat) => (
          <button
            key={cat}
            type="button"
            onClick={() => setSelectedCat(cat)}
            className={`rounded-lg px-3.5 py-2 text-xs font-semibold ${
              selectedCat === cat
                ? 'bg-[#003087] text-white'
                : 'bg-white border border-[#cbd5e1] text-[#475569]'
            }`}
          >
            {cat === '__all__' ? t.faq.allCat : cat}
          </button>
        ))}
      </div>

      <div className="space-y-3">
        {visibleFaqs.map((faq, idx) => {
          const isOpen = openIndex === idx;
          return (
            <div
              key={faq.question}
              className="rounded-2xl bg-white border border-[#e2e8f0] overflow-hidden"
            >
              <button
                type="button"
                onClick={() => setOpenIndex(isOpen ? null : idx)}
                className="w-full px-5 py-4 text-left flex items-center justify-between gap-4"
              >
                <div>
                  <p className="text-[11px] font-semibold uppercase tracking-wider text-[#e11d48]">
                    {faq.category}
                  </p>
                  <p className="text-sm sm:text-base font-semibold text-[#0f172a] mt-0.5">
                    {faq.question}
                  </p>
                </div>
                <ChevronDown
                  className={`w-5 h-5 text-[#003087] shrink-0 transition-transform ${
                    isOpen ? 'rotate-180' : ''
                  }`}
                />
              </button>
              {isOpen && (
                <div className="px-5 pb-5 text-sm text-[#475569] leading-relaxed border-t border-[#f1f5f9] pt-3">
                  {faq.answer}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

/* ---------------- BLOG / DRIVING TIPS PAGE ---------------- */

export const BlogPage: React.FC = () => {
  const { t } = useI18n();
  const [activeArticle, setActiveArticle] = useState<BlogArticle | null>(null);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-10 sm:py-14 space-y-8">
      <div>
        <p className="text-xs font-semibold uppercase tracking-[0.16em] text-[#e11d48] mb-1">
          {t.blog.kicker}
        </p>
        <h1 className="text-3xl sm:text-4xl font-semibold text-[#003087]">{t.blog.title}</h1>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {ZAMBIA_BLOG_POSTS.map((post) => (
          <article
            key={post.id}
            className="rounded-2xl bg-white border border-[#e2e8f0] overflow-hidden flex flex-col"
          >
            <div className="aspect-[4/3]">
              <VehicleImage src={post.image} alt={post.title} />
            </div>
            <div className="p-5 flex-1 flex flex-col">
              <p className="text-xs font-semibold text-[#e11d48] mb-1">
                {post.category} · {post.readTime}
              </p>
              <h2 className="text-lg font-semibold text-[#003087] mb-2">{post.title}</h2>
              <p className="text-xs text-[#64748b] leading-relaxed mb-4">{post.excerpt}</p>
              <button
                type="button"
                onClick={() => setActiveArticle(post)}
                className="mt-auto text-left text-xs font-semibold text-[#003087] hover:text-[#e11d48] inline-flex items-center gap-1"
              >
                <span>{t.blog.readGuideBtn}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </article>
        ))}
      </div>

      {activeArticle && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-2xl w-full overflow-hidden shadow-2xl">
            <div className="relative h-56">
              <VehicleImage src={activeArticle.image} alt={activeArticle.title} />
              <button
                type="button"
                onClick={() => setActiveArticle(null)}
                className="absolute top-3 right-3 rounded-full bg-white/90 p-2 text-[#003087]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-6 space-y-4">
              <p className="text-xs font-semibold uppercase tracking-wider text-[#e11d48]">
                {activeArticle.category} · {activeArticle.date}
              </p>
              <h2 className="text-2xl font-semibold text-[#003087]">{activeArticle.title}</h2>
              <div className="space-y-3 text-sm text-[#334155] leading-relaxed">
                {activeArticle.content.map((para) => (
                  <p key={para}>{para}</p>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

/* ---------------- CONTACT PAGE ---------------- */

export const ContactPage: React.FC = () => {
  const { t } = useI18n();
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [topic, setTopic] = useState(t.contact.topics[0] || 'Car Hire & LUN/Lusaka Delivery');
  const [message, setMessage] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [dispatchResult, setDispatchResult] = useState<DispatchResult | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    const res = await dispatchZamtoNotification({
      kind: 'Contact Inquiry',
      customerName: fullName.trim(),
      customerPhone: phone.trim(),
      customerEmail: email.trim() || undefined,
      topicOrVehicle: topic,
      message: message.trim(),
    });
    setDispatchResult(res);
    setSubmitting(false);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-10 sm:py-14 grid grid-cols-1 lg:grid-cols-5 gap-8">
      <div className="lg:col-span-2 space-y-6">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.16em] text-[#e11d48] mb-1">
            {t.contact.kicker}
          </p>
          <h1 className="text-3xl sm:text-4xl font-semibold text-[#003087]">
            {t.contact.title}
          </h1>
          <p className="text-sm text-[#475569] mt-2">{t.contact.subtitle}</p>
        </div>

        <div className="rounded-2xl bg-[#003087] text-white p-6 space-y-4">
          <div>
            <p className="text-xs text-[#fda4af] font-semibold uppercase">
              {t.contact.hotlineLabel}
            </p>
            <p className="text-lg font-semibold mt-0.5 flex items-center gap-2">
              <Phone className="w-4 h-4 text-[#fda4af]" />
              {SUPPORT_PHONE_DISPLAY}
            </p>
          </div>
          <div>
            <p className="text-xs text-[#fda4af] font-semibold uppercase">{t.contact.emailLabel}</p>
            <p className="text-sm mt-0.5">{SUPPORT_EMAIL}</p>
          </div>
          <div>
            <p className="text-xs text-[#fda4af] font-semibold uppercase">
              {t.contact.addressLabel}
            </p>
            <p className="text-sm mt-0.5">{HEAD_OFFICE_ADDRESS}</p>
          </div>

          <div className="pt-2 border-t border-white/15">
            <p className="text-xs text-[#fda4af] font-semibold uppercase mb-2.5">
              {t.contact.connectLabel}
            </p>
            <div className="grid grid-cols-2 gap-2">
              <a
                href={buildWhatsAppUrl('Hello Zamto Africa, I would like to speak with your desk.')}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-1.5 rounded-lg bg-[#e11d48] hover:bg-[#be123c] text-white text-xs font-bold px-3 py-2.5"
              >
                <MessageCircle className="w-4 h-4" />
                <span>WhatsApp</span>
              </a>
              <a
                href={SOCIAL_LINKS.facebook}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-1.5 rounded-lg bg-white/15 hover:bg-white/25 text-white text-xs font-semibold px-3 py-2.5"
              >
                <Facebook className="w-4 h-4" />
                <span>Facebook</span>
              </a>
              <a
                href={SOCIAL_LINKS.instagram}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-1.5 rounded-lg bg-white/15 hover:bg-white/25 text-white text-xs font-semibold px-3 py-2.5"
              >
                <Instagram className="w-4 h-4" />
                <span>Instagram</span>
              </a>
              <a
                href={SOCIAL_LINKS.tiktok}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-1.5 rounded-lg bg-white/15 hover:bg-white/25 text-white text-xs font-semibold px-3 py-2.5"
              >
                <Video className="w-4 h-4" />
                <span>TikTok</span>
              </a>
            </div>
          </div>
        </div>
      </div>

      <div className="lg:col-span-3 rounded-2xl bg-white border border-[#e2e8f0] p-6 sm:p-8">
        {dispatchResult ? (
          <div className="py-8 text-center space-y-4">
            <CheckCircle2 className="w-10 h-10 text-[#003087] mx-auto" />
            <p className="font-mono text-xs font-bold text-[#e11d48]">
              {dispatchResult.reference}
            </p>
            <h2 className="text-xl font-semibold text-[#003087]">{t.contact.sentTitle}</h2>
            <p className="text-sm text-[#475569] max-w-md mx-auto">{t.contact.sentDesc}</p>

            <div className="rounded-xl bg-[#f8fafc] border border-[#e2e8f0] p-4 text-xs text-left max-w-md mx-auto space-y-1.5">
              <p className="font-semibold text-[#003087]">
                Email ({dispatchResult.targetEmail}):{' '}
                {dispatchResult.emailSent
                  ? 'Delivered via Mail Server'
                  : 'Queued / Ready via Mailto Fallback'}
              </p>
              <p className="font-semibold text-[#003087]">
                WhatsApp ({dispatchResult.targetWhatsAppDisplay}):{' '}
                {dispatchResult.whatsappCloudSent
                  ? 'Delivered via WhatsApp Cloud'
                  : 'Instant WhatsApp Dispatch Link Ready Below'}
              </p>
            </div>

            <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
              <a
                href={dispatchResult.whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="rounded-lg bg-[#e11d48] hover:bg-[#be123c] text-white text-xs font-bold px-5 py-2.5 inline-flex items-center gap-1.5"
              >
                <MessageCircle className="w-4 h-4" />
                <span>{t.contact.openWhatsappBtn}</span>
              </a>
              <button
                type="button"
                onClick={() => {
                  setDispatchResult(null);
                  setMessage('');
                }}
                className="rounded-lg border border-[#003087] text-[#003087] text-xs font-semibold px-4 py-2.5"
              >
                {t.contact.sendAnotherBtn}
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <h2 className="text-xl font-semibold text-[#003087]">{t.contact.formTitle}</h2>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-semibold mb-1">
                  {t.contact.fullNameLabel}
                </label>
                <input
                  type="text"
                  required
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  className="w-full rounded-lg border border-[#cbd5e1] px-3 py-2.5 text-sm"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold mb-1">
                  {t.contact.phoneLabel}
                </label>
                <input
                  type="tel"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="+260..."
                  className="w-full rounded-lg border border-[#cbd5e1] px-3 py-2.5 text-sm"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold mb-1">
                  {t.contact.emailOptionalLabel}
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@email.com"
                  className="w-full rounded-lg border border-[#cbd5e1] px-3 py-2.5 text-sm"
                />
              </div>
            </div>
            <div>
              <label className="block text-xs font-semibold mb-1">{t.contact.topicLabel}</label>
              <select
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                className="w-full rounded-lg border border-[#cbd5e1] px-3 py-2.5 text-sm"
              >
                {t.contact.topics.map((item) => (
                  <option key={item} value={item}>
                    {item}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold mb-1">
                {t.contact.messageLabel}
              </label>
              <textarea
                rows={4}
                required
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder={t.contact.messagePlaceholder}
                className="w-full rounded-lg border border-[#cbd5e1] px-3 py-2.5 text-sm"
              />
            </div>
            <button
              type="submit"
              disabled={submitting}
              className="rounded-lg bg-[#003087] hover:bg-[#002266] disabled:opacity-50 text-white font-semibold text-sm px-6 py-3"
            >
              {submitting ? t.contact.sendingBtn : t.contact.sendBtn}
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
