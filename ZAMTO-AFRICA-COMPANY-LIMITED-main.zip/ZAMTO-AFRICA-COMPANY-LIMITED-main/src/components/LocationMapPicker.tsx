/// <reference types="google.maps" />
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  APILoadingStatus,
  AdvancedMarker,
  InfoWindow,
  Map as GoogleMap,
  Pin,
  useAdvancedMarkerRef,
  useApiLoadingStatus,
  useMap,
  useMapsLibrary,
} from '@vis.gl/react-google-maps';
import { Check, Crosshair, MapPin, Navigation, Route as RouteIcon, Search } from 'lucide-react';
import type { LusakaDeliveryZone } from '../types';
import { LUSAKA_DELIVERY_ZONES } from '../data/zambiaData';
import { useI18n } from '../i18n/I18nContext';
import { GOOGLE_MAPS_API_KEY } from '../utils/format';

export interface SelectedGeoPoint {
  label: string;
  address?: string;
  placeId?: string;
  location?: google.maps.LatLngLiteral;
  isCityExit: boolean;
}

interface LocationMapPickerProps {
  selectedLocation: string;
  onSelectLocation: (label: string, details?: SelectedGeoPoint) => void;
  dropoffLocation?: string;
  onSelectDropoffLocation?: (label: string, details?: SelectedGeoPoint) => void;
  modeLabel?: string;
}

interface ResolvedHubPlace {
  zoneId: string;
  label: string;
  shortName: string;
  formattedAddress: string;
  placeId: string;
  location: google.maps.LatLngLiteral;
  isLusakaLocal: boolean;
}

// Viewport center only (Lusaka region overview); all place coordinates come from Places API calls.
const LUSAKA_VIEWPORT_CENTER: google.maps.LatLngLiteral = { lat: -15.4067, lng: 28.2871 };

const HUB_SEARCH_QUERIES: Record<string, string> = {
  'rhodes-hq': 'Great East Road Rhodes Park Lusaka Zambia',
  'lun-airport': 'Kenneth Kaunda International Airport Lusaka Zambia',
  'kabulonga-woodlands': 'Kabulonga Lusaka Zambia',
  'manda-northmead': 'Manda Hill Shopping Mall Lusaka Zambia',
  'lusaka-cbd': 'Cairo Road Lusaka Zambia',
  'roma-foxdale': 'Roma Lusaka Zambia',
  'makeni-lilayi': 'Makeni Lusaka Zambia',
  'city-exit-livingstone': 'Livingstone Zambia',
  'city-exit-copperbelt': 'Ndola Zambia',
  'city-exit-solwezi': 'Solwezi Zambia',
};

function notifyIfQuotaError(err: unknown): void {
  const msg = String(err || '');
  if (
    msg.includes('RESOURCE_EXHAUSTED') ||
    msg.includes('OVER_QUERY_LIMIT') ||
    msg.includes('Quota') ||
    msg.includes('429')
  ) {
    window.dispatchEvent(new CustomEvent('gmp-quota-exceeded'));
  }
}

function isOutOfLusakaLabel(label: string): boolean {
  const lower = label.toLowerCase();
  return (
    lower.includes('out of city') ||
    lower.includes('city exit') ||
    lower.includes('livingstone') ||
    lower.includes('ndola') ||
    lower.includes('kitwe') ||
    lower.includes('solwezi') ||
    lower.includes('copperbelt') ||
    lower.includes('kafue national') ||
    lower.includes('siavonga')
  );
}

/* ---------------- ROUTES API SUB-COMPONENT ---------------- */

const RouteOverlay: React.FC<{
  origin: google.maps.LatLngLiteral | null;
  destination: google.maps.LatLngLiteral | null;
  onRouteComputed: (summary: { distanceKm: number; durationMins: number } | null) => void;
}> = ({ origin, destination, onRouteComputed }) => {
  const map = useMap();
  const routesLib = useMapsLibrary('routes');
  const polylinesRef = useRef<google.maps.Polyline[]>([]);

  useEffect(() => {
    polylinesRef.current.forEach((p) => p.setMap(null));
    polylinesRef.current = [];

    if (!routesLib || !map || !origin || !destination) {
      onRouteComputed(null);
      return;
    }

    const sameSpot =
      Math.abs(origin.lat - destination.lat) < 0.0005 &&
      Math.abs(origin.lng - destination.lng) < 0.0005;
    if (sameSpot) {
      onRouteComputed(null);
      return;
    }

    let cancelled = false;

    const request = {
      origin,
      destination,
      travelMode: 'DRIVING',
      fields: ['path', 'distanceMeters', 'durationMillis', 'viewport'],
    };

    const RouteClass = routesLib.Route as unknown as {
      computeRoutes: (req: typeof request) => Promise<{
        routes?: Array<{
          distanceMeters?: number;
          durationMillis?: number;
          viewport?: google.maps.LatLngBounds;
          createPolylines: () => google.maps.Polyline[];
        }>;
      }>;
    };

    if (!RouteClass?.computeRoutes) {
      onRouteComputed(null);
      return;
    }

    RouteClass.computeRoutes(request)
      .then(({ routes }) => {
        if (cancelled) return;
        const primary = routes?.[0];
        if (!primary) {
          onRouteComputed(null);
          return;
        }
        const created = primary.createPolylines();
        created.forEach((line) => {
          line.setOptions({
            strokeColor: '#003087',
            strokeOpacity: 0.9,
            strokeWeight: 5,
          });
          line.setMap(map);
        });
        polylinesRef.current = created;

        if (primary.viewport) {
          map.fitBounds(primary.viewport, 48);
        }

        const distanceKm = Math.round(((primary.distanceMeters || 0) / 1000) * 10) / 10;
        const durationMins = Math.max(1, Math.round((primary.durationMillis || 0) / 60000));
        onRouteComputed({ distanceKm, durationMins });
      })
      .catch((err) => {
        if (cancelled) return;
        notifyIfQuotaError(err);
        onRouteComputed(null);
      });

    return () => {
      cancelled = true;
      polylinesRef.current.forEach((p) => p.setMap(null));
      polylinesRef.current = [];
    };
  }, [routesLib, map, origin, destination, onRouteComputed]);

  return null;
};

/* ---------------- ANCHORED ADVANCED MARKER WITH INFOWINDOW ---------------- */

const PointMarkerWithInfo: React.FC<{
  position: google.maps.LatLngLiteral;
  title: string;
  subtitle: string;
  glyph: string;
  background: string;
  borderColor: string;
  openByDefault?: boolean;
}> = ({ position, title, subtitle, glyph, background, borderColor, openByDefault = false }) => {
  const [markerRef, marker] = useAdvancedMarkerRef();
  const [open, setOpen] = useState(openByDefault);

  return (
    <>
      <AdvancedMarker
        ref={markerRef}
        position={position}
        title={title}
        onClick={() => setOpen((o) => !o)}
      >
        <Pin
          background={background}
          borderColor={borderColor}
          glyphColor="#ffffff"
          glyphText={glyph}
          scale={1.15}
        />
      </AdvancedMarker>
      {open && marker && (
        <InfoWindow anchor={marker} maxWidth={240} onCloseClick={() => setOpen(false)}>
          <div className="p-1 text-xs text-[#0f172a]">
            <p className="font-bold text-[#003087]">{title}</p>
            <p className="text-[11px] text-[#475569] mt-0.5">{subtitle}</p>
          </div>
        </InfoWindow>
      )}
    </>
  );
};

/* ---------------- PLACES API AUTOCOMPLETE SEARCH ---------------- */

const PlacesAutocompleteBox: React.FC<{
  activeTarget: 'pickup' | 'dropoff';
  onPlaceResolved: (point: SelectedGeoPoint) => void;
}> = ({ activeTarget, onPlaceResolved }) => {
  const { t } = useI18n();
  const placesLib = useMapsLibrary('places');
  const [query, setQuery] = useState('');
  const [suggestions, setSuggestions] = useState<google.maps.places.AutocompleteSuggestion[]>([]);
  const [searching, setSearching] = useState(false);
  const sessionTokenRef = useRef<google.maps.places.AutocompleteSessionToken | null>(null);

  useEffect(() => {
    if (!placesLib || !query.trim()) {
      setSuggestions([]);
      return;
    }

    const timer = window.setTimeout(() => {
      if (!sessionTokenRef.current) {
        sessionTokenRef.current = new placesLib.AutocompleteSessionToken();
      }
      setSearching(true);
      placesLib.AutocompleteSuggestion.fetchAutocompleteSuggestions({
        input: query.trim(),
        sessionToken: sessionTokenRef.current,
        includedRegionCodes: ['zm'],
      })
        .then((res) => {
          setSuggestions(res.suggestions || []);
        })
        .catch((err) => {
          notifyIfQuotaError(err);
          setSuggestions([]);
        })
        .finally(() => setSearching(false));
    }, 240);

    return () => window.clearTimeout(timer);
  }, [placesLib, query]);

  const handleSelectSuggestion = useCallback(
    async (suggestion: google.maps.places.AutocompleteSuggestion) => {
      if (!placesLib || !suggestion.placePrediction) return;
      try {
        const place = suggestion.placePrediction.toPlace();
        await place.fetchFields({
          fields: ['id', 'displayName', 'formattedAddress', 'location', 'viewport'],
        });
        const loc = place.location;
        const formattedLabel = [place.displayName, place.formattedAddress]
          .filter(Boolean)
          .join(' — ');
        const finalLabel =
          formattedLabel || suggestion.placePrediction.text.text || 'Custom Zambia Location';

        onPlaceResolved({
          label: finalLabel,
          address: place.formattedAddress || undefined,
          placeId: place.id,
          location: loc ? { lat: loc.lat(), lng: loc.lng() } : undefined,
          isCityExit: isOutOfLusakaLabel(finalLabel),
        });
        setQuery('');
        setSuggestions([]);
        sessionTokenRef.current = null;
      } catch (err) {
        notifyIfQuotaError(err);
      }
    },
    [placesLib, onPlaceResolved]
  );

  return (
    <div className="relative">
      <div className="relative">
        <Search className="w-4 h-4 text-[#003087] absolute left-3 top-2.5 pointer-events-none" />
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder={
            activeTarget === 'pickup'
              ? `${t.mapPicker.selectingPickup}: ${t.mapPicker.searchPlaceholder}`
              : `${t.mapPicker.selectingDropoff}: ${t.mapPicker.searchPlaceholder}`
          }
          className="w-full rounded-lg border border-[#cbd5e1] bg-white pl-9 pr-16 py-2 text-xs font-medium text-[#0f172a] focus:border-[#003087] focus:outline-none"
        />
        {searching && (
          <span className="absolute right-3 top-2.5 text-[10px] font-semibold text-[#64748b]">
            Searching...
          </span>
        )}
      </div>

      {suggestions.length > 0 && (
        <ul className="absolute z-30 left-0 right-0 mt-1 rounded-xl bg-white border border-[#cbd5e1] shadow-lg max-h-52 overflow-y-auto divide-y divide-[#f1f5f9]">
          {suggestions.map((item, idx) => (
            <li key={item.placePrediction?.placeId || idx}>
              <button
                type="button"
                onClick={() => void handleSelectSuggestion(item)}
                className="w-full text-left px-3 py-2 text-xs hover:bg-[#eff6ff] flex items-start gap-2"
              >
                <MapPin className="w-3.5 h-3.5 text-[#e11d48] shrink-0 mt-0.5" />
                <span className="text-[#0f172a] font-medium">
                  {item.placePrediction?.text.text}
                </span>
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

/* ---------------- CAMERA FOCUSER ---------------- */

const MapCameraController: React.FC<{
  focusLocation: google.maps.LatLngLiteral | null;
  hasRoute: boolean;
}> = ({ focusLocation, hasRoute }) => {
  const map = useMap();
  useEffect(() => {
    if (!map || !focusLocation || hasRoute) return;
    map.panTo(focusLocation);
    if ((map.getZoom() || 0) < 12) {
      map.setZoom(12);
    }
  }, [map, focusLocation, hasRoute]);
  return null;
};

/* ---------------- GOOGLE MAPS ENABLED VIEW ---------------- */

const sessionResolvedHubs: Record<string, ResolvedHubPlace> = {};

const GoogleMapsInteractivePicker: React.FC<LocationMapPickerProps> = ({
  selectedLocation,
  onSelectLocation,
  dropoffLocation,
  onSelectDropoffLocation,
  modeLabel,
}) => {
  const { t } = useI18n();
  const apiStatus = useApiLoadingStatus();
  const placesLib = useMapsLibrary('places');

  const [activeTarget, setActiveTarget] = useState<'pickup' | 'dropoff'>('pickup');
  const [hubCoords, setHubCoords] = useState<Record<string, ResolvedHubPlace>>(() => ({
    ...sessionResolvedHubs,
  }));
  const [customPoints, setCustomPoints] = useState<Record<string, SelectedGeoPoint>>({});
  const [routeSummary, setRouteSummary] = useState<{
    distanceKm: number;
    durationMins: number;
  } | null>(null);
  const [locatingGps, setLocatingGps] = useState(false);

  const effectiveDropoff =
    dropoffLocation && dropoffLocation !== 'Same as pickup' ? dropoffLocation : selectedLocation;

  // Dynamically resolve key Zamto hubs (HQ + LUN Airport) once per session via Places API (New)
  useEffect(() => {
    if (!placesLib) return;
    let active = true;

    const resolveZone = async (zone: LusakaDeliveryZone) => {
      if (sessionResolvedHubs[zone.label]) {
        setHubCoords((prev) =>
          prev[zone.label] ? prev : { ...prev, [zone.label]: sessionResolvedHubs[zone.label] }
        );
        return;
      }
      const textQuery = HUB_SEARCH_QUERIES[zone.id];
      if (!textQuery) return;
      try {
        const { places } = await placesLib.Place.searchByText({
          textQuery,
          fields: ['id', 'displayName', 'formattedAddress', 'location'],
          region: 'zm',
          maxResultCount: 1,
        });
        if (!active) return;
        const first = places?.[0];
        if (first?.location) {
          const resolved: ResolvedHubPlace = {
            zoneId: zone.id,
            label: zone.label,
            shortName: zone.shortName,
            formattedAddress: first.formattedAddress || zone.area,
            placeId: first.id,
            location: { lat: first.location.lat(), lng: first.location.lng() },
            isLusakaLocal: zone.isLusakaLocal,
          };
          sessionResolvedHubs[zone.label] = resolved;
          setHubCoords((prev) => ({ ...prev, [zone.label]: resolved }));
        }
      } catch (err) {
        notifyIfQuotaError(err);
      }
    };

    const priorityZones = LUSAKA_DELIVERY_ZONES.filter(
      (z) =>
        z.id === 'rhodes-hq' ||
        z.id === 'lun-airport' ||
        z.label === selectedLocation ||
        z.label === effectiveDropoff
    );
    priorityZones.forEach((zone) => {
      void resolveZone(zone);
    });

    return () => {
      active = false;
    };
  }, [placesLib, selectedLocation, effectiveDropoff]);

  const resolveSingleZone = useCallback(
    async (zone: LusakaDeliveryZone): Promise<SelectedGeoPoint> => {
      const existing = sessionResolvedHubs[zone.label] || hubCoords[zone.label];
      if (existing) {
        return {
          label: zone.label,
          address: existing.formattedAddress,
          placeId: existing.placeId,
          location: existing.location,
          isCityExit: !zone.isLusakaLocal,
        };
      }
      if (placesLib) {
        try {
          const { places } = await placesLib.Place.searchByText({
            textQuery: HUB_SEARCH_QUERIES[zone.id] || zone.label,
            fields: ['id', 'displayName', 'formattedAddress', 'location'],
            region: 'zm',
            maxResultCount: 1,
          });
          const first = places?.[0];
          if (first?.location) {
            const loc = { lat: first.location.lat(), lng: first.location.lng() };
            const resolved: ResolvedHubPlace = {
              zoneId: zone.id,
              label: zone.label,
              shortName: zone.shortName,
              formattedAddress: first.formattedAddress || zone.area,
              placeId: first.id,
              location: loc,
              isLusakaLocal: zone.isLusakaLocal,
            };
            sessionResolvedHubs[zone.label] = resolved;
            setHubCoords((prev) => ({ ...prev, [zone.label]: resolved }));
            return {
              label: zone.label,
              address: resolved.formattedAddress,
              placeId: resolved.placeId,
              location: loc,
              isCityExit: !zone.isLusakaLocal,
            };
          }
        } catch (err) {
          notifyIfQuotaError(err);
        }
      }
      return {
        label: zone.label,
        address: zone.area,
        isCityExit: !zone.isLusakaLocal,
      };
    },
    [hubCoords, placesLib]
  );

  const applySelection = useCallback(
    (point: SelectedGeoPoint, targetOverride?: 'pickup' | 'dropoff') => {
      const target = targetOverride || activeTarget;
      if (point.location) {
        setCustomPoints((prev) => ({ ...prev, [point.label]: point }));
      }
      if (target === 'dropoff' && onSelectDropoffLocation) {
        onSelectDropoffLocation(point.label, point);
      } else {
        onSelectLocation(point.label, point);
      }
    },
    [activeTarget, onSelectDropoffLocation, onSelectLocation]
  );

  const handleZoneButtonClick = useCallback(
    async (zone: LusakaDeliveryZone) => {
      const point = await resolveSingleZone(zone);
      applySelection(point);
    },
    [resolveSingleZone, applySelection]
  );

  const handleMapClick = useCallback(
    async (latLng: google.maps.LatLngLiteral) => {
      let label = `Pinned Spot (${latLng.lat.toFixed(4)}, ${latLng.lng.toFixed(4)})`;
      let address = 'Lusaka / Zambia Map Pin';
      let placeId: string | undefined;

      if (placesLib) {
        try {
          const { places } = await placesLib.Place.searchNearby({
            locationRestriction: {
              center: latLng,
              radius: 400,
            },
            fields: ['id', 'displayName', 'formattedAddress', 'location'],
            maxResultCount: 1,
          });
          const nearest = places?.[0];
          if (nearest) {
            label = nearest.displayName
              ? `${nearest.displayName}${nearest.formattedAddress ? ` — ${nearest.formattedAddress}` : ''}`
              : nearest.formattedAddress || label;
            address = nearest.formattedAddress || address;
            placeId = nearest.id;
          }
        } catch (err) {
          notifyIfQuotaError(err);
        }
      }

      applySelection({
        label,
        address,
        placeId,
        location: latLng,
        isCityExit: isOutOfLusakaLabel(label),
      });
    },
    [placesLib, applySelection]
  );

  const handleUseCurrentGps = () => {
    if (!navigator.geolocation) return;
    setLocatingGps(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const latLng = { lat: pos.coords.latitude, lng: pos.coords.longitude };
        void handleMapClick(latLng).finally(() => setLocatingGps(false));
      },
      () => setLocatingGps(false),
      { enableHighAccuracy: true, timeout: 8000 }
    );
  };

  const pickupLocationCoord = useMemo(() => {
    return (
      customPoints[selectedLocation]?.location ||
      hubCoords[selectedLocation]?.location ||
      null
    );
  }, [customPoints, hubCoords, selectedLocation]);

  const dropoffLocationCoord = useMemo(() => {
    if (!onSelectDropoffLocation) return null;
    return (
      customPoints[effectiveDropoff]?.location ||
      hubCoords[effectiveDropoff]?.location ||
      null
    );
  }, [onSelectDropoffLocation, customPoints, hubCoords, effectiveDropoff]);

  const hasDistinctRoute = Boolean(
    pickupLocationCoord &&
      dropoffLocationCoord &&
      (Math.abs(pickupLocationCoord.lat - dropoffLocationCoord.lat) >= 0.0005 ||
        Math.abs(pickupLocationCoord.lng - dropoffLocationCoord.lng) >= 0.0005)
  );

  const focusPoint =
    activeTarget === 'dropoff'
      ? dropoffLocationCoord || pickupLocationCoord
      : pickupLocationCoord || dropoffLocationCoord;

  const activeZoneMeta =
    LUSAKA_DELIVERY_ZONES.find(
      (z) => z.label === (activeTarget === 'dropoff' ? effectiveDropoff : selectedLocation)
    ) || null;

  const mapUnavailable =
    apiStatus === APILoadingStatus.AUTH_FAILURE || apiStatus === APILoadingStatus.FAILED;

  return (
    <div className="rounded-xl border border-[#cbd5e1] bg-[#f8fafc] p-4 space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <p className="text-xs font-bold uppercase tracking-wider text-[#003087] flex items-center gap-1.5">
            <Navigation className="w-3.5 h-3.5 text-[#e11d48]" />
            <span>{modeLabel || t.mapPicker.titleDefault}</span>
          </p>
          <p className="text-[11px] text-[#475569] mt-0.5">
            {t.mapPicker.searchPlaceholder}
          </p>
        </div>

        <button
          type="button"
          onClick={handleUseCurrentGps}
          disabled={locatingGps}
          className="inline-flex items-center gap-1.5 rounded-lg border border-[#cbd5e1] bg-white hover:border-[#003087] px-2.5 py-1.5 text-[11px] font-semibold text-[#003087]"
        >
          <Crosshair className="w-3.5 h-3.5 text-[#e11d48]" />
          <span>{locatingGps ? '...' : t.mapPicker.useMyLocation}</span>
        </button>
      </div>

      {/* Pickup (A) & Drop-off (B) Active Target Switcher */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
        <button
          type="button"
          onClick={() => setActiveTarget('pickup')}
          className={`text-left rounded-xl p-3 border transition-colors ${
            activeTarget === 'pickup'
              ? 'bg-white border-[#003087] ring-1 ring-[#003087]'
              : 'bg-white/70 border-[#cbd5e1] hover:border-[#003087]'
          }`}
        >
          <div className="flex items-center justify-between gap-2 mb-1">
            <span className="text-[10px] font-bold uppercase tracking-wider text-[#003087]">
              {t.mapPicker.pickupPoint}
            </span>
            {activeTarget === 'pickup' && (
              <span className="text-[10px] font-bold text-[#e11d48]">
                {t.mapPicker.selectingPickup}
              </span>
            )}
          </div>
          <p className="text-xs font-semibold text-[#0f172a] truncate">{selectedLocation}</p>
        </button>

        {onSelectDropoffLocation ? (
          <div
            className={`rounded-xl p-3 border transition-colors ${
              activeTarget === 'dropoff'
                ? 'bg-white border-[#e11d48] ring-1 ring-[#e11d48]'
                : 'bg-white/70 border-[#cbd5e1] hover:border-[#003087]'
            }`}
          >
            <div className="flex items-center justify-between gap-2 mb-1">
              <button
                type="button"
                onClick={() => setActiveTarget('dropoff')}
                className="text-[10px] font-bold uppercase tracking-wider text-[#e11d48]"
              >
                {t.mapPicker.dropoffPoint}{' '}
                {activeTarget === 'dropoff' ? `(${t.mapPicker.selectingDropoff})` : ''}
              </button>
              {effectiveDropoff !== selectedLocation && (
                <button
                  type="button"
                  onClick={() =>
                    onSelectDropoffLocation(selectedLocation, customPoints[selectedLocation])
                  }
                  className="text-[10px] font-semibold text-[#003087] hover:underline"
                >
                  {t.mapPicker.sameAsPickup}
                </button>
              )}
            </div>
            <button
              type="button"
              onClick={() => setActiveTarget('dropoff')}
              className="w-full text-left text-xs font-semibold text-[#0f172a] truncate"
            >
              {effectiveDropoff}
            </button>
          </div>
        ) : (
          <div className="rounded-xl p-3 border border-[#e2e8f0] bg-white/80">
            <p className="text-[10px] font-bold uppercase tracking-wider text-[#475569] mb-1">
              Delivery Zone Details
            </p>
            <p className="text-xs text-[#0f172a] font-medium truncate">
              {activeZoneMeta?.transferNote || 'Rhodes Park HQ dispatch & Lusaka doorstep delivery'}
            </p>
          </div>
        )}
      </div>

      {/* Places Autocomplete Search */}
      {!mapUnavailable && (
        <PlacesAutocompleteBox
          activeTarget={activeTarget}
          onPlaceResolved={(pt) => applySelection(pt)}
        />
      )}

      {/* Map + Quick Hub Selector Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-4 items-stretch">
        <div className="lg:col-span-3 flex flex-col gap-2">
          {mapUnavailable ? (
            <div className="h-[300px] rounded-xl border border-[#cbd5e1] bg-white p-5 flex flex-col items-center justify-center text-center gap-2">
              <MapPin className="w-7 h-7 text-[#e11d48]" />
              <p className="text-sm font-semibold text-[#003087]">
                Select Pickup or Drop-off from Zamto Dispatch Zones
              </p>
              <p className="text-xs text-[#64748b] max-w-sm">
                Interactive map tiles are currently unavailable. Choose any Lusaka zone or City Exit
                corridor from the quick selector alongside.
              </p>
            </div>
          ) : (
            <div className="w-full h-[320px] sm:h-[360px] rounded-xl overflow-hidden border border-[#cbd5e1] bg-[#e2e8f0]">
              <GoogleMap
                mapId="DEMO_MAP_ID"
                defaultCenter={LUSAKA_VIEWPORT_CENTER}
                defaultZoom={11}
                gestureHandling="greedy"
                mapTypeControl={false}
                streetViewControl={false}
                internalUsageAttributionIds={['gmp_mcp_codeassist_v1_aistudio']}
                onClick={(ev) => {
                  if (ev.detail.latLng) {
                    void handleMapClick(ev.detail.latLng);
                  }
                }}
                style={{ width: '100%', height: '100%' }}
              >
                <MapCameraController focusLocation={focusPoint} hasRoute={hasDistinctRoute} />

                {/* Hub pins resolved from Places API */}
                {Object.values(hubCoords).map((hub) => {
                  const isPickup = hub.label === selectedLocation;
                  const isDropoff = onSelectDropoffLocation && hub.label === effectiveDropoff;
                  if (isPickup || isDropoff) return null;
                  return (
                    <AdvancedMarker
                      key={hub.zoneId}
                      position={hub.location}
                      title={hub.shortName}
                      onClick={() =>
                        applySelection({
                          label: hub.label,
                          address: hub.formattedAddress,
                          placeId: hub.placeId,
                          location: hub.location,
                          isCityExit: !hub.isLusakaLocal,
                        })
                      }
                    >
                      <Pin
                        background={hub.zoneId === 'rhodes-hq' ? '#0f172a' : '#64748b'}
                        borderColor="#ffffff"
                        glyphColor="#ffffff"
                        scale={0.85}
                      />
                    </AdvancedMarker>
                  );
                })}

                {/* Active Pickup Marker A */}
                {pickupLocationCoord && (
                  <PointMarkerWithInfo
                    position={pickupLocationCoord}
                    title={`Pickup: ${selectedLocation}`}
                    subtitle={
                      customPoints[selectedLocation]?.address ||
                      hubCoords[selectedLocation]?.formattedAddress ||
                      'Selected Pickup Point'
                    }
                    glyph="A"
                    background="#003087"
                    borderColor="#ffffff"
                  />
                )}

                {/* Active Drop-off Marker B (if distinct from Pickup) */}
                {hasDistinctRoute && dropoffLocationCoord && (
                  <PointMarkerWithInfo
                    position={dropoffLocationCoord}
                    title={`Drop-off: ${effectiveDropoff}`}
                    subtitle={
                      customPoints[effectiveDropoff]?.address ||
                      hubCoords[effectiveDropoff]?.formattedAddress ||
                      'Selected Return Point'
                    }
                    glyph="B"
                    background="#e11d48"
                    borderColor="#ffffff"
                  />
                )}

                {/* Live Driving Route */}
                {hasDistinctRoute && pickupLocationCoord && dropoffLocationCoord && (
                  <RouteOverlay
                    origin={pickupLocationCoord}
                    destination={dropoffLocationCoord}
                    onRouteComputed={setRouteSummary}
                  />
                )}
              </GoogleMap>
            </div>
          )}

          {routeSummary && (
            <div className="rounded-lg bg-white border border-[#bfdbfe] px-3.5 py-2 flex flex-wrap items-center justify-between gap-2 text-xs tabular-nums">
              <span className="inline-flex items-center gap-1.5 font-semibold text-[#003087]">
                <RouteIcon className="w-4 h-4 text-[#e11d48]" />
                <span>
                  {t.mapPicker.routeLabel}: {routeSummary.distanceKm} km · ~{routeSummary.durationMins} min
                </span>
              </span>
              <span className="text-[11px] text-[#475569]">
                {routeSummary.distanceKm > 70 || isOutOfLusakaLabel(effectiveDropoff)
                  ? 'City Exit Corridor (180 km/day)'
                  : 'Within Lusaka Zone (120 km/day)'}
              </span>
            </div>
          )}
        </div>

        {/* Quick Zamto Dispatch Zones & City Exit Corridors */}
        <div className="lg:col-span-2 flex flex-col gap-3">
          <div className="rounded-xl bg-white border border-[#cbd5e1] p-3.5 space-y-1">
            <p className="text-[10px] font-bold uppercase tracking-wider text-[#e11d48]">
              {activeZoneMeta?.zoneKind || 'Custom Google Maps Point'}
            </p>
            <p className="text-xs font-semibold text-[#003087]">
              {activeTarget === 'dropoff' ? effectiveDropoff : selectedLocation}
            </p>
            <p className="text-[11px] text-[#475569]">
              {activeZoneMeta?.transferNote ||
                'Pinned via Google Maps Places — Rhodes Park dispatch or doorstep delivery.'}
            </p>
            {activeZoneMeta && (
              <p className="text-[11px] font-medium text-[#0f172a]">
                Dispatch window: {activeZoneMeta.deliveryTime}
              </p>
            )}
          </div>

          <div className="grid grid-cols-2 gap-1.5 max-h-60 overflow-y-auto pr-1">
            {LUSAKA_DELIVERY_ZONES.map((zone) => {
              const targetLabel = activeTarget === 'dropoff' ? effectiveDropoff : selectedLocation;
              const active = targetLabel === zone.label;
              return (
                <button
                  key={zone.id}
                  type="button"
                  onClick={() => void handleZoneButtonClick(zone)}
                  className={`text-left rounded-lg px-2.5 py-2 text-[11px] font-medium border flex items-center justify-between gap-1 transition-colors ${
                    active
                      ? 'bg-[#003087] text-white border-[#003087]'
                      : 'bg-white text-[#334155] border-[#cbd5e1] hover:border-[#003087]'
                  }`}
                >
                  <span className="truncate flex items-center gap-1">
                    <MapPin className="w-3 h-3 shrink-0" />
                    {zone.shortName}
                  </span>
                  {active && <Check className="w-3 h-3 shrink-0 text-[#fda4af]" />}
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};

/* ---------------- FALLBACK PICKER WHEN KEY IS ABSENT ---------------- */

const StaticFallbackZonePicker: React.FC<LocationMapPickerProps> = ({
  selectedLocation,
  onSelectLocation,
  dropoffLocation,
  onSelectDropoffLocation,
  modeLabel,
}) => {
  const { t } = useI18n();
  const [activeTarget, setActiveTarget] = useState<'pickup' | 'dropoff'>('pickup');
  const effectiveDropoff =
    dropoffLocation && dropoffLocation !== 'Same as pickup' ? dropoffLocation : selectedLocation;

  return (
    <div className="rounded-xl border border-[#cbd5e1] bg-[#f8fafc] p-4 space-y-3">
      <p className="text-xs font-bold uppercase tracking-wider text-[#003087] flex items-center gap-1.5">
        <Navigation className="w-3.5 h-3.5 text-[#e11d48]" />
        <span>{modeLabel || t.mapPicker.titleDefault}</span>
      </p>
      {onSelectDropoffLocation && (
        <div className="flex gap-2 text-xs">
          <button
            type="button"
            onClick={() => setActiveTarget('pickup')}
            className={`px-3 py-1.5 rounded-lg font-semibold border ${
              activeTarget === 'pickup'
                ? 'bg-[#003087] text-white border-[#003087]'
                : 'bg-white text-[#475569] border-[#cbd5e1]'
            }`}
          >
            {t.mapPicker.pickupPoint}: {selectedLocation}
          </button>
          <button
            type="button"
            onClick={() => setActiveTarget('dropoff')}
            className={`px-3 py-1.5 rounded-lg font-semibold border ${
              activeTarget === 'dropoff'
                ? 'bg-[#e11d48] text-white border-[#e11d48]'
                : 'bg-white text-[#475569] border-[#cbd5e1]'
            }`}
          >
            {t.mapPicker.dropoffPoint}: {effectiveDropoff}
          </button>
        </div>
      )}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2">
        {LUSAKA_DELIVERY_ZONES.map((zone) => {
          const isMatch =
            (activeTarget === 'dropoff' ? effectiveDropoff : selectedLocation) === zone.label;
          return (
            <button
              key={zone.id}
              type="button"
              onClick={() => {
                const payload: SelectedGeoPoint = {
                  label: zone.label,
                  address: zone.area,
                  isCityExit: !zone.isLusakaLocal,
                };
                if (activeTarget === 'dropoff' && onSelectDropoffLocation) {
                  onSelectDropoffLocation(zone.label, payload);
                } else {
                  onSelectLocation(zone.label, payload);
                }
              }}
              className={`text-left rounded-lg px-2.5 py-2 text-[11px] font-medium border flex items-center justify-between gap-1 ${
                isMatch
                  ? 'bg-[#003087] text-white border-[#003087]'
                  : 'bg-white text-[#334155] border-[#cbd5e1] hover:border-[#003087]'
              }`}
            >
              <span className="truncate">{zone.shortName}</span>
              {isMatch && <Check className="w-3 h-3 shrink-0 text-[#fda4af]" />}
            </button>
          );
        })}
      </div>
    </div>
  );
};

export const LocationMapPicker: React.FC<LocationMapPickerProps> = (props) => {
  if (!GOOGLE_MAPS_API_KEY) {
    return <StaticFallbackZonePicker {...props} />;
  }
  return <GoogleMapsInteractivePicker {...props} />;
};
