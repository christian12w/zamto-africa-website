export const ZAMTO_BRAND_LOGO_PATH = '/assets/aistudio/logo_529d2d6f.png';

export const RESEND_GLOBAL_CSS = `/* Zamto Africa — Branded Global CSS for Resend Email & Form Templates */
:root {
  --zamto-cobalt: #003087;
  --zamto-navy: #001d54;
  --zamto-crimson: #e11d48;
  --zamto-crimson-dark: #be123c;
  --zamto-bg: #f1f5f9;
  --zamto-surface: #ffffff;
  --zamto-surface-muted: #f8fafc;
  --zamto-border: #cbd5e1;
  --zamto-divider: #e2e8f0;
  --zamto-ink: #0f172a;
  --zamto-muted: #475569;
  --zamto-soft-blue: #eff6ff;
  --zamto-soft-rose: #fff1f2;
}

* {
  box-sizing: border-box;
}

body,
.zamto-email-body {
  margin: 0;
  padding: 0;
  width: 100% !important;
  background-color: #f1f5f9;
  color: #0f172a;
  font-family: "Plus Jakarta Sans", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -webkit-text-size-adjust: 100%;
}

img {
  border: 0;
  outline: none;
  text-decoration: none;
  display: block;
}

table {
  border-collapse: collapse;
  mso-table-lspace: 0pt;
  mso-table-rspace: 0pt;
}

.zamto-wrapper {
  width: 100%;
  background-color: #f1f5f9;
  padding: 28px 14px;
}

.zamto-card {
  width: 100%;
  max-width: 640px;
  margin: 0 auto;
  background-color: #ffffff;
  border: 1px solid #cbd5e1;
  border-radius: 16px;
  overflow: hidden;
  box-shadow: 0 10px 30px rgba(0, 48, 135, 0.08);
}

.zamto-header {
  background: linear-gradient(135deg, #003087 0%, #001d54 100%);
  background-color: #003087;
  color: #ffffff;
  padding: 22px 26px;
}

.zamto-header-accent {
  height: 4px;
  background-color: #e11d48;
  line-height: 4px;
  font-size: 4px;
}

.zamto-logo-badge {
  display: inline-block;
  background-color: #ffffff;
  border-radius: 10px;
  padding: 7px 12px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.16);
}

.zamto-logo-img {
  height: 38px;
  width: auto;
  max-width: 160px;
}

.zamto-brand-kicker {
  margin: 12px 0 4px;
  font-size: 11px;
  font-weight: 700;
  letter-spacing: 1.6px;
  text-transform: uppercase;
  color: #fda4af;
}

.zamto-brand-title {
  margin: 0;
  font-family: Georgia, "Playfair Display", serif;
  font-size: 22px;
  line-height: 1.25;
  font-weight: 700;
  color: #ffffff;
}

.zamto-ref-pill {
  display: inline-block;
  margin-top: 10px;
  padding: 5px 11px;
  border-radius: 6px;
  background-color: rgba(255, 255, 255, 0.14);
  border: 1px solid rgba(255, 255, 255, 0.28);
  font-family: "JetBrains Mono", ui-monospace, Menlo, Consolas, monospace;
  font-size: 12px;
  font-weight: 700;
  color: #ffffff;
  letter-spacing: 0.4px;
}

.zamto-content {
  padding: 24px 26px;
  background-color: #ffffff;
}

.zamto-intro {
  margin: 0 0 18px;
  font-size: 14px;
  line-height: 1.6;
  color: #334155;
}

.zamto-table {
  width: 100%;
  border-collapse: collapse;
  border: 1px solid #e2e8f0;
  border-radius: 10px;
  overflow: hidden;
  font-size: 13px;
}

.zamto-label {
  padding: 10px 14px;
  border-bottom: 1px solid #e2e8f0;
  background-color: #f8fafc;
  font-weight: 700;
  color: #003087;
  width: 185px;
  vertical-align: top;
}

.zamto-value {
  padding: 10px 14px;
  border-bottom: 1px solid #e2e8f0;
  color: #0f172a;
  font-weight: 500;
  vertical-align: top;
  word-break: break-word;
}

.zamto-highlight-box {
  margin-top: 18px;
  padding: 14px 16px;
  border-radius: 10px;
  background-color: #eff6ff;
  border: 1px solid #bfdbfe;
}

.zamto-highlight-title {
  margin: 0 0 4px;
  font-size: 11px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 1.1px;
  color: #003087;
}

.zamto-highlight-amount {
  margin: 0;
  font-size: 16px;
  font-weight: 700;
  color: #0f172a;
  font-variant-numeric: tabular-nums;
}

.zamto-notes-box {
  margin-top: 16px;
  padding: 13px 15px;
  border-radius: 10px;
  background-color: #f8fafc;
  border-left: 4px solid #e11d48;
  font-size: 13px;
  line-height: 1.55;
  color: #334155;
}

.zamto-cta-wrap {
  margin-top: 22px;
}

.zamto-cta-btn {
  display: inline-block;
  background-color: #e11d48;
  color: #ffffff !important;
  text-decoration: none;
  font-size: 13px;
  font-weight: 700;
  padding: 11px 20px;
  border-radius: 8px;
}

.zamto-cta-secondary {
  display: inline-block;
  margin-left: 8px;
  background-color: #003087;
  color: #ffffff !important;
  text-decoration: none;
  font-size: 13px;
  font-weight: 700;
  padding: 11px 18px;
  border-radius: 8px;
}

.zamto-footer {
  padding: 18px 26px;
  background-color: #f8fafc;
  border-top: 1px solid #e2e8f0;
  font-size: 12px;
  line-height: 1.55;
  color: #475569;
}

.zamto-footer strong {
  color: #003087;
}

.zamto-footer-links {
  margin-top: 8px;
  font-size: 11px;
  color: #64748b;
}

@media only screen and (max-width: 620px) {
  .zamto-wrapper {
    padding: 12px 8px !important;
  }

  .zamto-header,
  .zamto-content,
  .zamto-footer {
    padding: 18px 16px !important;
  }

  .zamto-brand-title {
    font-size: 19px !important;
  }

  .zamto-label,
  .zamto-value {
    display: block !important;
    width: 100% !important;
  }

  .zamto-label {
    border-bottom: none !important;
    padding-bottom: 3px !important;
  }

  .zamto-value {
    padding-top: 2px !important;
  }

  .zamto-cta-btn,
  .zamto-cta-secondary {
    display: block !important;
    width: 100% !important;
    text-align: center !important;
    margin: 8px 0 0 !important;
  }
}
`;

export interface BrandedEmailRow {
  label: string;
  value: string;
}

export interface BrandedEmailTemplateInput {
  logoUrl: string;
  siteUrl?: string;
  kind: string;
  reference: string;
  headline?: string;
  introText?: string;
  rows: BrandedEmailRow[];
  totalDisplay?: string;
  paymentSummary?: string;
  notes?: string;
  whatsappUrl?: string;
  supportEmail?: string;
  supportPhone?: string;
}

function esc(raw: unknown): string {
  return String(raw ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

export function buildBrandedResendEmailHtml(input: BrandedEmailTemplateInput): string {
  const supportEmail = input.supportEmail || 'zamtoafrica@gmail.com';
  const supportPhone = input.supportPhone || '+260 572 213 038';
  const headline = input.headline || `${input.kind} Notification`;
  const introText =
    input.introText ||
    'Thank you for choosing Zamto Africa Company Limited. Below is the official record for your submission and Lusaka dispatch reference.';

  const filteredRows = input.rows.filter((row) => Boolean(row.value && row.value.trim()));
  const tableRowsHtml = filteredRows
    .map(
      (row, idx) => `
      <tr>
        <td class="zamto-label" style="padding:10px 14px;${
          idx === filteredRows.length - 1 ? 'border-bottom:none;' : 'border-bottom:1px solid #e2e8f0;'
        }background-color:#f8fafc;font-weight:700;color:#003087;width:185px;vertical-align:top;">
          ${esc(row.label)}
        </td>
        <td class="zamto-value" style="padding:10px 14px;${
          idx === filteredRows.length - 1 ? 'border-bottom:none;' : 'border-bottom:1px solid #e2e8f0;'
        }color:#0f172a;font-weight:500;vertical-align:top;word-break:break-word;">
          ${esc(row.value)}
        </td>
      </tr>`
    )
    .join('');

  const highlightHtml =
    input.totalDisplay || input.paymentSummary
      ? `
      <div class="zamto-highlight-box" style="margin-top:18px;padding:14px 16px;border-radius:10px;background-color:#eff6ff;border:1px solid #bfdbfe;">
        <p class="zamto-highlight-title" style="margin:0 0 4px;font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:1.1px;color:#003087;">
          Zambian 16% VAT-Inclusive Summary
        </p>
        ${
          input.totalDisplay
            ? `<p class="zamto-highlight-amount" style="margin:0;font-size:16px;font-weight:700;color:#0f172a;">${esc(
                input.totalDisplay
              )}</p>`
            : ''
        }
        ${
          input.paymentSummary
            ? `<p style="margin:4px 0 0;font-size:12px;font-weight:600;color:#334155;">Payment: ${esc(
                input.paymentSummary
              )}</p>`
            : ''
        }
      </div>`
      : '';

  const notesHtml = input.notes
    ? `
      <div class="zamto-notes-box" style="margin-top:16px;padding:13px 15px;border-radius:10px;background-color:#f8fafc;border-left:4px solid #e11d48;font-size:13px;line-height:1.55;color:#334155;">
        <strong style="color:#003087;display:block;margin-bottom:4px;">Client Notes / Submission Details</strong>
        ${esc(input.notes)}
      </div>`
    : '';

  const ctaHtml =
    input.whatsappUrl || input.siteUrl
      ? `
      <div class="zamto-cta-wrap" style="margin-top:22px;">
        ${
          input.whatsappUrl
            ? `<a href="${esc(
                input.whatsappUrl
              )}" class="zamto-cta-btn" style="display:inline-block;background-color:#e11d48;color:#ffffff;text-decoration:none;font-size:13px;font-weight:700;padding:11px 20px;border-radius:8px;">Open in WhatsApp Desk</a>`
            : ''
        }
        ${
          input.siteUrl
            ? `<a href="${esc(
                input.siteUrl
              )}" class="zamto-cta-secondary" style="display:inline-block;margin-left:8px;background-color:#003087;color:#ffffff;text-decoration:none;font-size:13px;font-weight:700;padding:11px 18px;border-radius:8px;">Visit Zamto Africa</a>`
            : ''
        }
      </div>`
      : '';

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>${esc(headline)} — ${esc(input.reference)}</title>
  <style>${RESEND_GLOBAL_CSS}</style>
</head>
<body class="zamto-email-body" style="margin:0;padding:0;background-color:#f1f5f9;color:#0f172a;font-family:'Plus Jakarta Sans',Arial,sans-serif;">
  <div style="display:none;max-height:0;overflow:hidden;opacity:0;">
    Zamto Africa ${esc(input.kind)} (${esc(input.reference)}) — Rhodes Park, Lusaka
  </div>
  <div class="zamto-wrapper" style="width:100%;background-color:#f1f5f9;padding:28px 14px;">
    <div class="zamto-card" style="width:100%;max-width:640px;margin:0 auto;background-color:#ffffff;border:1px solid #cbd5e1;border-radius:16px;overflow:hidden;">
      <div class="zamto-header" style="background:linear-gradient(135deg,#003087 0%,#001d54 100%);background-color:#003087;color:#ffffff;padding:22px 26px;">
        <table role="presentation" width="100%" cellspacing="0" cellpadding="0">
          <tr>
            <td valign="middle">
              <span class="zamto-logo-badge" style="display:inline-block;background-color:#ffffff;border-radius:10px;padding:7px 12px;">
                <img src="${esc(
                  input.logoUrl
                )}" alt="Zamto Africa Logo" class="zamto-logo-img" style="height:38px;width:auto;max-width:160px;display:block;" />
              </span>
            </td>
            <td align="right" valign="middle">
              <span class="zamto-ref-pill" style="display:inline-block;padding:5px 11px;border-radius:6px;background-color:rgba(255,255,255,0.14);border:1px solid rgba(255,255,255,0.28);font-family:ui-monospace,Consolas,monospace;font-size:12px;font-weight:700;color:#ffffff;">
                ${esc(input.reference)}
              </span>
            </td>
          </tr>
        </table>
        <p class="zamto-brand-kicker" style="margin:14px 0 4px;font-size:11px;font-weight:700;letter-spacing:1.6px;text-transform:uppercase;color:#fda4af;">
          Zamto Africa Company Limited · Lusaka
        </p>
        <h1 class="zamto-brand-title" style="margin:0;font-family:Georgia,serif;font-size:22px;line-height:1.25;font-weight:700;color:#ffffff;">
          ${esc(headline)}
        </h1>
      </div>
      <div class="zamto-header-accent" style="height:4px;background-color:#e11d48;line-height:4px;font-size:4px;">&nbsp;</div>

      <div class="zamto-content" style="padding:24px 26px;background-color:#ffffff;">
        <p class="zamto-intro" style="margin:0 0 18px;font-size:14px;line-height:1.6;color:#334155;">
          ${esc(introText)}
        </p>

        <table class="zamto-table" role="presentation" width="100%" cellspacing="0" cellpadding="0" style="width:100%;border-collapse:collapse;border:1px solid #e2e8f0;font-size:13px;">
          ${tableRowsHtml}
        </table>

        ${highlightHtml}
        ${notesHtml}
        ${ctaHtml}
      </div>

      <div class="zamto-footer" style="padding:18px 26px;background-color:#f8fafc;border-top:1px solid #e2e8f0;font-size:12px;line-height:1.55;color:#475569;">
        <strong style="color:#003087;">Zamto Africa Company Limited</strong> · Rhodes Park Head Office<br />
        Corner of Katapola Road &amp; Great East Rd, Plot 1222, Lusaka, Zambia<br />
        <span class="zamto-footer-links" style="display:inline-block;margin-top:6px;font-size:11px;color:#64748b;">
          Tel / WhatsApp: ${esc(supportPhone)} · Email: ${esc(supportEmail)} · All rates include 16% Zambian VAT
        </span>
      </div>
    </div>
  </div>
</body>
</html>`;
}

export function buildResendDashboardHtmlTemplate(origin: string): string {
  const cleanOrigin = origin.replace(/\/+$/, '');
  return buildBrandedResendEmailHtml({
    logoUrl: `${cleanOrigin}${ZAMTO_BRAND_LOGO_PATH}`,
    siteUrl: cleanOrigin,
    kind: '{{kind}}',
    reference: '{{reference}}',
    headline: '{{kind}} Submission',
    introText:
      'A new form submission has been received through the Zamto Africa platform. Review the client, vehicle, and payment details below.',
    rows: [
      { label: 'Submission Type', value: '{{kind}}' },
      { label: 'Reference', value: '{{reference}}' },
      { label: 'Client Name', value: '{{customer_name}}' },
      { label: 'Phone / WhatsApp', value: '{{customer_phone}}' },
      { label: 'Client Email', value: '{{customer_email}}' },
      { label: 'Vehicle / Topic', value: '{{vehicle_or_topic}}' },
      { label: 'Pickup / Location', value: '{{pickup_location}}' },
      { label: 'Drop-off', value: '{{dropoff_location}}' },
      { label: 'Rental Dates', value: '{{date_range}}' },
    ],
    totalDisplay: '{{total_display}}',
    paymentSummary: '{{payment_summary}}',
    notes: '{{message}}',
    whatsappUrl: 'https://wa.me/260572213038',
  });
}
