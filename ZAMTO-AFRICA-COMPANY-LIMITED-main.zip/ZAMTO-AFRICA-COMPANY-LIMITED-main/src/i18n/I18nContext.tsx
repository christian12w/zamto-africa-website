import React, { createContext, useContext } from 'react';
import type { LanguageCode } from '../types';
import { TRANSLATIONS, type SiteTranslations } from './translations';

interface I18nContextValue {
  lang: LanguageCode;
  setLang: (next: LanguageCode) => void;
  t: SiteTranslations;
}

const I18nContext = createContext<I18nContextValue>({
  lang: 'en',
  setLang: () => undefined,
  t: TRANSLATIONS.en,
});

export const I18nProvider: React.FC<{
  lang: LanguageCode;
  setLang: (next: LanguageCode) => void;
  children: React.ReactNode;
}> = ({ lang, setLang, children }) => {
  const value: I18nContextValue = {
    lang,
    setLang,
    t: TRANSLATIONS[lang] || TRANSLATIONS.en,
  };
  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>;
};

export function useI18n(): I18nContextValue {
  return useContext(I18nContext);
}
