import type { LanguageCode } from '../types';

export interface SiteTranslations {
  nav: {
    home: string;
    hire: string;
    sales: string;
    locations: string;
    services: string;
    bookings: string;
    sellCar: string;
    about: string;
    faq: string;
    tips: string;
    contact: string;
    admin: string;
    compare: string;
    languageLabel: string;
  };
  mobileNav: {
    home: string;
    hire: string;
    buy: string;
    bookings: string;
    whatsapp: string;
    whatsappSupport: string;
  };
  footer: {
    tagline: string;
    trustLine: string;
    followUs: string;
    hireSalesHeading: string;
    hirePackagesLink: string;
    salesLink: string;
    sellTradeLink: string;
    viewAgreementLink: string;
    downloadPdfLink: string;
    lusakaDeliveryHeading: string;
    headOfficeMapLink: string;
    airportTransferLink: string;
    aboutLink: string;
    faqLink: string;
    tipsLink: string;
    headOfficeHeading: string;
    whatsappDeskBtn: string;
    fleetAdminBtn: string;
    rightsReserved: string;
    liveRateFooter: string;
  };
  home: {
    kicker: string;
    heroTitle: string;
    heroSub: string;
    browseHireBtn: string;
    buyVehicleBtn: string;
    whatsappDesk: string;
    dailyRateLabel: string;
    lunTransferNote: string;
    pickupPoint: string;
    dropoffPoint: string;
    pickupDate: string;
    returnDate: string;
    mapsPickerOpen: string;
    mapsPickerClosed: string;
    searchBtn: string;
    classesKicker: string;
    classesTitle: string;
    seeAllFleetPrefix: string;
    seeAllFleetSuffix: string;
    fromLabel: string;
    perDay: string;
    cityExitLabel: string;
    withinLusakaOnly: string;
    detailsBtn: string;
    bookNowBtn: string;
    hireSectionTitle: string;
    hireSectionSub: string;
    tabPopular: string;
    tabSmall: string;
    tabSuv: string;
    tabPickup: string;
    tabCommercial: string;
    salesKicker: string;
    salesSectionTitle: string;
    viewAllSalesBtn: string;
    viewDetailsBtn: string;
    pillars: { title: string; text: string }[];
    categories: Record<'Economy' | 'Sedan' | 'SUV / 4x4' | 'Pickup' | 'Van / Bus' | 'Small Truck', { title: string; subtitle: string }>;
  };
  hire: {
    liveTariffPrefix: string;
    pageTitle: string;
    pageSub: string;
    dayTripSelected: string;
    hideMap: string;
    selectOnMap: string;
    rentalAgreementBtn: string;
    hideFilters: string;
    filtersDatesBtn: string;
    filterFleetHeading: string;
    resetBtn: string;
    pickupZoneLabel: string;
    allZonesOption: string;
    pickupLabel: string;
    returnLabel: string;
    transmissionLabel: string;
    fuelLabel: string;
    anyOption: string;
    minSeatsLabel: string;
    anySeats: string;
    maxRateLabel: string;
    eligibilityHeading: string;
    policyBoxTitle: string;
    policyBoxDriver: string;
    policyBoxMileage: string;
    showingVehicles: string;
    emptyTitle: string;
    emptySub: string;
    resetAllBtn: string;
    packagesSpecsBtn: string;
    bookPayBtn: string;
    perDayPremium: string;
    depositLabel: string;
    selectTierHeading: string;
    clearBreakdownHeading: string;
    continueCheckoutBtn: string;
    requestWhatsappBtn: string;
    checkoutTitlePrefix: string;
    stepOf3: string;
    completedTitle: string;
    step1Title: string;
    step2Title: string;
    step3Title: string;
    contractTypeLabel: string;
    personalHire: string;
    companyHire: string;
    nextLicenceZone: string;
    nextPaymentAgreement: string;
    backLabel: string;
    reviewAgreement: string;
    blankPdf: string;
    dispatchConfirmedTitle: string;
    openMyBookings: string;
    sendRefWhatsapp: string;
    openSignedAgreement: string;
    downloadOfficialPdf: string;
    allCat: string;
  };
  sales: {
    kicker: string;
    buyTitle: string;
    sellTitle: string;
    subline: string;
    buyTab: string;
    sellTab: string;
    searchPlaceholder: string;
    compareSelected: string;
    filtersBtn: string;
    inventoryFilters: string;
    resetBtn: string;
    makeLabel: string;
    bodyTypeLabel: string;
    fuelLabel: string;
    transmissionLabel: string;
    conditionLabel: string;
    locationLabel: string;
    minYearLabel: string;
    maxPriceLabel: string;
    maxMileageLabel: string;
    compareCheckbox: string;
    viewDetailsBtn: string;
    financeKicker: string;
    financeHeading: string;
    compareModalTitle: string;
    compareEmpty: string;
    bookTestDrive: string;
    makeOffer: string;
    contactDealer: string;
    bankEstimatorTitle: string;
    partnerBank: string;
    depositPct: string;
    repayment: string;
    estMonthly: string;
    sellHeading: string;
    sellSub: string;
    privateSeller: string;
    dealerPartner: string;
    submitListing: string;
    valuationReceived: string;
    tradeInTitle: string;
    estOfferRange: string;
    sendPhotosWhatsapp: string;
    confirmViewing: string;
    submitOffer: string;
  };
  locations: {
    kicker: string;
    title: string;
    subtitle: string;
    hireSelectedBtn: string;
    bookDeliveryBtn: string;
  };
  services: {
    kicker: string;
    title: string;
    viewPdfBtn: string;
    airportBannerTag: string;
    browseFleetBtn: string;
    requestQuoteBtn: string;
    cards: { title: string; desc: string; points: string[] }[];
  };
  about: {
    kicker: string;
    title: string;
    p1: string;
    p2: string;
    exploreFleetBtn: string;
    agreementPdfBtn: string;
    stats: { kpi: string; label: string }[];
    values: { title: string; text: string }[];
  };
  faq: {
    kicker: string;
    title: string;
    allCat: string;
    items: { category: string; question: string; answer: string }[];
  };
  blog: {
    kicker: string;
    title: string;
    readGuideBtn: string;
  };
  contact: {
    kicker: string;
    title: string;
    subtitle: string;
    hotlineLabel: string;
    emailLabel: string;
    addressLabel: string;
    connectLabel: string;
    formTitle: string;
    fullNameLabel: string;
    phoneLabel: string;
    emailOptionalLabel: string;
    topicLabel: string;
    messageLabel: string;
    messagePlaceholder: string;
    sendBtn: string;
    sendingBtn: string;
    sentTitle: string;
    sentDesc: string;
    sendAnotherBtn: string;
    openWhatsappBtn: string;
    topics: string[];
  };
  bookings: {
    kicker: string;
    title: string;
    subtitle: string;
    newBookingBtn: string;
    emptyTitle: string;
    emptyDesc: string;
    browseHireBtn: string;
    browseSalesBtn: string;
    signedAgreementBtn: string;
    payOnlineBtn: string;
    supportBtn: string;
    cancelBtn: string;
    completePaymentTitle: string;
  };
  admin: {
    kicker: string;
    title: string;
    savedBadge: string;
    resetDefaultsBtn: string;
    fxTitle: string;
    setDailyRateBtn: string;
    syncRateBtn: string;
    syncingBtn: string;
    kpis: { hireUnits: string; salesStock: string; customerBookings: string; sellerLeads: string };
    tabs: { hire: string; sales: string; bookings: string; sellers: string };
  };
  payment: {
    payFull: string;
    payDeposit: string;
    selectMethod: string;
    momoPromptTitle: string;
    momoPhoneLabel: string;
    momoHint: string;
    cardTitle: string;
    cardRedirectNote: string;
    bankTitle: string;
    bankRefLabel: string;
    payOnlineBtnPrefix: string;
    processingBtn: string;
    liveReadyBadge: string;
    previewReadyBadge: string;
    awaitingPinMsg: string;
    verifyingMsg: string;
  };
  mapPicker: {
    titleDefault: string;
    selectingPickup: string;
    selectingDropoff: string;
    searchPlaceholder: string;
    useMyLocation: string;
    pickupPoint: string;
    dropoffPoint: string;
    sameAsPickup: string;
    routeLabel: string;
  };
}

const EN: SiteTranslations = {
  nav: {
    home: 'Home',
    hire: 'Car Hire',
    sales: 'Buy Cars',
    locations: 'Lusaka & Map',
    services: 'Services',
    bookings: 'My Bookings',
    sellCar: 'Sell Your Car',
    about: 'About',
    faq: 'FAQ',
    tips: 'Tips',
    contact: 'Contact',
    admin: 'Admin',
    compare: 'Compare',
    languageLabel: 'Language',
  },
  mobileNav: {
    home: 'Home',
    hire: 'Hire',
    buy: 'Buy',
    bookings: 'Bookings',
    whatsapp: 'WhatsApp',
    whatsappSupport: 'WhatsApp Support',
  },
  footer: {
    tagline:
      'Headquartered in Rhodes Park, Lusaka — transporting clients and delivering vehicles across all parts of Lusaka, LUN Airport, and Zambia City Exit corridors.',
    trustLine: 'RTSA Registered · JEVIC Verified · 24/7 Dispatch',
    followUs: 'Follow Zamto Africa',
    hireSalesHeading: 'Hire, Sales & Forms',
    hirePackagesLink: 'Car Hire Packages (ZMW / USD)',
    salesLink: 'Japanese Imports For Sale',
    sellTradeLink: 'Sell Your Car / Trade-In',
    viewAgreementLink: 'View Digital Rental Agreement',
    downloadPdfLink: 'Download Rental Agreement PDF',
    lusakaDeliveryHeading: 'Lusaka Delivery & Info',
    headOfficeMapLink: 'Head Office & Lusaka Map',
    airportTransferLink: 'LUN Airport Transfers (K500 / K800)',
    aboutLink: 'About Zamto Africa',
    faqLink: 'Requirements, Mileage & FAQs',
    tipsLink: 'Zambia Driving & Buying Tips',
    headOfficeHeading: 'Lusaka Head Office',
    whatsappDeskBtn: 'WhatsApp Desk',
    fleetAdminBtn: 'Fleet Admin',
    rightsReserved: 'All rights reserved.',
    liveRateFooter: 'Companies Act No. 10 of 2017 · Rhodes Park, Lusaka',
  },
  home: {
    kicker: 'Rhodes Park, Lusaka · Car Hire & Certified Imports',
    heroTitle: 'Drive Zambia Your Way',
    heroSub:
      'Based in Rhodes Park, Lusaka with door-to-door delivery across every Lusaka suburb, LUN Airport transfers, City Exit 4x4 hires & inspected Japanese vehicles for sale.',
    browseHireBtn: 'Browse Hire Fleet',
    buyVehicleBtn: 'Buy a Vehicle',
    whatsappDesk: 'WhatsApp Desk',
    dailyRateLabel: 'Daily Live Rate',
    lunTransferNote: 'LUN Transfers from K500 · MTN / Airtel / Card',
    pickupPoint: 'Pickup Point',
    dropoffPoint: 'Drop-off Point',
    pickupDate: 'Pickup Date',
    returnDate: 'Return Date',
    mapsPickerOpen: 'Close Map',
    mapsPickerClosed: 'Maps Picker',
    searchBtn: 'Search Hire Fleet',
    classesKicker: 'Vehicle Classes',
    classesTitle: 'Choose a Vehicle Type',
    seeAllFleetPrefix: 'See All',
    seeAllFleetSuffix: 'Hire Vehicles',
    fromLabel: 'From',
    perDay: '/ day',
    cityExitLabel: 'City Exit',
    withinLusakaOnly: 'Within Lusaka Only',
    detailsBtn: 'Details',
    bookNowBtn: 'Book Now',
    hireSectionTitle: 'Car Hire Packages (Premium · City Exit)',
    hireSectionSub:
      'Includes Small Cars (Passo, FIT, Mazda CX-5), City & Safari SUVs, Hilux 4WD, and Commercial Vans.',
    tabPopular: 'Popular',
    tabSmall: 'Small Cars & CX-5',
    tabSuv: 'SUV / 4×4',
    tabPickup: 'Pick-4WD',
    tabCommercial: 'Vans & Trucks',
    salesKicker: 'Certified Vehicle Sales',
    salesSectionTitle: 'Inspected Vehicles For Sale',
    viewAllSalesBtn: 'View All Sales Inventory',
    viewDetailsBtn: 'View Details',
    pillars: [
      {
        title: 'All-Lusaka Doorstep Delivery',
        text: 'Dispatched from our central Rhodes Park office directly to LUN Airport, hotels, and residences across Lusaka.',
      },
      {
        title: 'Live MoMo, Airtel & Card Checkout',
        text: 'Pay online in USD or ZMW (16% VAT inclusive) via Airtel Money, MTN MoMo, Zamtel Kwacha, Visa, Mastercard, or Zanaco EFT.',
      },
      {
        title: 'Inspected Fleet & Bank Finance',
        text: 'Full 4×4 options with optional assigned driver at K150/day plus JEVIC-verified Japanese vehicle imports.',
      },
    ],
    categories: {
      Economy: { title: 'Small Cars', subtitle: 'Passo · FIT · Mazda CX-5' },
      Sedan: { title: 'Sedans', subtitle: 'Toyota Mark X V6' },
      'SUV / 4x4': { title: 'SUV & Safari 4×4', subtitle: 'RAV4 · Forester · Prado' },
      Pickup: { title: 'Pickup 4WD', subtitle: 'Hilux Double Cab' },
      'Van / Bus': { title: 'Vans & Minibus', subtitle: 'Alphard · HIACE 4×4' },
      'Small Truck': { title: 'Cargo Trucks', subtitle: '2T & 2–3T Box Truck' },
    },
  },
  hire: {
    liveTariffPrefix: 'Zamto Africa Live Tariff',
    pageTitle: 'Hire Fleet — Premium & City Exit Packages',
    pageSub: 'Rhodes Park Head Office dispatch across all Lusaka zones · Small Cars incl. Mazda CX-5',
    dayTripSelected: 'day trip selected',
    hideMap: 'Hide Location Map',
    selectOnMap: 'Select Pickup on Map',
    rentalAgreementBtn: 'Rental Agreement',
    hideFilters: 'Hide Filters',
    filtersDatesBtn: 'Filters & Dates',
    filterFleetHeading: 'Filter Fleet',
    resetBtn: 'Reset',
    pickupZoneLabel: 'Pickup / Delivery Zone',
    allZonesOption: 'All Lusaka Zones & Corridors',
    pickupLabel: 'Pickup',
    returnLabel: 'Return',
    transmissionLabel: 'Transmission',
    fuelLabel: 'Fuel Type',
    anyOption: 'Any',
    minSeatsLabel: 'Minimum Seats',
    anySeats: 'Any seats',
    maxRateLabel: 'Max Premium Rate / Day',
    eligibilityHeading: 'Eligibility & Features',
    policyBoxTitle: 'Driver & Mileage Policy',
    policyBoxDriver: 'Drivers must be 22+ years with 2+ years licence, or add a Zamto Driver.',
    policyBoxMileage: 'Within city: 120 km/day · City Exit: 180 km/day.',
    showingVehicles: 'Showing',
    emptyTitle: 'No hire vehicles match these exact filters',
    emptySub:
      'Toyota Passo is restricted to within-Lusaka zones. Clear "City Exit Eligible" or reset filters to view all fleet units.',
    resetAllBtn: 'Reset All Filters',
    packagesSpecsBtn: 'Packages & Specs',
    bookPayBtn: 'Book & Pay',
    perDayPremium: '/ day Premium',
    depositLabel: 'Deposit',
    selectTierHeading: 'Select Hire Package Tier',
    clearBreakdownHeading: 'Clear Price Breakdown',
    continueCheckoutBtn: 'Continue to Checkout & Pay',
    requestWhatsappBtn: 'Request via WhatsApp',
    checkoutTitlePrefix: 'Zamto Africa Checkout',
    stepOf3: 'Step',
    completedTitle: 'Booking, Payment & Rental Agreement',
    step1Title: '1. Renter & ID Info',
    step2Title: '2. Licence, Zone & Tier',
    step3Title: '3. Payment & Agreement',
    contractTypeLabel: 'Contract Type:',
    personalHire: 'Personal Hire',
    companyHire: 'Company Hire',
    nextLicenceZone: 'Next: Licence & Zone',
    nextPaymentAgreement: 'Next: Payment & Agreement',
    backLabel: 'Back',
    reviewAgreement: 'Review Zamto Africa Car Rental Agreement',
    blankPdf: 'Blank PDF (11 Pages)',
    dispatchConfirmedTitle: 'Dispatched to WhatsApp (+260 572 213 038) & zamtoafrica@gmail.com',
    openMyBookings: 'Open My Bookings',
    sendRefWhatsapp: 'Send Ref to WhatsApp',
    openSignedAgreement: 'Open Signed Agreement & Receipt',
    downloadOfficialPdf: 'Download Official PDF (11 Pages)',
    allCat: 'All',
  },
  sales: {
    kicker: 'Zamto Africa Certified Marketplace',
    buyTitle: 'Japanese Imported & Local Cars For Sale',
    sellTitle: 'Sell Your Car or Estimate Trade-In',
    subline:
      'JEVIC odometer verified · ZRA duty cleared · Eligible for Zanaco, Stanbic, Absa & FNB finance',
    buyTab: 'Buy Vehicles',
    sellTab: 'Sell / Trade-In',
    searchPlaceholder: 'Search Hilux, Prado, Alphard, Lexus, CX-5...',
    compareSelected: 'Compare Selected',
    filtersBtn: 'Filters',
    inventoryFilters: 'Inventory Filters',
    resetBtn: 'Reset',
    makeLabel: 'Make',
    bodyTypeLabel: 'Body Type',
    fuelLabel: 'Fuel',
    transmissionLabel: 'Transmission',
    conditionLabel: 'Condition',
    locationLabel: 'Location',
    minYearLabel: 'Min Year',
    maxPriceLabel: 'Max Price',
    maxMileageLabel: 'Max Mileage',
    compareCheckbox: 'Compare',
    viewDetailsBtn: 'View Details',
    financeKicker: 'Zambian Asset Finance Partners',
    financeHeading: 'Bank Financing Ready Pro-Forma Invoices',
    compareModalTitle: 'Side-by-Side Vehicle Comparison',
    compareEmpty: 'Tick "Compare" on 2 or 3 vehicles to compare specifications side by side.',
    bookTestDrive: 'Book Test Drive',
    makeOffer: 'Make Offer',
    contactDealer: 'Contact Dealer',
    bankEstimatorTitle: 'Zambian Bank Financing Estimator',
    partnerBank: 'Partner Bank',
    depositPct: 'Deposit',
    repayment: 'Repayment',
    estMonthly: 'Estimated Monthly',
    sellHeading: 'List or Trade-In Your Vehicle',
    sellSub: 'Get an instant cash offer or consign at our Zamto Africa Rhodes Park showroom.',
    privateSeller: 'Private Seller',
    dealerPartner: 'Dealer Partner',
    submitListing: 'Submit Listing',
    valuationReceived: 'Valuation Request Sent to Email & WhatsApp',
    tradeInTitle: 'Instant Zambia Trade-In Estimator',
    estOfferRange: 'Estimated Trade-In / Cash Offer Range',
    sendPhotosWhatsapp: 'Send Photos via WhatsApp',
    confirmViewing: 'Confirm Viewing',
    submitOffer: 'Submit Offer',
  },
  locations: {
    kicker: 'One Central Lusaka Head Office · Google Maps Dispatch & Drop-off',
    title: 'Rhodes Park Head Office & Google Maps Delivery Planner',
    subtitle:
      'Pick any pickup and drop-off point on Google Maps across Lusaka, LUN Airport, or out-of-city corridors.',
    hireSelectedBtn: 'Hire with Selected Pickup & Drop-off',
    bookDeliveryBtn: 'Book Delivery',
  },
  services: {
    kicker: 'Official Zamto Africa Rate Card & Support',
    title: 'Airport Transfers, Chauffeurs & Lusaka Transport',
    viewPdfBtn: 'View Car Rental Agreement PDF',
    airportBannerTag: 'Airport Transfer Service',
    browseFleetBtn: 'Browse Fleet',
    requestQuoteBtn: 'Request Quote',
    cards: [
      {
        title: 'LUN Airport Transfers & All-Lusaka Transport',
        desc: '4-hour Airport Transfer Service with fuel, driver, and insurance included—transporting clients from Kenneth Kaunda Airport (LUN) to any hotel or neighbourhood across Lusaka.',
        points: [
          'Small Car (4 hrs): K500',
          'Business Van / SUV (4 hrs): K800',
          'Overtime: +K60 / 30 min (Daytime) · +K80 / 30 min (Nighttime)',
        ],
      },
      {
        title: 'Long-Term Corporate, NGO & City Exit Fleet',
        desc: 'Hilux, Ford Ranger, Mitsubishi Triton, Prado, and 1–2T Box Trucks dispatched from our Rhodes Park HQ with preventative maintenance and clear Within-City vs City Exit contracts.',
        points: [
          'Within City: 120 km/day (K15/km excess)',
          'Out of City (City Exit): 180 km/day (K20/km excess)',
          'VAT (16%) formal invoicing under Companies Act No. 10 of 2017',
        ],
      },
      {
        title: 'Assigned Chauffeur for International Clients',
        desc: 'Dedicated Zamto Africa driver option—mandatory if renter is under 22 or has under 2 years driving experience, and ideal for international business travellers.',
        points: [
          'Assigned Driver within Lusaka: K150 / day',
          "Driver's meals already included",
          '7 International Languages (EN · 中文 · FR · PT · ES · DE · 日本語)',
        ],
      },
      {
        title: 'Official Digital Rental Agreement & Inspection',
        desc: 'Transparent terms covering Option A Base Rate vs Option B Inclusive Rate (deductible waived) plus joint pickup & return Vehicle Inspection Reports.',
        points: [
          'Digital signature & document pre-upload before arrival',
          'Includes 11-page PDF with Vehicle Inspection Report',
          'Zambia Police & 24/7 office emergency support',
        ],
      },
    ],
  },
  about: {
    kicker: 'Rhodes Park, Lusaka · Companies Act No. 10 of 2017',
    title: 'Zamto Africa — Your Trusted Partner in Automotive Freedom',
    p1: 'Registered in Zambia with our single physical head office & showroom at Corner of Katapola Road & Great East Rd, Plot 1222, Rhodes Park, Lusaka, Zamto Africa Company Limited combines car hire, all-Lusaka client & vehicle transport, and verified Japanese imported vehicle sales.',
    p2: 'From single-day city Passo hires (K800) and K500 LUN airport transfers to multi-month City Exit 4x4 Hilux leases, our team serves both Zambian residents and international arrivals with transparent ZMW and live daily USD pricing.',
    exploreFleetBtn: 'Explore Hire Fleet',
    agreementPdfBtn: 'Rental Agreement PDF',
    stats: [
      { kpi: '1 Central HQ', label: 'Corner of Katapola Rd & Great East Rd, Rhodes Park' },
      { kpi: 'All Lusaka', label: 'Door-to-door client & vehicle delivery across all zones' },
      { kpi: '7 Languages', label: 'EN · 中文 · FR · PT · ES · DE · 日本語' },
      { kpi: 'Live Daily FX', label: 'Real-time ZMW & USD pricing conversion' },
    ],
    values: [
      {
        title: 'Clear Package Tiers',
        text: 'Every model lists clear Basic (Option A), Premium (Option B deductible waived), and City Exit out-of-town rates.',
      },
      {
        title: 'Joint Inspection Reports',
        text: 'Every hire is documented at handover and return with tyres, fluids, spare wheel, safety kit, and fuel checked together.',
      },
      {
        title: 'Verified Sales Transparency',
        text: 'Every car for sale carries authentic mileage certificates, inspection sheets, and financing invoices.',
      },
    ],
  },
  faq: {
    kicker: 'Zambia Driving & Rental Agreement Guide',
    title: 'Frequently Asked Questions',
    allCat: 'All',
    items: [
      {
        category: 'Licences & Requirements',
        question: 'What documents, age, and experience do I need to rent a car from Zamto Africa?',
        answer:
          'You need (1) Valid ID (Passport or Zambian NRC), (2) Proof of Residence (utility bill or hotel booking), and (3) A valid driving licence held for at least 2 years. Drivers must be aged 22+. Otherwise a Zamto Africa driver is assigned at K150/day within Lusaka (meals included).',
      },
      {
        category: 'Lusaka Delivery & Coverage',
        question: 'Do you only operate in Lusaka, and can you deliver a vehicle to my hotel or home?',
        answer:
          'Our central office is at Corner of Katapola Road & Great East Road (Plot 1222, Rhodes Park, Lusaka). We deliver vehicles across all parts of Lusaka—including LUN Airport, Kabulonga, Woodlands, CBD, Roma, and Makeni—and clear City Exit rentals for Livingstone, Ndola, Kitwe, and Solwezi.',
      },
      {
        category: 'Packages, Mileage & Insurance',
        question: 'What is the difference between Basic, Premium, and City Exit Packages?',
        answer:
          'Basic (Option A) covers Within-City Lusaka travel (120 km/day; K15/km excess) with standard deductible. Premium (Option B) waives the insurance deductible/excess for covered damage or theft. City Exit authorises out-of-city travel across Zambia (180 km/day; K20/km excess).',
      },
      {
        category: 'Airport Transfers & Overtime',
        question: 'How much are Kenneth Kaunda (LUN) airport transfers?',
        answer:
          'A 4-hour Small Car Airport Transfer is K500 and a Business Van or SUV transfer is K800 (converted to USD at our daily live rate), inclusive of fuel, driver, and insurance. Overtime beyond 4 hours is K60/30 min (daytime) or K80/30 min (nighttime).',
      },
    ],
  },
  blog: {
    kicker: 'Local Insights',
    title: 'Driving in Zambia & Buyer Guides',
    readGuideBtn: 'Read Guide',
  },
  contact: {
    kicker: 'Lusaka Head Office · All-Lusaka Dispatch',
    title: 'Speak With Zamto Africa',
    subtitle:
      'Every inquiry sent here is dispatched to zamtoafrica@gmail.com and our WhatsApp desk (+260 572 213 038) for immediate assistance.',
    hotlineLabel: 'WhatsApp & Hotline',
    emailLabel: 'Email',
    addressLabel: 'Head Office Address',
    connectLabel: 'Connect With Us',
    formTitle: 'Send an Inquiry (Email & WhatsApp Dispatch)',
    fullNameLabel: 'Full Name *',
    phoneLabel: 'Phone / WhatsApp *',
    emailOptionalLabel: 'Email Address',
    topicLabel: 'Topic',
    messageLabel: 'Message *',
    messagePlaceholder: 'Share dates, Lusaka delivery area, or vehicle model...',
    sendBtn: 'Send to Email & WhatsApp',
    sendingBtn: 'Dispatching...',
    sentTitle: 'Inquiry Dispatched',
    sentDesc: 'Your inquiry has been logged for our Lusaka reservations desk.',
    sendAnotherBtn: 'Send Another Inquiry',
    openWhatsappBtn: 'Open Message in WhatsApp (+260 572 213 038)',
    topics: [
      'Car Hire & LUN/Lusaka Delivery',
      '4-Hour Airport Transfer (K500 / K800)',
      'Buying a Vehicle / Financing',
      'Corporate Lease / City Exit Permit',
    ],
  },
  bookings: {
    kicker: 'Customer Reservations & Contracts',
    title: 'My Bookings, Payments & Agreements',
    subtitle:
      'Track your Zamto Africa car hire pickups, settle online via MoMo or Card, and open your signed Rental Agreement anytime.',
    newBookingBtn: 'New Vehicle Booking',
    emptyTitle: 'No Active Bookings Yet',
    emptyDesc:
      'Reserve a vehicle from our Lusaka & Zambia fleet to receive an instant digital Rental Agreement and online payment receipt.',
    browseHireBtn: 'Browse Car Hire',
    browseSalesBtn: 'Browse Cars For Sale',
    signedAgreementBtn: 'Signed Agreement',
    payOnlineBtn: 'Pay Online',
    supportBtn: 'Support',
    cancelBtn: 'Cancel',
    completePaymentTitle: 'Complete Payment',
  },
  admin: {
    kicker: 'Operations & Fleet Control',
    title: 'Admin: Edit Vehicles, Photos, Rates & Bookings',
    savedBadge: 'All edits save immediately',
    resetDefaultsBtn: 'Reset Fleet to Defaults',
    fxTitle: 'Daily USD / ZMW Exchange Rate Control',
    setDailyRateBtn: 'Set Daily Rate',
    syncRateBtn: 'Sync Market Rate',
    syncingBtn: 'Syncing...',
    kpis: {
      hireUnits: 'Hire Fleet Units',
      salesStock: 'Sales Stock Available',
      customerBookings: 'Customer Bookings',
      sellerLeads: 'Seller Valuation Leads',
    },
    tabs: {
      hire: 'Hire Fleet',
      sales: 'Sales Inventory',
      bookings: 'Bookings',
      sellers: 'Seller Leads',
    },
  },
  payment: {
    payFull: 'Pay Full Rental Now',
    payDeposit: '30% Booking Lock Deposit',
    selectMethod: 'Select Online Payment Method (Lenco Zambia)',
    momoPromptTitle: 'Live Mobile Money Prompt (Lenco)',
    momoPhoneLabel: 'Mobile Money Phone Number (+260 / 097 / 096 / 095)',
    momoHint:
      'Sends a live Lenco Mobile Money USSD PIN prompt directly to your Airtel, MTN, or Zamtel handset and dispatches confirmation to WhatsApp & Email.',
    cardTitle: 'Secure Card Checkout (Visa / Mastercard)',
    cardRedirectNote:
      'Processes securely via Lenco Pay / PCI-DSS card gateway supporting Visa & Mastercard.',
    bankTitle: 'Zamto Africa Company Limited — Online Bank EFT',
    bankRefLabel: 'Optional Zanaco EFT / Transfer Reference (or leave blank for pending online verification)',
    payOnlineBtnPrefix: 'Pay',
    processingBtn: 'Connecting Lenco...',
    liveReadyBadge: 'Lenco Live Gateway Connected',
    previewReadyBadge: 'Online Verification & WhatsApp Dispatch Ready',
    awaitingPinMsg: 'Lenco USSD PIN prompt sent — Approve payment on your phone...',
    verifyingMsg: 'Verifying transaction with Lenco gateway...',
  },
  mapPicker: {
    titleDefault: 'Google Maps Pickup & Drop-off Selector Across Zambia',
    selectingPickup: 'Setting Pickup (A)',
    selectingDropoff: 'Setting Drop-off (B)',
    searchPlaceholder: 'Search Lusaka hotel, mall, airport, or Zambia city...',
    useMyLocation: 'My Location',
    pickupPoint: 'Pickup Point (A)',
    dropoffPoint: 'Drop-off Point (B)',
    sameAsPickup: 'Same as pickup',
    routeLabel: 'Estimated Driving Route',
  },
};

const ZH: SiteTranslations = {
  nav: {
    home: '首页',
    hire: '车辆租赁',
    sales: '车辆买卖',
    locations: '卢萨卡与地图',
    services: '机场与专车',
    bookings: '我的订单',
    sellCar: '卖车/置换',
    about: '关于我们',
    faq: '常见问题',
    tips: '用车指南',
    contact: '联系我们',
    admin: '后台管理',
    compare: '对比',
    languageLabel: '语言',
  },
  mobileNav: {
    home: '首页',
    hire: '租车',
    buy: '买车',
    bookings: '订单',
    whatsapp: 'WhatsApp',
    whatsappSupport: 'WhatsApp 客服',
  },
  footer: {
    tagline:
      '总部位于卢萨卡 Rhodes Park，为卢萨卡全城、LUN 国际机场及赞比亚跨城路线提供上门取送车与专车服务。',
    trustLine: 'RTSA 注册 · JEVIC 认证 · 全天候调度',
    followUs: '关注 Zamto Africa',
    hireSalesHeading: '租车、购车与合同',
    hirePackagesLink: '租车价格套餐 (ZMW / USD)',
    salesLink: '日本进口在售车辆',
    sellTradeLink: '卖车 / 置换估价',
    viewAgreementLink: '查看电子租车协议',
    downloadPdfLink: '下载官方租车协议 PDF',
    lusakaDeliveryHeading: '卢萨卡配送与指南',
    headOfficeMapLink: '总部位置与谷歌地图选点',
    airportTransferLink: 'LUN 机场接送 (K500 / K800)',
    aboutLink: '关于 Zamto Africa',
    faqLink: '证件、里程与常见问题',
    tipsLink: '赞比亚驾驶与购车指南',
    headOfficeHeading: '卢萨卡总部地址',
    whatsappDeskBtn: 'WhatsApp 客服',
    fleetAdminBtn: '车队管理',
    rightsReserved: '保留所有权利。',
    liveRateFooter: '赞比亚公司法第10号注册 · 卢萨卡 Rhodes Park',
  },
  home: {
    kicker: '卢萨卡 Rhodes Park · 专业租车与认证进口车销售',
    heroTitle: '畅行赞比亚 · 尊享出行体验',
    heroSub:
      '总部位于卢萨卡 Rhodes Park，提供卢萨卡全城上门送车、LUN 机场接送、出城四驱越野租赁及优质日本进口车销售（支持克瓦查 ZMW 与美元 USD）。',
    browseHireBtn: '浏览可租车队',
    buyVehicleBtn: '购买认证车辆',
    whatsappDesk: 'WhatsApp 咨询',
    dailyRateLabel: '当日实时汇率',
    lunTransferNote: 'LUN 机场接送 K500 起 · 支持 MTN / Airtel / 银行卡',
    pickupPoint: '取车地点',
    dropoffPoint: '还车地点',
    pickupDate: '取车日期',
    returnDate: '还车日期',
    mapsPickerOpen: '收起地图',
    mapsPickerClosed: '地图选点',
    searchBtn: '搜索可租车辆',
    classesKicker: '车型分类',
    classesTitle: '选择您的理想车型',
    seeAllFleetPrefix: '查看全部',
    seeAllFleetSuffix: '款可租车辆',
    fromLabel: '起价',
    perDay: '/ 天',
    cityExitLabel: '出城价',
    withinLusakaOnly: '仅限卢萨卡市内',
    detailsBtn: '查看详情',
    bookNowBtn: '立即预订',
    hireSectionTitle: '租车套餐与价格（市内尊享 · 出城套餐）',
    hireSectionSub: '涵盖经济小车 (Passo, FIT, Mazda CX-5)、城市与safari越野 SUV、Hilux 四驱皮卡及商务面包车。',
    tabPopular: '热门车型',
    tabSmall: '经济小车 & CX-5',
    tabSuv: 'SUV / 4×4 越野',
    tabPickup: '四驱皮卡',
    tabCommercial: '商务车 & 货车',
    salesKicker: '认证现车销售',
    salesSectionTitle: '精选在售日本进口车',
    viewAllSalesBtn: '查看全部在售车辆',
    viewDetailsBtn: '查看详情',
    pillars: [
      { title: '卢萨卡全城上门送取车', text: '从 Rhodes Park 总部直接派送至 LUN 机场、各大酒店及卢萨卡各住宅区。' },
      { title: '支持移动支付与国际银行卡', text: '支持 MTN MoMo、Airtel Money、Visa、Mastercard 或门店 POS 实时结算。' },
      { title: '严格车检与银行分期支持', text: '提供 K150/天专职司机选项及 JEVIC 认证里程的日本进口二手车。' },
    ],
    categories: {
      Economy: { title: '经济型小车', subtitle: 'Passo · FIT · Mazda CX-5' },
      Sedan: { title: '行政轿车', subtitle: 'Toyota Mark X V6' },
      'SUV / 4x4': { title: '四驱 SUV / 越野', subtitle: 'RAV4 · Forester · Prado' },
      Pickup: { title: '四驱双排皮卡', subtitle: 'Hilux 双排 4WD' },
      'Van / Bus': { title: '商务车 & 中巴', subtitle: 'Alphard · HIACE 4×4' },
      'Small Truck': { title: '厢式轻卡货车', subtitle: '2吨及2–3吨封闭货车' },
    },
  },
  hire: {
    ...EN.hire,
    liveTariffPrefix: 'Zamto Africa 实时价目表',
    pageTitle: '可租车队 — 市内尊享与出城套餐',
    pageSub: '卢萨卡 Rhodes Park 总部全城配送 · 含 Mazda CX-5 等小型车',
    dayTripSelected: '天行程',
    hideMap: '隐藏地图',
    selectOnMap: '地图选择取还车点',
    rentalAgreementBtn: '查看租车协议',
    hideFilters: '隐藏筛选',
    filtersDatesBtn: '筛选与日期',
    filterFleetHeading: '筛选车队',
    resetBtn: '重置',
    pickupZoneLabel: '取车 / 送车区域',
    allZonesOption: '卢萨卡所有区域及跨城路线',
    pickupLabel: '取车日期',
    returnLabel: '还车日期',
    transmissionLabel: '变速箱',
    fuelLabel: '燃油类型',
    anyOption: '不限',
    minSeatsLabel: '最少座位数',
    anySeats: '不限座位数',
    maxRateLabel: '最高日租金上限',
    eligibilityHeading: '配置与出行范围',
    policyBoxTitle: '司机与里程政策',
    policyBoxDriver: '驾驶员需年满22周岁且驾龄2年以上，或加选 K150/天 Zamto 专职司机。',
    policyBoxMileage: '市内每日限120公里 · 出城每日限180公里。',
    showingVehicles: '当前显示',
    emptyTitle: '暂无符合筛选条件的车辆',
    emptySub: 'Toyota Passo 仅限卢萨卡市内使用，请取消勾选或重置筛选条件以查看所有车辆。',
    resetAllBtn: '重置所有筛选条件',
    packagesSpecsBtn: '套餐与配置',
    bookPayBtn: '预订并支付',
    perDayPremium: '/ 天 (尊享)',
    depositLabel: '押金',
    selectTierHeading: '选择租车套餐级别',
    clearBreakdownHeading: '透明价格明细',
    continueCheckoutBtn: '前往结账与签约',
    requestWhatsappBtn: '通过 WhatsApp 咨询',
    checkoutTitlePrefix: 'Zamto Africa 结账',
    stepOf3: '第',
    completedTitle: '预订、支付与电子租车协议已完成',
    step1Title: '1. 租车人及证件',
    step2Title: '2. 驾照、区域与套餐',
    step3Title: '3. 支付与电子签约',
    contractTypeLabel: '合同类型：',
    personalHire: '个人租车',
    companyHire: '企业用车',
    nextLicenceZone: '下一步：驾照与区域',
    nextPaymentAgreement: '下一步：支付与协议',
    backLabel: '返回',
    reviewAgreement: '阅读 Zamto Africa 租车协议条款',
    blankPdf: '空白协议 PDF (11页)',
    dispatchConfirmedTitle: '预订详情已同步发送至 WhatsApp (+260 572 213 038) 与 zamtoafrica@gmail.com',
    openMyBookings: '查看我的订单',
    sendRefWhatsapp: '发送订单号到 WhatsApp',
    openSignedAgreement: '打开已签署协议与收据',
    downloadOfficialPdf: '下载完整官方协议 PDF',
    allCat: '全部',
  },
  sales: {
    ...EN.sales,
    kicker: 'Zamto Africa 认证车辆交易中心',
    buyTitle: '精选日本进口与本地优质在售车辆',
    sellTitle: '出售爱车或置换估价',
    subline: 'JEVIC 真实里程认证 · ZRA 关税已清 · 支持 Zanaco、Stanbic、Absa 及 FNB 银行分期',
    buyTab: '购买车辆',
    sellTab: '卖车 / 置换',
    searchPlaceholder: '搜索 Hilux, Prado, Alphard, Lexus, CX-5...',
    compareSelected: '对比所选车辆',
    filtersBtn: '筛选',
    inventoryFilters: '车辆筛选',
    resetBtn: '重置',
    makeLabel: '品牌',
    bodyTypeLabel: '车身类型',
    fuelLabel: '燃油',
    transmissionLabel: '变速箱',
    conditionLabel: '车况来源',
    locationLabel: '所在位置',
    minYearLabel: '最低年份',
    maxPriceLabel: '最高预算',
    maxMileageLabel: '最大里程',
    compareCheckbox: '加入对比',
    viewDetailsBtn: '查看详情',
    financeKicker: '赞比亚合作银行车贷',
    financeHeading: '提供银行按揭专用形式发票',
    compareModalTitle: '车辆参数横向对比',
    compareEmpty: '请勾选 2 至 3 辆车进行横向参数对比。',
    bookTestDrive: '预约试驾',
    makeOffer: '提交报价',
    contactDealer: '联系销售顾问',
    bankEstimatorTitle: '赞比亚银行车贷月供计算器',
    partnerBank: '合作银行',
    depositPct: '首付比例',
    repayment: '分期月数',
    estMonthly: '预估月供',
    sellHeading: '登记卖车或置换估价',
    sellSub: '快速获取现金报价或在 Rhodes Park 展厅寄售。',
    privateSeller: '个人车主',
    dealerPartner: '合作车商',
    submitListing: '提交车辆信息',
    valuationReceived: '估价请求已发送至邮箱与 WhatsApp',
    tradeInTitle: '赞比亚即时置换估价器',
    estOfferRange: '预估收购/置换价格区间',
    sendPhotosWhatsapp: '通过 WhatsApp 发送实车照片',
    confirmViewing: '确认预约看车',
    submitOffer: '确认提交报价',
  },
  locations: {
    kicker: '卢萨卡单一总部 · 谷歌地图全城取还车规划',
    title: 'Rhodes Park 总部与谷歌地图接送规划',
    subtitle: '直接在谷歌地图上选择卢萨卡市内、LUN 机场或跨城出行的取还车地点。',
    hireSelectedBtn: '按所选地点立即租车',
    bookDeliveryBtn: '预订上门配送',
  },
  services: {
    kicker: 'Zamto Africa 官方价格表与服务支持',
    title: 'LUN 机场接送、专职司机与卢萨卡全城运输',
    viewPdfBtn: '查看租车协议 PDF',
    airportBannerTag: '机场专车接送服务',
    browseFleetBtn: '浏览车队',
    requestQuoteBtn: '获取报价',
    cards: [
      {
        title: 'LUN 机场接送与卢萨卡全城用车',
        desc: '4小时机场专车接送含油费、司机与保险，从卡翁达国际机场 (LUN) 直达卢萨卡任意酒店或住宅。',
        points: ['经济小车 (4小时): K500', '商务车 / SUV (4小时): K800', '超时费: 日间 +K60/30分钟 · 夜间 +K80/30分钟'],
      },
      {
        title: '企业长租、NGO 与出城越野车队',
        desc: '从 Rhodes Park 总部调度 Hilux、Ranger、Triton、Prado 及轻卡货车，支持市内与出城合同。',
        points: ['市内限额: 120公里/天 (超额 K15/公里)', '出城限额: 180公里/天 (超额 K20/公里)', '可开具 16% 正式 VAT 发票'],
      },
      {
        title: '国际客户专职司机服务',
        desc: '专为未满22岁或驾龄不足2年的客户以及国际商旅人士配备经验丰富的 Zamto 专职司机。',
        points: ['卢萨卡市内专职司机: K150 / 天', '费用已包含司机餐费', '支持 7 种国际语言 (EN · 中文 · FR · PT · ES · DE · 日本語)'],
      },
      {
        title: '官方电子租车协议与联合验车',
        desc: '清晰区分 Option A 基础险与 Option B 全险（免赔付），交车与还车现场共同签署验车单。',
        points: ['抵达前在线提交驾照与护照', '提供含验车单在内的 11 页官方 PDF 合同', '24小时应急调度与道路协助'],
      },
    ],
  },
  about: {
    kicker: '卢萨卡 Rhodes Park · 赞比亚公司法注册',
    title: 'Zamto Africa — 您在赞比亚值得信赖的出行伙伴',
    p1: 'Zamto Africa 总部及展厅位于卢萨卡 Rhodes Park（Katapola Rd 与 Great East Rd 交汇处 1222 号地块），提供租车、全城专车接送及认证日本进口车销售服务。',
    p2: '无论单日市内代步、LUN 机场接送还是矿区越野长租，我们均提供透明的克瓦查 ZMW 与每日实时美元 USD 报价。',
    exploreFleetBtn: '浏览租车车队',
    agreementPdfBtn: '下载租车协议 PDF',
    stats: [
      { kpi: '1 处核心总部', label: '卢萨卡 Rhodes Park 实体展厅与调度中心' },
      { kpi: '卢萨卡全城', label: '覆盖所有城区、酒店与 LUN 机场的门到门配送' },
      { kpi: '7 种国际语言', label: 'EN · 中文 · FR · PT · ES · DE · 日本語' },
      { kpi: '实时日汇率', label: '透明的克瓦查 ZMW 与美元 USD 自动换算' },
    ],
    values: [
      { title: '清晰透明套餐', text: '每款车型均明确列出市内基础价、尊享免赔价与出城跨区价格。' },
      { title: '交还车联合验车', text: '取还车现场核对轮胎、油量、备胎与安全套件并双方签字确认。' },
      { title: '真实进口车况', text: '所有在售车辆均提供 JEVIC 里程认证、海关清关单及银行按揭支持。' },
    ],
  },
  faq: {
    kicker: '赞比亚驾驶与租车协议指南',
    title: '常见问题解答',
    allCat: '全部',
    items: [
      {
        category: '驾照与证件要求',
        question: '在 Zamto Africa 租车需要哪些证件与驾龄条件？',
        answer: '您需要提供有效护照或赞比亚身份证 (NRC)、住址/酒店预订单及持有满2年的有效正式驾照，且年满22周岁。否则可按 K150/天配属 Zamto 专职司机（含餐费）。',
      },
      {
        category: '卢萨卡全城配送',
        question: '你们只在一个地点办公吗？能否送车到酒店或住所？',
        answer: '我们的实体总部位于卢萨卡 Rhodes Park，并可调度车辆与专车司机送达 LUN 机场、Kabulonga、Woodlands、CBD、Roma 及 Makeni 等全城各区，同时办理赴利文斯顿、铜带省与索卢韦齐的出城用车。',
      },
      {
        category: '套餐、里程与保险',
        question: 'Basic、Premium 与 City Exit 套餐有什么区别？',
        answer: 'Basic (Option A) 为市内基础价（120公里/天）；Premium (Option B) 豁免覆盖范围内的保险免赔额；City Exit 授权跨城行驶（180公里/天，超额 K20/公里）。',
      },
      {
        category: '机场接送与超时费',
        question: 'LUN 肯尼思·卡翁达机场接送费用是多少？',
        answer: '4小时小车接送 K500，商务面包车或 SUV K800（含油费、司机与保险）。超出4小时白天加收 K60/30分钟，夜间加收 K80/30分钟。',
      },
    ],
  },
  blog: { kicker: '本地出行百科', title: '赞比亚驾驶与购车实用指南', readGuideBtn: '阅读全文' },
  contact: {
    ...EN.contact,
    kicker: '卢萨卡总部 · 全城调度响应',
    title: '联系 Zamto Africa',
    subtitle: '您提交的每一条咨询都将同步发送至 zamtoafrica@gmail.com 与官方 WhatsApp (+260 572 213 038)。',
    hotlineLabel: 'WhatsApp 与热线电话',
    emailLabel: '电子邮箱',
    addressLabel: '总部地址',
    connectLabel: '社交媒体',
    formTitle: '发送咨询（自动同步至邮箱与 WhatsApp）',
    fullNameLabel: '您的姓名 *',
    phoneLabel: '联系电话 / WhatsApp *',
    emailOptionalLabel: '电子邮箱',
    topicLabel: '咨询主题',
    messageLabel: '详细需求 *',
    messagePlaceholder: '请告知用车日期、卢萨卡送车地点或意向车型...',
    sendBtn: '发送至邮箱与 WhatsApp',
    sendingBtn: '正在发送...',
    sentTitle: '咨询已成功发送',
    sentDesc: '我们的卢萨卡预订专员将尽快回复您。',
    sendAnotherBtn: '再次发送咨询',
    openWhatsappBtn: '在 WhatsApp 中直接发送 (+260 572 213 038)',
    topics: ['租车与卢萨卡/机场配送', '4小时机场专车接送 (K500 / K800)', '购车咨询与银行车贷', '企业长租 / 出城许可'],
  },
  bookings: {
    ...EN.bookings,
    kicker: '客户订单与电子合同',
    title: '我的订单、支付记录与协议',
    subtitle: '查看您的取车安排、通过移动钱包或银行卡在线结算并随时查看已签署的电子合同。',
    newBookingBtn: '新建租车预订',
    emptyTitle: '暂无订单记录',
    emptyDesc: '预订车辆后可在此查看电子租车协议与在线支付收据。',
    browseHireBtn: '浏览租车车队',
    browseSalesBtn: '浏览在售车辆',
    signedAgreementBtn: '已签署协议',
    payOnlineBtn: '在线支付',
    supportBtn: '客服支持',
    cancelBtn: '取消订单',
    completePaymentTitle: '完成订单支付',
  },
  admin: {
    ...EN.admin,
    kicker: '车队运营管理后台',
    title: '后台管理：编辑车辆、图片、价格与订单',
    savedBadge: '所有修改即时保存',
    resetDefaultsBtn: '恢复默认车队数据',
    fxTitle: '每日美元 / 克瓦查汇率控制',
    setDailyRateBtn: '设定汇率',
    syncRateBtn: '同步市场汇率',
    syncingBtn: '同步中...',
    kpis: { hireUnits: '在租车型数量', salesStock: '在售现车数量', customerBookings: '客户预订总数', sellerLeads: '卖车估价线索' },
    tabs: { hire: '租车车队', sales: '销售库存', bookings: '客户订单', sellers: '卖车线索' },
  },
  payment: {
    ...EN.payment,
    payFull: '全额支付租金',
    payDeposit: '支付 30% 锁车定金',
    selectMethod: '选择在线支付方式 (Lenco Zambia)',
    momoPromptTitle: '实时移动钱包推送',
    momoPhoneLabel: '移动钱包手机号码 (+260)',
    momoHint: '向您的手机发送实时 USSD 确认请求，并将确认回执发送至 WhatsApp 与邮箱。',
    cardTitle: '安全银行卡支付 (Visa / Mastercard)',
    cardRedirectNote: '安全跳转至支持 ZMW 与 USD 的加密银行卡支付网关。',
    bankTitle: 'Zamto Africa 公司网上银行转账',
    bankRefLabel: '银行转账参考号（选填，留空则进入在线核验）',
    payOnlineBtnPrefix: '立即支付',
    processingBtn: '正在连接支付网关...',
    liveReadyBadge: '在线支付网关已连接',
    previewReadyBadge: '在线核验与 WhatsApp 通知已就绪',
    awaitingPinMsg: '已发送 USSD PIN 请求 — 请在手机上输入密码确认...',
    verifyingMsg: '正在与支付网关核验交易状态...',
  },
  mapPicker: {
    titleDefault: '赞比亚谷歌地图取车与还车选点',
    selectingPickup: '正在设置取车点 (A)',
    selectingDropoff: '正在设置还车点 (B)',
    searchPlaceholder: '搜索卢萨卡酒店、商场、机场或赞比亚城市...',
    useMyLocation: '当前位置',
    pickupPoint: '取车点 (A)',
    dropoffPoint: '还车点 (B)',
    sameAsPickup: '同取车点',
    routeLabel: '预估驾驶路线',
  },
};

const FR: SiteTranslations = {
  ...EN,
  nav: {
    home: 'Accueil',
    hire: 'Location',
    sales: 'Acheter',
    locations: 'Carte & Zones',
    services: 'Services',
    bookings: 'Réservations',
    sellCar: 'Vendre',
    about: 'À propos',
    faq: 'FAQ',
    tips: 'Conseils',
    contact: 'Contact',
    admin: 'Admin',
    compare: 'Comparer',
    languageLabel: 'Langue',
  },
  mobileNav: {
    home: 'Accueil',
    hire: 'Louer',
    buy: 'Acheter',
    bookings: 'Dossiers',
    whatsapp: 'WhatsApp',
    whatsappSupport: 'Support WhatsApp',
  },
  footer: {
    ...EN.footer,
    tagline:
      'Basé à Rhodes Park, Lusaka — transport de clients et livraison de véhicules dans tout Lusaka, à l’aéroport LUN et hors de la ville.',
    followUs: 'Suivre Zamto Africa',
    hireSalesHeading: 'Location, Ventes & Contrats',
    hirePackagesLink: 'Tarifs de Location (ZMW / USD)',
    salesLink: 'Imports Japonais à Vendre',
    sellTradeLink: 'Vendre / Reprise Véhicule',
    viewAgreementLink: 'Voir le Contrat de Location',
    downloadPdfLink: 'Télécharger le Contrat PDF',
    lusakaDeliveryHeading: 'Livraison Lusaka & Infos',
    headOfficeMapLink: 'Siège & Carte Google Maps',
    airportTransferLink: 'Transferts Aéroport LUN (K500 / K800)',
    aboutLink: 'À propos de Zamto Africa',
    faqLink: 'Documents, Kilométrage & FAQ',
    tipsLink: 'Conseils Conduite & Achat Zambie',
    headOfficeHeading: 'Siège Social Lusaka',
    whatsappDeskBtn: 'Bureau WhatsApp',
    fleetAdminBtn: 'Gestion Flotte',
    rightsReserved: 'Tous droits réservés.',
  },
  home: {
    ...EN.home,
    kicker: 'Rhodes Park, Lusaka · Location & Importations Certifiées',
    heroTitle: 'Conduisez la Zambie à Votre Rythme',
    heroSub:
      'Basé à Rhodes Park, Lusaka — livraison porte-à-porte dans tout Lusaka, transferts aéroport LUN, 4x4 hors ville et véhicules japonais certifiés à vendre.',
    browseHireBtn: 'Voir la Flotte',
    buyVehicleBtn: 'Acheter un Véhicule',
    whatsappDesk: 'Bureau WhatsApp',
    dailyRateLabel: 'Taux du Jour',
    pickupPoint: 'Lieu de Prise en Charge',
    dropoffPoint: 'Lieu de Retour',
    pickupDate: 'Date de Départ',
    returnDate: 'Date de Retour',
    mapsPickerOpen: 'Fermer Carte',
    mapsPickerClosed: 'Carte Google',
    searchBtn: 'Rechercher',
    classesKicker: 'Catégories',
    classesTitle: 'Choisir un Type de Véhicule',
    seeAllFleetPrefix: 'Voir les',
    seeAllFleetSuffix: 'Véhicules',
    fromLabel: 'Dès',
    perDay: '/ jour',
    cityExitLabel: 'Hors Ville',
    withinLusakaOnly: 'Lusaka Uniquement',
    detailsBtn: 'Détails',
    bookNowBtn: 'Réserver',
    hireSectionTitle: 'Forfaits Location (Premium · Hors Ville)',
    hireSectionSub: 'Petites voitures (Passo, FIT, Mazda CX-5), SUV Safari 4×4, Hilux et minibus.',
    tabPopular: 'Populaires',
    tabSmall: 'Citadines & CX-5',
    tabSuv: 'SUV / 4×4',
    tabPickup: 'Pick-up 4×4',
    tabCommercial: 'Vans & Camions',
    salesKicker: 'Ventes Certifiées',
    salesSectionTitle: 'Véhicules Inspectés à Vendre',
    viewAllSalesBtn: 'Tout le Stock Vente',
    viewDetailsBtn: 'Voir Détails',
  },
  hire: {
    ...EN.hire,
    pageTitle: 'Flotte de Location — Forfaits Premium & Hors Ville',
    hideMap: 'Masquer la Carte',
    selectOnMap: 'Choisir sur Carte',
    rentalAgreementBtn: 'Contrat de Location',
    hideFilters: 'Masquer Filtres',
    filtersDatesBtn: 'Filtres & Dates',
    filterFleetHeading: 'Filtrer la Flotte',
    resetBtn: 'Réinitialiser',
    packagesSpecsBtn: 'Tarifs & Détails',
    bookPayBtn: 'Réserver & Payer',
    continueCheckoutBtn: 'Passer au Paiement',
    requestWhatsappBtn: 'Demander via WhatsApp',
    allCat: 'Tous',
  },
  sales: {
    ...EN.sales,
    buyTitle: 'Véhicules Japonais & Locaux à Vendre',
    sellTitle: 'Vendre ou Évaluer Votre Véhicule',
    buyTab: 'Acheter',
    sellTab: 'Vendre / Reprise',
    viewDetailsBtn: 'Voir Détails',
    bookTestDrive: 'Réserver un Essai',
    makeOffer: 'Faire une Offre',
    contactDealer: 'Contacter le Vendeur',
  },
  locations: {
    ...EN.locations,
    title: 'Siège Rhodes Park & Planificateur Google Maps',
    hireSelectedBtn: 'Louer avec ces Points',
    bookDeliveryBtn: 'Réserver Livraison',
  },
  services: {
    ...EN.services,
    title: 'Transferts Aéroport, Chauffeurs & Transport Lusaka',
    viewPdfBtn: 'Voir Contrat PDF',
    browseFleetBtn: 'Voir la Flotte',
    requestQuoteBtn: 'Demander un Devis',
  },
  about: {
    ...EN.about,
    title: 'Zamto Africa — Votre Partenaire Automobile de Confiance',
    exploreFleetBtn: 'Explorer la Flotte',
    agreementPdfBtn: 'Contrat PDF',
  },
  faq: { ...EN.faq, title: 'Questions Fréquentes', allCat: 'Toutes' },
  blog: { ...EN.blog, title: 'Guides de Conduite & Achat en Zambie', readGuideBtn: 'Lire le Guide' },
  contact: {
    ...EN.contact,
    title: 'Contacter Zamto Africa',
    subtitle:
      'Chaque demande est transmise à zamtoafrica@gmail.com et à notre ligne WhatsApp (+260 572 213 038).',
    formTitle: 'Envoyer une Demande (Email & WhatsApp)',
    fullNameLabel: 'Nom Complet *',
    phoneLabel: 'Téléphone / WhatsApp *',
    emailOptionalLabel: 'Adresse Email',
    topicLabel: 'Sujet',
    messageLabel: 'Message *',
    sendBtn: 'Envoyer par Email & WhatsApp',
    sendingBtn: 'Envoi...',
    sentTitle: 'Demande Envoyée',
    sendAnotherBtn: 'Envoyer un Autre Message',
  },
  bookings: {
    ...EN.bookings,
    title: 'Mes Réservations, Paiements & Contrats',
    newBookingBtn: 'Nouvelle Réservation',
    emptyTitle: 'Aucune Réservation Active',
    signedAgreementBtn: 'Contrat Signé',
    payOnlineBtn: 'Payer en Ligne',
    cancelBtn: 'Annuler',
  },
  payment: {
    ...EN.payment,
    payFull: 'Payer le Total Maintenant',
    payDeposit: 'Acompte de 30 %',
    selectMethod: 'Choisir le Mode de Paiement en Ligne',
    payOnlineBtnPrefix: 'Payer',
  },
  mapPicker: {
    titleDefault: 'Sélecteur Google Maps Prise en Charge & Retour',
    selectingPickup: 'Point Départ (A)',
    selectingDropoff: 'Point Retour (B)',
    searchPlaceholder: 'Rechercher hôtel, aéroport LUN, quartier...',
    useMyLocation: 'Ma Position',
    pickupPoint: 'Prise en Charge (A)',
    dropoffPoint: 'Retour (B)',
    sameAsPickup: 'Identique au départ',
    routeLabel: 'Itinéraire Estimé',
  },
};

const PT: SiteTranslations = {
  ...EN,
  nav: {
    home: 'Início',
    hire: 'Aluguer',
    sales: 'Comprar',
    locations: 'Mapa Lusaka',
    services: 'Serviços',
    bookings: 'Reservas',
    sellCar: 'Vender',
    about: 'Sobre Nós',
    faq: 'FAQ',
    tips: 'Dicas',
    contact: 'Contacto',
    admin: 'Admin',
    compare: 'Comparar',
    languageLabel: 'Idioma',
  },
  mobileNav: {
    home: 'Início',
    hire: 'Alugar',
    buy: 'Comprar',
    bookings: 'Reservas',
    whatsapp: 'WhatsApp',
    whatsappSupport: 'Suporte WhatsApp',
  },
  footer: {
    ...EN.footer,
    tagline:
      'Sede em Rhodes Park, Lusaka — transporte de clientes e entrega de viaturas em toda Lusaka, Aeroporto LUN e corredores regionais.',
    followUs: 'Siga a Zamto Africa',
    hirePackagesLink: 'Pacotes de Aluguer (ZMW / USD)',
    salesLink: 'Viaturas Japonesas à Venda',
    sellTradeLink: 'Vender ou Retoma',
    viewAgreementLink: 'Ver Contrato Digital',
    downloadPdfLink: 'Descarregar Contrato PDF',
    headOfficeMapLink: 'Sede & Mapa Google Maps',
    airportTransferLink: 'Traslados Aeroporto LUN (K500 / K800)',
    aboutLink: 'Sobre a Zamto Africa',
    faqLink: 'Requisitos, Quilometragem & FAQ',
    tipsLink: 'Dicas de Condução na Zâmbia',
    whatsappDeskBtn: 'Balcão WhatsApp',
    fleetAdminBtn: 'Gestão de Frota',
    rightsReserved: 'Todos os direitos reservados.',
  },
  home: {
    ...EN.home,
    kicker: 'Rhodes Park, Lusaka · Aluguer & Importações Certificadas',
    heroTitle: 'Conduza na Zâmbia do Seu Jeito',
    heroSub:
      'Sede em Rhodes Park, Lusaka — entrega porta a porta em toda Lusaka, traslados no Aeroporto LUN, viaturas 4x4 fora da cidade e carros japoneses certificados à venda.',
    browseHireBtn: 'Ver Frota de Aluguer',
    buyVehicleBtn: 'Comprar Viatura',
    whatsappDesk: 'WhatsApp Direto',
    dailyRateLabel: 'Taxa Diária',
    pickupPoint: 'Local de Recolha',
    dropoffPoint: 'Local de Devolução',
    pickupDate: 'Data de Recolha',
    returnDate: 'Data de Devolução',
    mapsPickerOpen: 'Fechar Mapa',
    mapsPickerClosed: 'Escolher no Mapa',
    searchBtn: 'Pesquisar Frota',
    classesKicker: 'Categorias',
    classesTitle: 'Escolha o Tipo de Viatura',
    fromLabel: 'Desde',
    perDay: '/ dia',
    cityExitLabel: 'Fora Cidade',
    withinLusakaOnly: 'Apenas Lusaka',
    detailsBtn: 'Detalhes',
    bookNowBtn: 'Reservar',
    hireSectionTitle: 'Pacotes de Aluguer (Premium · Fora da Cidade)',
    tabPopular: 'Populares',
    tabSmall: 'Compactos & CX-5',
    tabSuv: 'SUV / 4×4',
    tabPickup: 'Pick-up 4WD',
    tabCommercial: 'Vans & Camiões',
    salesKicker: 'Vendas Certificadas',
    salesSectionTitle: 'Veículos Certificados para Venda',
    viewAllSalesBtn: 'Ver Todo o Stock',
    viewDetailsBtn: 'Ver Detalhes',
  },
  hire: {
    ...EN.hire,
    pageTitle: 'Frota de Aluguer — Premium & Fora da Cidade',
    packagesSpecsBtn: 'Pacotes & Detalhes',
    bookPayBtn: 'Reservar & Pagar',
    continueCheckoutBtn: 'Continuar para Pagamento',
    requestWhatsappBtn: 'Pedir via WhatsApp',
    allCat: 'Todos',
  },
  sales: {
    ...EN.sales,
    buyTitle: 'Viaturas Japonesas e Locais à Venda',
    sellTitle: 'Vender ou Avaliar a Sua Viatura',
    buyTab: 'Comprar',
    sellTab: 'Vender / Retoma',
    viewDetailsBtn: 'Ver Detalhes',
    bookTestDrive: 'Marcar Test Drive',
    makeOffer: 'Fazer Proposta',
    contactDealer: 'Contactar Vendedor',
  },
  locations: {
    ...EN.locations,
    title: 'Sede Rhodes Park & Planeador Google Maps',
    hireSelectedBtn: 'Alugar com Locais Selecionados',
    bookDeliveryBtn: 'Agendar Entrega',
  },
  services: {
    ...EN.services,
    title: 'Traslados Aeroporto, Motoristas & Transporte Lusaka',
    viewPdfBtn: 'Ver Contrato PDF',
    browseFleetBtn: 'Ver Frota',
    requestQuoteBtn: 'Pedir Orçamento',
  },
  about: {
    ...EN.about,
    title: 'Zamto Africa — O Seu Parceiro Automóvel na Zâmbia',
    exploreFleetBtn: 'Explorar Frota',
    agreementPdfBtn: 'Contrato PDF',
  },
  faq: { ...EN.faq, title: 'Perguntas Frequentes', allCat: 'Todas' },
  blog: { ...EN.blog, title: 'Guias de Condução e Compra na Zâmbia', readGuideBtn: 'Ler Guia' },
  contact: {
    ...EN.contact,
    title: 'Fale com a Zamto Africa',
    subtitle:
      'Cada pedido é enviado automaticamente para zamtoafrica@gmail.com e WhatsApp (+260 572 213 038).',
    formTitle: 'Enviar Mensagem (Email & WhatsApp)',
    fullNameLabel: 'Nome Completo *',
    phoneLabel: 'Telefone / WhatsApp *',
    emailOptionalLabel: 'Email',
    topicLabel: 'Assunto',
    messageLabel: 'Mensagem *',
    sendBtn: 'Enviar para Email & WhatsApp',
    sendingBtn: 'A enviar...',
    sentTitle: 'Mensagem Enviada',
    sendAnotherBtn: 'Enviar Outra Mensagem',
  },
  bookings: {
    ...EN.bookings,
    title: 'As Minhas Reservas, Pagamentos & Contratos',
    newBookingBtn: 'Nova Reserva',
    emptyTitle: 'Sem Reservas Ativas',
    signedAgreementBtn: 'Contrato Assinado',
    payOnlineBtn: 'Pagar Online',
    cancelBtn: 'Cancelar',
  },
  payment: {
    ...EN.payment,
    payFull: 'Pagar Total Agora',
    payDeposit: 'Depósito de 30%',
    selectMethod: 'Selecionar Método de Pagamento Online',
    payOnlineBtnPrefix: 'Pagar',
  },
  mapPicker: {
    titleDefault: 'Seleção Google Maps de Recolha e Devolução',
    selectingPickup: 'Recolha (A)',
    selectingDropoff: 'Devolução (B)',
    searchPlaceholder: 'Pesquisar hotel, aeroporto LUN ou zona...',
    useMyLocation: 'Minha Localização',
    pickupPoint: 'Recolha (A)',
    dropoffPoint: 'Devolução (B)',
    sameAsPickup: 'Mesmo local',
    routeLabel: 'Rota Estimada',
  },
};

const ES: SiteTranslations = {
  ...EN,
  nav: {
    home: 'Inicio',
    hire: 'Alquiler',
    sales: 'Comprar',
    locations: 'Mapa Lusaka',
    services: 'Servicios',
    bookings: 'Reservas',
    sellCar: 'Vender Auto',
    about: 'Nosotros',
    faq: 'Preguntas',
    tips: 'Consejos',
    contact: 'Contacto',
    admin: 'Admin',
    compare: 'Comparar',
    languageLabel: 'Idioma',
  },
  mobileNav: {
    home: 'Inicio',
    hire: 'Alquilar',
    buy: 'Comprar',
    bookings: 'Reservas',
    whatsapp: 'WhatsApp',
    whatsappSupport: 'Soporte WhatsApp',
  },
  footer: {
    ...EN.footer,
    tagline:
      'Sede en Rhodes Park, Lusaka — transporte de clientes y entrega de vehículos en todo Lusaka, Aeropuerto LUN y rutas fuera de ciudad.',
    followUs: 'Sigue a Zamto Africa',
    hirePackagesLink: 'Tarifas de Alquiler (ZMW / USD)',
    salesLink: 'Importados Japoneses en Venta',
    sellTradeLink: 'Vender o Entregar Auto',
    viewAgreementLink: 'Ver Contrato Digital',
    downloadPdfLink: 'Descargar Contrato PDF',
    headOfficeMapLink: 'Sede y Mapa Google Maps',
    airportTransferLink: 'Traslados Aeropuerto LUN (K500 / K800)',
    aboutLink: 'Sobre Zamto Africa',
    faqLink: 'Requisitos, Kilometraje y Preguntas',
    tipsLink: 'Consejos de Conducción en Zambia',
    whatsappDeskBtn: 'WhatsApp Directo',
    fleetAdminBtn: 'Admin Flota',
    rightsReserved: 'Todos los derechos reservados.',
  },
  home: {
    ...EN.home,
    kicker: 'Rhodes Park, Lusaka · Alquiler y Autos Certificados',
    heroTitle: 'Conduce Zambia a Tu Manera',
    heroSub:
      'Sede en Rhodes Park, Lusaka — entrega puerta a puerta en todo Lusaka, traslados al Aeropuerto LUN, 4x4 fuera de la ciudad y vehículos japoneses certificados en venta.',
    browseHireBtn: 'Ver Flota de Alquiler',
    buyVehicleBtn: 'Comprar Vehículo',
    whatsappDesk: 'WhatsApp Directo',
    dailyRateLabel: 'Tasa Diaria',
    pickupPoint: 'Punto de Recogida',
    dropoffPoint: 'Punto de Devolución',
    pickupDate: 'Fecha Recogida',
    returnDate: 'Fecha Retorno',
    mapsPickerOpen: 'Cerrar Mapa',
    mapsPickerClosed: 'Selector Mapa',
    searchBtn: 'Buscar Flota',
    classesKicker: 'Categorías',
    classesTitle: 'Elige un Tipo de Vehículo',
    fromLabel: 'Desde',
    perDay: '/ día',
    cityExitLabel: 'Fuera Ciudad',
    withinLusakaOnly: 'Solo Lusaka',
    detailsBtn: 'Detalles',
    bookNowBtn: 'Reservar',
    hireSectionTitle: 'Planes de Alquiler (Premium · Fuera de Ciudad)',
    tabPopular: 'Populares',
    tabSmall: 'Compactos y CX-5',
    tabSuv: 'SUV / 4×4',
    tabPickup: 'Pickup 4WD',
    tabCommercial: 'Vans y Camiones',
    salesKicker: 'Venta Certificada',
    salesSectionTitle: 'Vehículos Inspeccionados en Venta',
    viewAllSalesBtn: 'Ver Todo el Inventario',
    viewDetailsBtn: 'Ver Detalles',
  },
  hire: {
    ...EN.hire,
    pageTitle: 'Flota de Alquiler — Planes Premium y Fuera de Ciudad',
    packagesSpecsBtn: 'Planes y Ficha',
    bookPayBtn: 'Reservar y Pagar',
    continueCheckoutBtn: 'Ir al Pago',
    requestWhatsappBtn: 'Solicitar por WhatsApp',
    allCat: 'Todos',
  },
  sales: {
    ...EN.sales,
    buyTitle: 'Autos Importados y Locales en Venta',
    sellTitle: 'Vende Tu Auto o Calcula Permuta',
    buyTab: 'Comprar',
    sellTab: 'Vender / Permuta',
    viewDetailsBtn: 'Ver Detalles',
    bookTestDrive: 'Agendar Prueba',
    makeOffer: 'Hacer Oferta',
    contactDealer: 'Contactar Asesor',
  },
  locations: {
    ...EN.locations,
    title: 'Sede Rhodes Park y Planificador Google Maps',
    hireSelectedBtn: 'Alquilar con Puntos Elegidos',
    bookDeliveryBtn: 'Reservar Entrega',
  },
  services: {
    ...EN.services,
    title: 'Traslados Aeropuerto, Choferes y Transporte en Lusaka',
    viewPdfBtn: 'Ver Contrato PDF',
    browseFleetBtn: 'Ver Flota',
    requestQuoteBtn: 'Solicitar Cotización',
  },
  about: {
    ...EN.about,
    title: 'Zamto Africa — Tu Aliado Automotriz en Zambia',
    exploreFleetBtn: 'Explorar Flota',
    agreementPdfBtn: 'Contrato PDF',
  },
  faq: { ...EN.faq, title: 'Preguntas Frecuentes', allCat: 'Todas' },
  blog: { ...EN.blog, title: 'Guías de Conducción y Compra en Zambia', readGuideBtn: 'Leer Guía' },
  contact: {
    ...EN.contact,
    title: 'Habla con Zamto Africa',
    subtitle:
      'Cada consulta se envía a zamtoafrica@gmail.com y a nuestro WhatsApp oficial (+260 572 213 038).',
    formTitle: 'Enviar Consulta (Email y WhatsApp)',
    fullNameLabel: 'Nombre Completo *',
    phoneLabel: 'Teléfono / WhatsApp *',
    emailOptionalLabel: 'Correo Electrónico',
    topicLabel: 'Asunto',
    messageLabel: 'Mensaje *',
    sendBtn: 'Enviar a Email y WhatsApp',
    sendingBtn: 'Enviando...',
    sentTitle: 'Consulta Enviada',
    sendAnotherBtn: 'Enviar Otra Consulta',
  },
  bookings: {
    ...EN.bookings,
    title: 'Mis Reservas, Pagos y Contratos',
    newBookingBtn: 'Nueva Reserva',
    emptyTitle: 'Sin Reservas Activas',
    signedAgreementBtn: 'Contrato Firmado',
    payOnlineBtn: 'Pagar en Línea',
    cancelBtn: 'Cancelar',
  },
  payment: {
    ...EN.payment,
    payFull: 'Pagar Total Ahora',
    payDeposit: 'Depósito del 30%',
    selectMethod: 'Seleccionar Método de Pago en Línea',
    payOnlineBtnPrefix: 'Pagar',
  },
  mapPicker: {
    titleDefault: 'Selector Google Maps de Recogida y Devolución',
    selectingPickup: 'Recogida (A)',
    selectingDropoff: 'Devolución (B)',
    searchPlaceholder: 'Buscar hotel en Lusaka, aeropuerto LUN o ciudad...',
    useMyLocation: 'Mi Ubicación',
    pickupPoint: 'Recogida (A)',
    dropoffPoint: 'Devolución (B)',
    sameAsPickup: 'Mismo lugar',
    routeLabel: 'Ruta Estimada',
  },
};

const DE: SiteTranslations = {
  ...EN,
  nav: {
    home: 'Start',
    hire: 'Mietwagen',
    sales: 'Fahrzeugkauf',
    locations: 'Karte & Zonen',
    services: 'Services',
    bookings: 'Buchungen',
    sellCar: 'Verkaufen',
    about: 'Über Uns',
    faq: 'FAQ',
    tips: 'Reisetipps',
    contact: 'Kontakt',
    admin: 'Admin',
    compare: 'Vergleich',
    languageLabel: 'Sprache',
  },
  mobileNav: {
    home: 'Start',
    hire: 'Mieten',
    buy: 'Kaufen',
    bookings: 'Buchung',
    whatsapp: 'WhatsApp',
    whatsappSupport: 'WhatsApp Support',
  },
  footer: {
    ...EN.footer,
    tagline:
      'Hauptsitz in Rhodes Park, Lusaka — Fahrzeugzustellung und Personentransfer in ganz Lusaka, zum Flughafen LUN und landesweit.',
    followUs: 'Zamto Africa Folgen',
    hirePackagesLink: 'Mietwagenpakete (ZMW / USD)',
    salesLink: 'Geprüfte Japan-Importe',
    sellTradeLink: 'Fahrzeug Verkaufen / Inzahlungnahme',
    viewAgreementLink: 'Mietvertrag Ansehen',
    downloadPdfLink: 'Mietvertrag PDF Laden',
    headOfficeMapLink: 'Zentrale & Google Maps',
    airportTransferLink: 'LUN Flughafentransfer (K500 / K800)',
    aboutLink: 'Über Zamto Africa',
    faqLink: 'Anforderungen & FAQ',
    tipsLink: 'Fahr- & Kauftipps Sambia',
    whatsappDeskBtn: 'WhatsApp Büro',
    fleetAdminBtn: 'Flotten-Admin',
    rightsReserved: 'Alle Rechte vorbehalten.',
  },
  home: {
    ...EN.home,
    kicker: 'Rhodes Park, Lusaka · Mietwagen & Geprüfte Importe',
    heroTitle: 'Entdecken Sie Sambia auf Ihre Weise',
    heroSub:
      'Hauptsitz in Rhodes Park, Lusaka — Tür-zu-Tür-Zustellung in ganz Lusaka, LUN-Flughafentransfers, 4x4 Überland-Mietwagen und geprüfte Japan-Importe.',
    browseHireBtn: 'Mietflotte Ansehen',
    buyVehicleBtn: 'Fahrzeug Kaufen',
    whatsappDesk: 'WhatsApp Büro',
    dailyRateLabel: 'Tageswechselkurs',
    pickupPoint: 'Abholort',
    dropoffPoint: 'Rückgabeort',
    pickupDate: 'Abholdatum',
    returnDate: 'Rückgabedatum',
    mapsPickerOpen: 'Karte Schließen',
    mapsPickerClosed: 'Google Maps',
    searchBtn: 'Flotte Suchen',
    classesKicker: 'Fahrzeugklassen',
    classesTitle: 'Fahrzeugtyp Wählen',
    fromLabel: 'Ab',
    perDay: '/ Tag',
    cityExitLabel: 'Überland',
    withinLusakaOnly: 'Nur Stadtgebiet Lusaka',
    detailsBtn: 'Details',
    bookNowBtn: 'Jetzt Buchen',
    hireSectionTitle: 'Mietpakete (Premium · Überland)',
    tabPopular: 'Beliebt',
    tabSmall: 'Kleinwagen & CX-5',
    tabSuv: 'SUV / 4×4',
    tabPickup: 'Pickup 4WD',
    tabCommercial: 'Vans & LKW',
    salesKicker: 'Geprüfter Verkauf',
    salesSectionTitle: 'Geprüfte Fahrzeuge zum Verkauf',
    viewAllSalesBtn: 'Alle Kaufangebote',
    viewDetailsBtn: 'Details Ansehen',
  },
  hire: {
    ...EN.hire,
    pageTitle: 'Mietflotte — Premium & Überland-Pakete',
    packagesSpecsBtn: 'Pakete & Daten',
    bookPayBtn: 'Buchen & Zahlen',
    continueCheckoutBtn: 'Zur Kasse',
    requestWhatsappBtn: 'Per WhatsApp Anfragen',
    allCat: 'Alle',
  },
  sales: {
    ...EN.sales,
    buyTitle: 'Geprüfte Japan-Importe & Fahrzeuge zum Verkauf',
    sellTitle: 'Fahrzeug Verkaufen oder Inzahlungnahme',
    buyTab: 'Kaufen',
    sellTab: 'Verkaufen',
    viewDetailsBtn: 'Details Ansehen',
    bookTestDrive: 'Probefahrt Buchen',
    makeOffer: 'Angebot Machen',
    contactDealer: 'Händler Kontaktieren',
  },
  locations: {
    ...EN.locations,
    title: 'Zentrale Rhodes Park & Google Maps Zustellplaner',
    hireSelectedBtn: 'Mit Gewählten Punkten Mieten',
    bookDeliveryBtn: 'Zustellung Buchen',
  },
  services: {
    ...EN.services,
    title: 'Flughafentransfers, Chauffeure & Lusaka-Transport',
    viewPdfBtn: 'Mietvertrag PDF',
    browseFleetBtn: 'Flotte Ansehen',
    requestQuoteBtn: 'Angebot Anfordern',
  },
  about: {
    ...EN.about,
    title: 'Zamto Africa — Ihr Verlässlicher Partner in Sambia',
    exploreFleetBtn: 'Mietflotte Entdecken',
    agreementPdfBtn: 'Mietvertrag PDF',
  },
  faq: { ...EN.faq, title: 'Häufig Gestellte Fragen', allCat: 'Alle' },
  blog: { ...EN.blog, title: 'Sambia Fahr- & Kaufratgeber', readGuideBtn: 'Ratgeber Lesen' },
  contact: {
    ...EN.contact,
    title: 'Kontakt zu Zamto Africa',
    subtitle:
      'Jede Anfrage wird direkt an zamtoafrica@gmail.com und unser WhatsApp-Team (+260 572 213 038) gesendet.',
    formTitle: 'Anfrage Senden (E-Mail & WhatsApp)',
    fullNameLabel: 'Vollständiger Name *',
    phoneLabel: 'Telefon / WhatsApp *',
    emailOptionalLabel: 'E-Mail-Adresse',
    topicLabel: 'Thema',
    messageLabel: 'Nachricht *',
    sendBtn: 'An E-Mail & WhatsApp Senden',
    sendingBtn: 'Wird gesendet...',
    sentTitle: 'Anfrage Gesendet',
    sendAnotherBtn: 'Weitere Anfrage Senden',
  },
  bookings: {
    ...EN.bookings,
    title: 'Meine Buchungen, Zahlungen & Verträge',
    newBookingBtn: 'Neue Buchung',
    emptyTitle: 'Keine Aktiven Buchungen',
    signedAgreementBtn: 'Unterzeichneter Vertrag',
    payOnlineBtn: 'Online Bezahlen',
    cancelBtn: 'Stornieren',
  },
  payment: {
    ...EN.payment,
    payFull: 'Gesamtbetrag Jetzt Zahlen',
    payDeposit: '30 % Anzahlung',
    selectMethod: 'Online-Zahlungsmethode Wählen',
    payOnlineBtnPrefix: 'Zahlen',
  },
  mapPicker: {
    titleDefault: 'Google Maps Abhol- & Rückgabe-Auswahl',
    selectingPickup: 'Abholort (A)',
    selectingDropoff: 'Rückgabeort (B)',
    searchPlaceholder: 'Hotel, Flughafen LUN oder Stadt in Sambia suchen...',
    useMyLocation: 'Mein Standort',
    pickupPoint: 'Abholort (A)',
    dropoffPoint: 'Rückgabeort (B)',
    sameAsPickup: 'Wie Abholort',
    routeLabel: 'Geschätzte Fahrstrecke',
  },
};

const JA: SiteTranslations = {
  ...EN,
  nav: {
    home: 'ホーム',
    hire: 'レンタカー',
    sales: '車両販売',
    locations: '地図・エリア',
    services: '空港送迎',
    bookings: '予約管理',
    sellCar: '車売却・下取',
    about: '会社概要',
    faq: 'よくある質問',
    tips: '運転ガイド',
    contact: 'お問い合わせ',
    admin: '管理画面',
    compare: '比較',
    languageLabel: '言語',
  },
  mobileNav: {
    home: 'ホーム',
    hire: 'レンタル',
    buy: '購入',
    bookings: '予約',
    whatsapp: 'WhatsApp',
    whatsappSupport: 'WhatsApp サポート',
  },
  footer: {
    ...EN.footer,
    tagline:
      'ルサカ Rhodes Park 本社より、ルサカ市内全域、LUN国際空港送迎、市外対応車両の配車・送迎を行っております。',
    followUs: 'Zamto Africa 公式SNS',
    hirePackagesLink: 'レンタル料金プラン (ZMW / USD)',
    salesLink: '日本輸入認定販売車両',
    sellTradeLink: '愛車の売却・下取り査定',
    viewAgreementLink: '電子レンタル契約書を確認',
    downloadPdfLink: '契約書 PDF をダウンロード',
    headOfficeMapLink: '本社・Google マップ配車',
    airportTransferLink: 'LUN 空港送迎 (K500 / K800)',
    aboutLink: 'Zamto Africa について',
    faqLink: '必要書類・走行距離・FAQ',
    tipsLink: 'ザンビア運転・購入ガイド',
    whatsappDeskBtn: 'WhatsApp 窓口',
    fleetAdminBtn: '車両管理',
    rightsReserved: 'All rights reserved.',
  },
  home: {
    ...EN.home,
    kicker: 'ルサカ Rhodes Park 本社 · レンタカー＆認定日本車販売',
    heroTitle: 'ザンビアを自由に、快適に走る',
    heroSub:
      'ルサカ Rhodes Park を拠点に、ルサカ市内全域への配車、LUN 空港送迎、市外対応 4x4 レンタル、JEVIC 査定済み日本輸入車の販売を行っています。',
    browseHireBtn: 'レンタル車両を見る',
    buyVehicleBtn: '販売車両を見る',
    whatsappDesk: 'WhatsApp 相談',
    dailyRateLabel: '本日適用レート',
    pickupPoint: '受取場所',
    dropoffPoint: '返却場所',
    pickupDate: '受取日',
    returnDate: '返却日',
    mapsPickerOpen: '地図を閉じる',
    mapsPickerClosed: '地図で選ぶ',
    searchBtn: '空車を検索',
    classesKicker: '車両クラス',
    classesTitle: '車両タイプを選択',
    fromLabel: '料金',
    perDay: '/ 日',
    cityExitLabel: '市外プラン',
    withinLusakaOnly: 'ルサカ市内限定',
    detailsBtn: '詳細',
    bookNowBtn: '今すぐ予約',
    hireSectionTitle: 'レンタカープラン（市内プレミアム・市外対応）',
    tabPopular: '人気車両',
    tabSmall: 'コンパクト & CX-5',
    tabSuv: 'SUV / 4×4',
    tabPickup: '4WD ピックアップ',
    tabCommercial: 'バン・トラック',
    salesKicker: '認定中古車販売',
    salesSectionTitle: '検査済み日本輸入販売車',
    viewAllSalesBtn: '販売在庫をすべて見る',
    viewDetailsBtn: '詳細を見る',
  },
  hire: {
    ...EN.hire,
    pageTitle: 'レンタル車両一覧 — 市内・市外対応プラン',
    packagesSpecsBtn: '料金・仕様',
    bookPayBtn: '予約・決済',
    continueCheckoutBtn: 'お支払いへ進む',
    requestWhatsappBtn: 'WhatsApp で問い合わせ',
    allCat: 'すべて',
  },
  sales: {
    ...EN.sales,
    buyTitle: '認定日本輸入車・販売車両在庫',
    sellTitle: 'お車の売却・下取り査定',
    buyTab: '車両購入',
    sellTab: '売却・下取り',
    viewDetailsBtn: '詳細を見る',
    bookTestDrive: '試乗を予約',
    makeOffer: '希望額を提示',
    contactDealer: '担当者に連絡',
  },
  locations: {
    ...EN.locations,
    title: 'Rhodes Park 本社 & Google マップ配車プランナー',
    hireSelectedBtn: '選択した地点で予約する',
    bookDeliveryBtn: '配車を予約',
  },
  services: {
    ...EN.services,
    title: 'LUN 空港送迎・専属ドライバー・ルサカ配車サービス',
    viewPdfBtn: 'レンタル契約書 PDF',
    browseFleetBtn: '車両を見る',
    requestQuoteBtn: '見積依頼',
  },
  about: {
    ...EN.about,
    title: 'Zamto Africa — ザンビアで信頼されるモビリティパートナー',
    exploreFleetBtn: 'レンタル車両を見る',
    agreementPdfBtn: '契約書 PDF',
  },
  faq: { ...EN.faq, title: 'よくある質問', allCat: 'すべて' },
  blog: { ...EN.blog, title: 'ザンビア運転・車両購入ガイド', readGuideBtn: '記事を読む' },
  contact: {
    ...EN.contact,
    title: 'Zamto Africa お問い合わせ',
    subtitle:
      'お問い合わせ内容は zamtoafrica@gmail.com および公式 WhatsApp (+260 572 213 038) に送信されます。',
    formTitle: 'お問い合わせフォーム（メール & WhatsApp 連携）',
    fullNameLabel: 'お名前 *',
    phoneLabel: '電話番号 / WhatsApp *',
    emailOptionalLabel: 'メールアドレス',
    topicLabel: 'お問い合わせ項目',
    messageLabel: 'メッセージ *',
    sendBtn: 'メール & WhatsApp に送信',
    sendingBtn: '送信中...',
    sentTitle: '送信完了',
    sendAnotherBtn: '続けて問い合わせる',
  },
  bookings: {
    ...EN.bookings,
    title: 'ご予約・決済・電子契約書',
    newBookingBtn: '新規予約',
    emptyTitle: '有効な予約はありません',
    signedAgreementBtn: '署名済み契約書',
    payOnlineBtn: 'オンライン決済',
    cancelBtn: 'キャンセル',
  },
  payment: {
    ...EN.payment,
    payFull: '全額を今すぐ支払う',
    payDeposit: '30% 予約手付金',
    selectMethod: 'オンライン決済方法を選択',
    payOnlineBtnPrefix: '支払う',
  },
  mapPicker: {
    titleDefault: 'Google マップ 受取・返却地点選択',
    selectingPickup: '受取地点 (A) 選択中',
    selectingDropoff: '返却地点 (B) 選択中',
    searchPlaceholder: 'ルサカのホテル、LUN空港、都市を検索...',
    useMyLocation: '現在地',
    pickupPoint: '受取地点 (A)',
    dropoffPoint: '返却地点 (B)',
    sameAsPickup: '受取場所と同じ',
    routeLabel: '予想走行ルート',
  },
};

export const TRANSLATIONS: Record<LanguageCode, SiteTranslations> = {
  en: EN,
  zh: ZH,
  fr: FR,
  pt: PT,
  es: ES,
  de: DE,
  ja: JA,
};
