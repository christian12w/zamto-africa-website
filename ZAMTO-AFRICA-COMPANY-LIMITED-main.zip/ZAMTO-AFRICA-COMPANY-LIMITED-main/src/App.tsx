import React, { useEffect, useState } from 'react';
import type {
  CurrencyMode,
  CustomerBooking,
  HirePackageTier,
  HireSearchCriteria,
  HireVehicle,
  LanguageCode,
  PageRoute,
  SaleVehicle,
  SellCarSubmission,
  VehicleCategory,
} from './types';
import {
  INITIAL_HIRE_FLEET,
  INITIAL_SALES_INVENTORY,
  ZAMBIA_LOCATIONS,
} from './data/zambiaData';
import {
  FloatingWhatsAppButton,
  MobileBottomNav,
  SiteFooter,
  SiteHeader,
} from './components/NavbarAndFooter';
import { HomePage } from './components/HomePage';
import { CarHireView } from './components/CarHireView';
import { CarSalesView } from './components/CarSalesView';
import {
  AboutPage,
  BlogPage,
  ContactPage,
  FaqPage,
  LocationsPage,
  ServicesPage,
} from './components/InfoPages';
import { AdminDashboardView, MyBookingsView } from './components/Dashboards';
import { RentalAgreementModal } from './components/RentalAgreementModal';
import type { PaymentCompletionResult, PaymentRailId } from './components/PaymentCheckoutWidget';
import { I18nProvider } from './i18n/I18nContext';
import { dispatchZamtoNotification } from './utils/dispatch';
import { OfflineIndicator } from './components/PWAInstallBanner';
import { APIProvider } from '@vis.gl/react-google-maps';
import {
  GOOGLE_MAPS_API_KEY,
  fetchLiveUsdZmwRate,
  formatMoney,
  getZmwPerUsd,
  setZmwPerUsd,
} from './utils/format';

import { auth } from './lib/firebase';

interface BookingClaim {
  id: string;
  token: string;
}

const STORAGE_KEYS = {
  bookingClaims: 'zamto_africa_booking_claims_v1',
  lang: 'zamto_africa_lang_v1',
  pendingCheckout: 'zamto_pending_checkout_v1',
};

const VALID_LANGS: LanguageCode[] = ['en', 'zh', 'fr', 'pt', 'es', 'de', 'ja'];

function readInitialLang(): LanguageCode {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.lang) as LanguageCode | null;
    if (raw && VALID_LANGS.includes(raw)) return raw;
  } catch {
    // Ignore storage access errors
  }
  return 'en';
}

function readStorage<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

export function App() {
  const [route, setRoute] = useState<PageRoute>('home');
  const [currency, setCurrency] = useState<CurrencyMode>('USD');
  const [lang, setLang] = useState<LanguageCode>(readInitialLang);

  const [hireFleet, setHireFleet] = useState<HireVehicle[]>(INITIAL_HIRE_FLEET);
  const [salesInventory, setSalesInventory] = useState<SaleVehicle[]>(INITIAL_SALES_INVENTORY);
  const [bookingClaims, setBookingClaims] = useState<BookingClaim[]>(() =>
    readStorage(STORAGE_KEYS.bookingClaims, [])
  );
  const [customerBookings, setCustomerBookings] = useState<CustomerBooking[]>([]);
  const [adminBookings, setAdminBookings] = useState<CustomerBooking[]>([]);
  const [sellerLeads, setSellerLeads] = useState<SellCarSubmission[]>([]);

  const [adminAuthenticated, setAdminAuthenticated] = useState(false);
  const [adminPasswordConfigured, setAdminPasswordConfigured] = useState(true);
  const [adminAuthLoading, setAdminAuthLoading] = useState(true);
  const [firebaseIdToken, setFirebaseIdToken] = useState<string | null>(null);

  const [hireSearch, setHireSearch] = useState<HireSearchCriteria>({
    pickupLocation: ZAMBIA_LOCATIONS[0],
    dropoffLocation: 'Same as pickup',
    pickupDate: '2026-11-26',
    pickupTime: '09:00',
    returnDate: '2026-11-30',
    returnTime: '09:00',
    driverAge: '22+ (2+ yrs licence)',
  });

  const [hireInitialCategory, setHireInitialCategory] = useState<VehicleCategory | 'All'>('All');
  const [selectedHireVehicle, setSelectedHireVehicle] = useState<HireVehicle | null>(null);
  const [bookingHireVehicle, setBookingHireVehicle] = useState<HireVehicle | null>(null);
  const [preselectedAddons, setPreselectedAddons] = useState<string[]>([]);
  const [preselectedTier, setPreselectedTier] = useState<HirePackageTier>('Premium');

  const [salesTab, setSalesTab] = useState<'buy' | 'sell'>('buy');
  const [compareIds, setCompareIds] = useState<string[]>([]);
  const [showCompareModal, setShowCompareModal] = useState(false);
  const [selectedSaleVehicle, setSelectedSaleVehicle] = useState<SaleVehicle | null>(null);
  const [showAgreementModal, setShowAgreementModal] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [zmwPerUsd, setZmwPerUsdState] = useState<number>(() => getZmwPerUsd());
  const [mapsQuotaExceeded, setMapsQuotaExceeded] = useState(false);

  const handleLangChange = (next: LanguageCode) => {
    setLang(next);
    try {
      localStorage.setItem(STORAGE_KEYS.lang, next);
    } catch {
      // Ignore storage access errors
    }
  };

  useEffect(() => {
    document.documentElement.lang = lang;
  }, [lang]);

  useEffect(() => {
    const onQuota = () => setMapsQuotaExceeded(true);
    window.addEventListener('gmp-quota-exceeded', onQuota);
    return () => window.removeEventListener('gmp-quota-exceeded', onQuota);
  }, []);

  // Hydrate shared fleet, inventory, and FX rate from backend database
  useEffect(() => {
    let active = true;
    fetch('/api/fleet', { credentials: 'include' })
      .then((res) => (res.ok ? res.json() : null))
      .then(
        (
          data: {
            hireFleet?: HireVehicle[];
            salesInventory?: SaleVehicle[];
            fxRate?: { rate?: number; source?: string } | null;
          } | null
        ) => {
          if (!active || !data) return;
          if (Array.isArray(data.hireFleet) && data.hireFleet.length > 0) {
            setHireFleet(data.hireFleet);
          }
          if (Array.isArray(data.salesInventory) && data.salesInventory.length > 0) {
            setSalesInventory(data.salesInventory);
          }
          if (data.fxRate && typeof data.fxRate.rate === 'number') {
            const applied = setZmwPerUsd(
              data.fxRate.rate,
              data.fxRate.source === 'live' ? 'live' : 'admin'
            );
            setZmwPerUsdState(applied);
            return;
          }
          void fetchLiveUsdZmwRate().then((rate) => {
            if (active && rate) setZmwPerUsdState(rate);
          });
        }
      )
      .catch(() => {
        void fetchLiveUsdZmwRate().then((rate) => {
          if (active && rate) setZmwPerUsdState(rate);
        });
      });
    return () => {
      active = false;
    };
  }, []);

  // Track optional Firebase Auth token in memory
  useEffect(() => {
    const unsub = auth.onIdTokenChanged(async (user) => {
      if (user) {
        try {
          const token = await user.getIdToken();
          setFirebaseIdToken(token);
        } catch {
          setFirebaseIdToken(null);
        }
      } else {
        setFirebaseIdToken(null);
      }
    });
    return () => unsub();
  }, []);

  const refreshAdminSession = async (overrideToken?: string | null) => {
    setAdminAuthLoading(true);
    try {
      const headers: Record<string, string> = {};
      const tokenToUse = overrideToken ?? firebaseIdToken;
      if (tokenToUse) {
        headers.Authorization = `Bearer ${tokenToUse}`;
      }
      const res = await fetch('/api/admin/session', {
        credentials: 'include',
        headers,
      });
      if (res.ok) {
        const data = (await res.json()) as {
          authenticated?: boolean;
          passwordConfigured?: boolean;
        };
        setAdminAuthenticated(Boolean(data.authenticated));
        setAdminPasswordConfigured(Boolean(data.passwordConfigured));
      }
    } catch {
      // Ignore transient check failure
    } finally {
      setAdminAuthLoading(false);
    }
  };

  useEffect(() => {
    void refreshAdminSession();
  }, [firebaseIdToken]);

  const loadAdminRecords = async (overrideToken?: string | null) => {
    try {
      const headers: Record<string, string> = {};
      const tokenToUse = overrideToken ?? firebaseIdToken;
      if (tokenToUse) headers.Authorization = `Bearer ${tokenToUse}`;
      const res = await fetch('/api/admin/dashboard', {
        credentials: 'include',
        headers,
      });
      if (res.status === 401) {
        setAdminAuthenticated(false);
        return;
      }
      if (res.ok) {
        const data = (await res.json()) as {
          bookings?: CustomerBooking[];
          sellerLeads?: SellCarSubmission[];
        };
        if (Array.isArray(data.bookings)) setAdminBookings(data.bookings);
        if (Array.isArray(data.sellerLeads)) setSellerLeads(data.sellerLeads);
      }
    } catch {
      // Ignore transient network failure
    }
  };

  useEffect(() => {
    if (adminAuthenticated) {
      void loadAdminRecords();
    }
  }, [adminAuthenticated]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.bookingClaims, JSON.stringify(bookingClaims));
    } catch {
      // Ignore storage quota issues
    }
    if (bookingClaims.length === 0) return;
    let active = true;
    fetch('/api/bookings/mine', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ claims: bookingClaims }),
    })
      .then((res) => (res.ok ? res.json() : null))
      .then((data: { bookings?: CustomerBooking[] } | null) => {
        if (active && Array.isArray(data?.bookings)) {
          setCustomerBookings(data.bookings);
        }
      })
      .catch(() => undefined);
    return () => {
      active = false;
    };
  }, [bookingClaims]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    window.setTimeout(() => {
      setToastMessage((curr) => (curr === msg ? null : curr));
    }, 4000);
  };

  // Verify Lenco 3DS / redirect returns to /
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const gateway = params.get('gateway');
    if (gateway !== 'lenco') return;

    const txRef = params.get('tx_ref') || params.get('reference') || '';
    const transactionId = params.get('transaction_id') || '';

    window.history.replaceState({}, '', window.location.pathname);

    let pendingRaw: string | null = null;
    try {
      pendingRaw = sessionStorage.getItem(STORAGE_KEYS.pendingCheckout);
      sessionStorage.removeItem(STORAGE_KEYS.pendingCheckout);
    } catch {
      pendingRaw = null;
    }

    const qs = new URLSearchParams({ provider: 'lenco' });
    if (txRef) qs.set('txRef', txRef);
    if (transactionId) qs.set('transactionId', transactionId);

    fetch(`/api/payments/verify?${qs.toString()}`)
      .then((res) => (res.ok ? res.json() : null))
      .then(
        (
          data: {
            verified?: boolean;
            transactionRef?: string;
          } | null
        ) => {
          if (!data?.verified) {
            showToast('Payment could not be verified automatically. Contact +260 572 213 038.');
            return;
          }

          const verifiedRef = data.transactionRef || txRef;
          if (!pendingRaw) {
            setRoute('bookings');
            showToast(`Payment verified (${verifiedRef}).`);
            return;
          }

          try {
            const pending = JSON.parse(pendingRaw) as
              | {
                  mode: 'create';
                  booking: CustomerBooking;
                  payOption: 'full' | 'deposit';
                  amountDueZmw: number;
                }
              | {
                  mode: 'update';
                  bookingId: string;
                  paymentMethod: PaymentRailId;
                  payOption: 'full' | 'deposit';
                  amountDueZmw: number;
                };

            const nextPaymentStatus =
              pending.payOption === 'deposit' ? 'Deposit Paid' : 'Paid';
            const paidAt = new Date().toISOString();

            if (pending.mode === 'create') {
              const finalized: CustomerBooking = {
                ...pending.booking,
                paymentStatus: nextPaymentStatus,
                paymentTransactionRef: verifiedRef,
                paidAmountZmw: pending.amountDueZmw,
                paidAt,
                status: 'Confirmed',
              };
              void persistCreatedBooking(finalized);
              void dispatchZamtoNotification({
                kind: 'Car Hire Booking',
                reference: finalized.id,
                customerName: finalized.customerName,
                customerPhone: finalized.customerPhone,
                customerEmail: finalized.customerEmail,
                topicOrVehicle: `${finalized.vehicleName} (${finalized.packageTier || 'Premium'})`,
                pickupLocation: finalized.pickupLocation,
                dropoffLocation: finalized.dropoffLocation,
                dateRange: `${finalized.startDate} to ${finalized.endDate || ''}`,
                totalDisplay: formatMoney(finalized.totalZmw, currency),
                paymentSummary: `${nextPaymentStatus} via ${finalized.paymentMethod} (${verifiedRef})`,
                message: `Online gateway payment verified and dispatched.`,
              });
              setRoute('bookings');
              showToast(`Booking ${finalized.id} confirmed & dispatched (${verifiedRef}).`);
            } else {
              void persistCompletePayment(pending.bookingId, {
                paymentMethod: pending.paymentMethod,
                paymentStatus: nextPaymentStatus,
                transactionRef: verifiedRef,
                paidAmountZmw: pending.amountDueZmw,
                paidAt,
              });
              const target = customerBookings.find((item) => item.id === pending.bookingId);
              if (target) {
                void dispatchZamtoNotification({
                  kind: 'Car Hire Booking',
                  reference: target.id,
                  customerName: target.customerName,
                  customerPhone: target.customerPhone,
                  customerEmail: target.customerEmail,
                  topicOrVehicle: target.vehicleName,
                  pickupLocation: target.pickupLocation,
                  dropoffLocation: target.dropoffLocation,
                  dateRange: `${target.startDate} to ${target.endDate || ''}`,
                  totalDisplay: formatMoney(target.totalZmw, currency),
                  paymentSummary: `${nextPaymentStatus} via ${pending.paymentMethod} (${verifiedRef})`,
                });
              }
              setRoute('bookings');
              showToast(`Payment verified (${verifiedRef}) for ${pending.bookingId}.`);
            }
          } catch {
            setRoute('bookings');
            showToast(`Payment verified (${verifiedRef}).`);
          }
        }
      )
      .catch(() => {
        showToast('Could not reach payment verification endpoint.');
      });
  }, []);

  const navigateTo = (next: PageRoute) => {
    setRoute(next);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleToggleCompare = (id: string) => {
    setCompareIds((prev) => {
      if (prev.includes(id)) return prev.filter((item) => item !== id);
      if (prev.length >= 3) {
        showToast('Compare up to 3 vehicles side by side.');
        return prev;
      }
      return [...prev, id];
    });
  };

  const adminFetch = async (url: string, options: RequestInit = {}) => {
    const headers: Record<string, string> = {
      ...(options.body ? { 'Content-Type': 'application/json' } : {}),
      ...(firebaseIdToken ? { Authorization: `Bearer ${firebaseIdToken}` } : {}),
      ...((options.headers as Record<string, string>) || {}),
    };
    const res = await fetch(url, {
      ...options,
      credentials: 'include',
      headers,
    });
    if (res.status === 401) {
      setAdminAuthenticated(false);
      showToast('Admin session expired. Please enter your password to continue.');
      return null;
    }
    if (!res.ok) {
      const errData = (await res.json().catch(() => ({}))) as { error?: string };
      showToast(errData.error || 'Could not save change to server.');
      return null;
    }
    return res;
  };

  const persistCreatedBooking = async (booking: CustomerBooking) => {
    setCustomerBookings((prev) => [booking, ...prev.filter((b) => b.id !== booking.id)]);
    try {
      const res = await fetch('/api/bookings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(booking),
      });
      if (res.ok) {
        const data = (await res.json()) as { booking: CustomerBooking; claimToken?: string };
        if (data.claimToken) {
          setBookingClaims((prev) => [
            { id: booking.id, token: data.claimToken! },
            ...prev.filter((c) => c.id !== booking.id),
          ]);
        }
        if (data.booking) {
          setCustomerBookings((prev) => [
            data.booking,
            ...prev.filter((b) => b.id !== data.booking.id),
          ]);
        }
      }
    } catch {
      // Keep local view if offline
    }
  };

  const persistCompletePayment = async (id: string, payment: PaymentCompletionResult) => {
    setCustomerBookings((prev) =>
      prev.map((item) =>
        item.id === id
          ? {
              ...item,
              paymentMethod: payment.paymentMethod,
              paymentStatus: payment.paymentStatus,
              paymentTransactionRef: payment.transactionRef,
              paidAmountZmw: (item.paidAmountZmw || 0) + payment.paidAmountZmw,
              paidAt: payment.paidAt,
              status: 'Confirmed',
            }
          : item
      )
    );
    const claim = bookingClaims.find((c) => c.id === id);
    try {
      const res = await fetch(`/api/bookings/${encodeURIComponent(id)}/complete-payment`, {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          claimToken: claim?.token || '',
          paymentMethod: payment.paymentMethod,
          paymentStatus: payment.paymentStatus,
          transactionRef: payment.transactionRef,
          paidAmountZmw: payment.paidAmountZmw,
          paidAt: payment.paidAt,
        }),
      });
      if (res.ok) {
        const data = (await res.json()) as { booking?: CustomerBooking };
        if (data.booking) {
          setCustomerBookings((prev) =>
            prev.map((item) => (item.id === id ? data.booking! : item))
          );
        }
      }
    } catch {
      // Ignore network errors
    }
  };

  const handleCreateBooking = (booking: CustomerBooking) => {
    void persistCreatedBooking(booking);
    showToast(`${booking.type} ${booking.id} saved (${booking.paymentStatus || 'Confirmed'}).`);
  };

  const handleCompleteBookingPayment = (id: string, payment: PaymentCompletionResult) => {
    void persistCompletePayment(id, payment);
    showToast(`Payment verified (${payment.transactionRef}) for ${id}.`);
  };

  const handleCancelBooking = async (id: string) => {
    setCustomerBookings((prev) =>
      prev.map((item) => (item.id === id ? { ...item, status: 'Cancelled' } : item))
    );
    const claim = bookingClaims.find((c) => c.id === id);
    try {
      await fetch(`/api/bookings/${encodeURIComponent(id)}/cancel`, {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ claimToken: claim?.token || '' }),
      });
    } catch {
      // Ignore network errors
    }
    showToast(`Reservation ${id} marked as cancelled.`);
  };

  const handleSubmitSellCar = async (lead: SellCarSubmission) => {
    setSellerLeads((prev) => [lead, ...prev]);
    try {
      await fetch('/api/seller-leads', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(lead),
      });
    } catch {
      // Ignore network errors
    }
    showToast('Vehicle valuation submitted to Zamto Africa Lusaka.');
  };

  const appContent = (
    <I18nProvider lang={lang} setLang={handleLangChange}>
      <div className="min-h-screen flex flex-col bg-[#f8fafc] text-[#0f172a]">
        {mapsQuotaExceeded && (
          <div className="bg-amber-50 border-b border-amber-200 text-amber-900 px-4 py-2.5 text-xs md:text-sm text-center sticky top-0 z-50 shadow-sm">
            <span>
              Google Maps Platform quota reached. If you are the app owner, visit{' '}
              <a
                href="https://developers.google.com/maps/ai/ai-studio?utm_campaign=gmp_mcp_codeassist_v1_aistudio#quota_exceeded_errors"
                target="_blank"
                rel="noopener noreferrer"
                className="underline font-semibold text-amber-950 hover:text-amber-800"
              >
                maps developer site
              </a>{' '}
              for instructions to update your account.
            </span>
          </div>
        )}
        <SiteHeader
          route={route}
          onNavigate={navigateTo}
          currency={currency}
          onCurrencyChange={setCurrency}
          lang={lang}
          onLangChange={handleLangChange}
          bookingCount={customerBookings.filter((b) => b.status !== 'Cancelled').length}
          compareCount={compareIds.length}
          onOpenCompare={() => {
            setSalesTab('buy');
            setRoute('sales');
            setShowCompareModal(true);
          }}
          onOpenSellTab={() => {
            setSalesTab('sell');
            navigateTo('sales');
          }}
        />

      {toastMessage && (
        <div className="fixed top-20 right-4 z-50 bg-[#003087] text-white text-xs font-semibold px-4 py-2.5 rounded-xl shadow-lg border border-[#e11d48]">
          {toastMessage}
        </div>
      )}

      {showAgreementModal && (
        <RentalAgreementModal onClose={() => setShowAgreementModal(false)} />
      )}

      <main className="flex-1">
        {route === 'home' && (
          <HomePage
            currency={currency}
            lang={lang}
            hireSearch={hireSearch}
            onUpdateHireSearch={setHireSearch}
            onSubmitHireSearch={() => {
              setHireInitialCategory('All');
              navigateTo('hire');
            }}
            onSelectCategory={(cat) => {
              setHireInitialCategory(cat);
              navigateTo('hire');
            }}
            allHireFleet={hireFleet}
            featuredSales={salesInventory.filter((v) => v.featured).slice(0, 3)}
            onViewHireVehicle={(v) => {
              setSelectedHireVehicle(v);
              navigateTo('hire');
            }}
            onBookHireVehicle={(v) => {
              setPreselectedAddons([]);
              setPreselectedTier('Premium');
              setBookingHireVehicle(v);
              navigateTo('hire');
            }}
            onViewSaleVehicle={(v) => {
              setSalesTab('buy');
              setSelectedSaleVehicle(v);
              navigateTo('sales');
            }}
            onNavigate={navigateTo}
          />
        )}

        {route === 'hire' && (
          <CarHireView
            fleet={hireFleet}
            currency={currency}
            search={hireSearch}
            onUpdateSearch={setHireSearch}
            initialCategory={hireInitialCategory}
            selectedVehicle={selectedHireVehicle}
            onSelectVehicle={setSelectedHireVehicle}
            bookingVehicle={bookingHireVehicle}
            onOpenBooking={(v, addons = [], tier = 'Premium') => {
              setPreselectedAddons(addons);
              setPreselectedTier(tier);
              setBookingHireVehicle(v);
            }}
            preselectedAddons={preselectedAddons}
            preselectedTier={preselectedTier}
            onCreateBooking={handleCreateBooking}
            onGoToBookings={() => navigateTo('bookings')}
            onOpenAgreement={() => setShowAgreementModal(true)}
          />
        )}

        {route === 'sales' && (
          <CarSalesView
            inventory={salesInventory}
            currency={currency}
            activeTab={salesTab}
            onTabChange={setSalesTab}
            compareIds={compareIds}
            onToggleCompare={handleToggleCompare}
            showCompareModal={showCompareModal}
            onSetShowCompareModal={setShowCompareModal}
            selectedSaleVehicle={selectedSaleVehicle}
            onSelectSaleVehicle={setSelectedSaleVehicle}
            onCreateBooking={handleCreateBooking}
            onSubmitSellCar={handleSubmitSellCar}
          />
        )}

        {route === 'locations' && (
          <LocationsPage
            onHireFromBranch={(pickupLabel, dropoffLabel) => {
              setHireSearch((prev) => ({
                ...prev,
                pickupLocation: pickupLabel,
                dropoffLocation: dropoffLabel || 'Same as pickup',
              }));
              setHireInitialCategory('All');
              navigateTo('hire');
            }}
          />
        )}

        {route === 'services' && (
          <ServicesPage
            onNavigate={navigateTo}
            currency={currency}
            onOpenAgreement={() => setShowAgreementModal(true)}
          />
        )}
        {route === 'about' && <AboutPage onNavigate={navigateTo} />}
        {route === 'faq' && <FaqPage />}
        {route === 'blog' && <BlogPage />}
        {route === 'contact' && <ContactPage />}

        {route === 'bookings' && (
          <MyBookingsView
            bookings={customerBookings}
            currency={currency}
            onCancelBooking={handleCancelBooking}
            onCompleteBookingPayment={handleCompleteBookingPayment}
            onNavigate={navigateTo}
          />
        )}

        {route === 'admin' && (
          <AdminDashboardView
            hireFleet={hireFleet}
            salesInventory={salesInventory}
            bookings={adminBookings}
            sellerLeads={sellerLeads}
            currency={currency}
            zmwPerUsd={zmwPerUsd}
            adminAuth={{
              authenticated: adminAuthenticated,
              passwordConfigured: adminPasswordConfigured,
              authLoading: adminAuthLoading,
              onSetupPassword: async (password, idToken) => {
                const headers: Record<string, string> = { 'Content-Type': 'application/json' };
                const token = idToken || firebaseIdToken;
                if (token) headers.Authorization = `Bearer ${token}`;
                const res = await fetch('/api/admin/setup-password', {
                  method: 'POST',
                  credentials: 'include',
                  headers,
                  body: JSON.stringify({ password }),
                });
                const data = (await res.json().catch(() => ({}))) as { error?: string };
                if (!res.ok) return data.error || 'Could not save admin password.';
                setAdminPasswordConfigured(true);
                setAdminAuthenticated(true);
                showToast('Admin password saved and panel unlocked.');
                return null;
              },
              onLoginPassword: async (password, idToken) => {
                const headers: Record<string, string> = { 'Content-Type': 'application/json' };
                const token = idToken || firebaseIdToken;
                if (token) headers.Authorization = `Bearer ${token}`;
                const res = await fetch('/api/admin/login', {
                  method: 'POST',
                  credentials: 'include',
                  headers,
                  body: JSON.stringify({ password }),
                });
                const data = (await res.json().catch(() => ({}))) as { error?: string };
                if (!res.ok) return data.error || 'Incorrect password.';
                setAdminAuthenticated(true);
                showToast('Admin unlocked.');
                return null;
              },
              onVerifyGoogleAdmin: async (idToken) => {
                setFirebaseIdToken(idToken);
                const res = await fetch('/api/admin/session', {
                  credentials: 'include',
                  headers: { Authorization: `Bearer ${idToken}` },
                });
                const data = (await res.json().catch(() => ({}))) as { authenticated?: boolean };
                if (data.authenticated) {
                  setAdminAuthenticated(true);
                  showToast('Signed in to Admin.');
                  return null;
                }
                return 'Enter the Backend Admin Password once to authorize this Google account.';
              },
              onLogout: async () => {
                await fetch('/api/admin/logout', { method: 'POST', credentials: 'include' });
                try {
                  await auth.signOut();
                } catch {
                  // Ignore Firebase sign-out error
                }
                setAdminAuthenticated(false);
                showToast('Admin panel locked.');
              },
              onChangePassword: async (currentPassword, newPassword) => {
                const res = await adminFetch('/api/admin/change-password', {
                  method: 'POST',
                  body: JSON.stringify({ currentPassword, newPassword }),
                });
                if (!res) return 'Could not update password. Verify your current password.';
                showToast('Admin password updated.');
                return null;
              },
            }}
            onUpdateExchangeRate={async (nextRate, source) => {
              const saved = setZmwPerUsd(nextRate, source);
              setZmwPerUsdState(saved);
              const res = await adminFetch('/api/admin/fx-rate', {
                method: 'PUT',
                body: JSON.stringify({ rate: saved, source }),
              });
              if (res) {
                showToast(`Exchange rate saved: 1 USD = ZMW ${saved.toFixed(2)}`);
              }
            }}
            onSyncLiveRate={async () => {
              const live = await fetchLiveUsdZmwRate();
              if (live) {
                setZmwPerUsdState(live);
                await adminFetch('/api/admin/fx-rate', {
                  method: 'PUT',
                  body: JSON.stringify({ rate: live, source: 'live' }),
                });
                showToast(`Synced & saved live rate: 1 USD = ZMW ${live.toFixed(2)}`);
              } else {
                showToast(`Using current indicative rate: 1 USD = ZMW ${zmwPerUsd.toFixed(2)}`);
              }
              return live;
            }}
            onUpdateHireVehicle={async (id, patch) => {
              const existing = hireFleet.find((v) => v.id === id);
              if (!existing) return;
              const updated = { ...existing, ...patch };
              const res = await adminFetch(`/api/admin/hire-vehicles/${encodeURIComponent(id)}`, {
                method: 'PUT',
                body: JSON.stringify(updated),
              });
              if (res) {
                const data = (await res.json()) as { vehicle?: HireVehicle };
                setHireFleet((prev) =>
                  prev.map((v) => (v.id === id ? data.vehicle || updated : v))
                );
                showToast('Hire vehicle saved permanently.');
              }
            }}
            onAddHireVehicle={async (v) => {
              const res = await adminFetch('/api/admin/hire-vehicles', {
                method: 'POST',
                body: JSON.stringify(v),
              });
              if (res) {
                const data = (await res.json()) as { vehicle?: HireVehicle };
                setHireFleet((prev) => [data.vehicle || v, ...prev]);
                showToast(`Saved ${v.name} to Hire Fleet.`);
              }
            }}
            onDeleteHireVehicle={async (id) => {
              const res = await adminFetch(`/api/admin/hire-vehicles/${encodeURIComponent(id)}`, {
                method: 'DELETE',
              });
              if (res) {
                setHireFleet((prev) => prev.filter((v) => v.id !== id));
                showToast('Removed hire vehicle.');
              }
            }}
            onUpdateSaleVehicle={async (id, patch) => {
              const existing = salesInventory.find((v) => v.id === id);
              if (!existing) return;
              const updated = { ...existing, ...patch };
              const res = await adminFetch(`/api/admin/sale-vehicles/${encodeURIComponent(id)}`, {
                method: 'PUT',
                body: JSON.stringify(updated),
              });
              if (res) {
                const data = (await res.json()) as { vehicle?: SaleVehicle };
                setSalesInventory((prev) =>
                  prev.map((v) => (v.id === id ? data.vehicle || updated : v))
                );
                showToast('Sales vehicle saved permanently.');
              }
            }}
            onAddSaleVehicle={async (v) => {
              const res = await adminFetch('/api/admin/sale-vehicles', {
                method: 'POST',
                body: JSON.stringify(v),
              });
              if (res) {
                const data = (await res.json()) as { vehicle?: SaleVehicle };
                setSalesInventory((prev) => [data.vehicle || v, ...prev]);
                showToast(`Saved ${v.name} to Sales Marketplace.`);
              }
            }}
            onDeleteSaleVehicle={async (id) => {
              const res = await adminFetch(`/api/admin/sale-vehicles/${encodeURIComponent(id)}`, {
                method: 'DELETE',
              });
              if (res) {
                setSalesInventory((prev) => prev.filter((v) => v.id !== id));
                showToast('Removed vehicle listing.');
              }
            }}
            onResetFleetDefaults={async () => {
              const res = await adminFetch('/api/admin/reset-fleet', { method: 'POST' });
              if (res) {
                const data = (await res.json()) as {
                  hireFleet?: HireVehicle[];
                  salesInventory?: SaleVehicle[];
                };
                setHireFleet(data.hireFleet || INITIAL_HIRE_FLEET);
                setSalesInventory(data.salesInventory || INITIAL_SALES_INVENTORY);
                showToast('Restored default fleet & studio cutouts.');
              }
            }}
            onUpdateBookingStatus={async (id, status) => {
              const res = await adminFetch(`/api/admin/bookings/${encodeURIComponent(id)}`, {
                method: 'PATCH',
                body: JSON.stringify({ status }),
              });
              if (res) {
                setAdminBookings((prev) =>
                  prev.map((b) => (b.id === id ? { ...b, status } : b))
                );
                showToast(`Booking ${id} updated.`);
              }
            }}
            onUpdateBookingPaymentStatus={async (id, paymentStatus) => {
              const res = await adminFetch(`/api/admin/bookings/${encodeURIComponent(id)}`, {
                method: 'PATCH',
                body: JSON.stringify({ paymentStatus }),
              });
              if (res) {
                setAdminBookings((prev) =>
                  prev.map((b) => (b.id === id ? { ...b, paymentStatus } : b))
                );
                showToast(`Payment status updated for ${id}.`);
              }
            }}
            onDeleteBooking={async (id) => {
              const res = await adminFetch(`/api/admin/bookings/${encodeURIComponent(id)}`, {
                method: 'DELETE',
              });
              if (res) {
                setAdminBookings((prev) => prev.filter((b) => b.id !== id));
                showToast(`Booking ${id} deleted.`);
              }
            }}
          />
        )}
      </main>

      <SiteFooter
        onNavigate={navigateTo}
        onOpenSellTab={() => {
          setSalesTab('sell');
          navigateTo('sales');
        }}
        onOpenAgreement={() => setShowAgreementModal(true)}
      />

      <MobileBottomNav route={route} onNavigate={navigateTo} />
      <FloatingWhatsAppButton />
      <OfflineIndicator />
      </div>
    </I18nProvider>
  );

  if (!GOOGLE_MAPS_API_KEY) {
    return appContent;
  }

  return (
    <APIProvider
      apiKey={GOOGLE_MAPS_API_KEY}
      language="en"
      region="ZM"
      libraries={['places', 'marker', 'routes']}
    >
      {appContent}
    </APIProvider>
  );
}

export default App;
