export type CurrencyMode = 'ZMW' | 'USD';
export type LanguageCode = 'en' | 'zh' | 'fr' | 'pt' | 'es' | 'de' | 'ja';

export type PageRoute =
  | 'home'
  | 'hire'
  | 'sales'
  | 'locations'
  | 'services'
  | 'about'
  | 'faq'
  | 'blog'
  | 'contact'
  | 'bookings'
  | 'admin';

export type VehicleCategory =
  | 'Economy'
  | 'Sedan'
  | 'SUV / 4x4'
  | 'Pickup'
  | 'Luxury'
  | 'Van / Bus'
  | 'Small Truck';

export type HirePackageTier = 'Basic' | 'Premium' | 'City Exit';

export interface VehiclePhoto {
  url: string;
  label: string;
}

export interface HireVehicle {
  id: string;
  name: string;
  brand: string;
  year: number;
  category: VehicleCategory;
  fleetClass?: string;
  modelIntro?: string;
  transmission: 'Automatic' | 'Manual';
  fuel: 'Diesel' | 'Petrol' | 'Hybrid';
  seats: number;
  bags: number;
  dailyRateZmw: number;
  basicRateZmw: number;
  premiumRateZmw?: number;
  cityExitRateZmw?: number;
  weeklyRateZmw: number;
  monthlyRateZmw: number;
  depositZmw: number;
  engine: string;
  mileagePolicy: string;
  locations: string[];
  features: string[];
  has4x4: boolean;
  hasGps: boolean;
  hasAc: boolean;
  hasChildSeatOption: boolean;
  unlimitedMileage: boolean;
  status: 'Available' | 'Booked' | 'Maintenance';
  bookedDates: string[];
  photos: VehiclePhoto[];
  description: string;
}

export interface SaleVehicle {
  id: string;
  name: string;
  make: string;
  model: string;
  year: number;
  bodyType: VehicleCategory;
  priceZmw: number;
  mileageKm: number;
  engine: string;
  fuel: 'Diesel' | 'Petrol';
  transmission: 'Automatic' | 'Manual';
  color: string;
  location: string;
  condition: 'Fresh Japanese Import' | 'Zambian Used' | 'Certified Pre-Owned';
  status: 'For Sale' | 'Reserved' | 'Sold';
  importOrigin: string;
  warranty: string;
  serviceHistory: string;
  conditionSummary: string;
  features: string[];
  photos: VehiclePhoto[];
  featured?: boolean;
}

export interface HireSearchCriteria {
  pickupLocation: string;
  dropoffLocation: string;
  pickupDate: string;
  pickupTime: string;
  returnDate: string;
  returnTime: string;
  driverAge: string;
}

export interface HireBookingAddon {
  id: string;
  label: string;
  priceZmw: number;
  billing: 'per_day' | 'flat';
  description: string;
}

export interface CustomerBooking {
  id: string;
  type: 'Car Hire' | 'Test Drive' | 'Purchase Offer';
  vehicleId: string;
  vehicleName: string;
  pickupLocation?: string;
  dropoffLocation?: string;
  startDate: string;
  endDate?: string;
  totalZmw: number;
  paymentMethod: string;
  paymentStatus?: 'Paid' | 'Deposit Paid' | 'Pending Online Verification' | 'Pending Desk Payment';
  paymentTransactionRef?: string;
  paidAmountZmw?: number;
  paidAt?: string;
  includeVat?: boolean;
  vatAmountZmw?: number;
  customerName: string;
  customerPhone: string;
  customerEmail: string;
  licenceFileName?: string;
  residenceFileName?: string;
  nrcOrPassport?: string;
  dateOfBirth?: string;
  licenceNumber?: string;
  licenceIssueDate?: string;
  physicalAddress?: string;
  hireKind?: 'Personal' | 'Company';
  companyName?: string;
  packageTier?: HirePackageTier;
  tripZone?: 'Within City' | 'Outside City';
  agreementAccepted?: boolean;
  contractSignedAt?: string;
  addons?: string[];
  status: 'Confirmed' | 'Pending Verification' | 'Cancelled';
  createdAt: string;
}

export interface SellCarSubmission {
  id: string;
  sellerType: 'Private Seller' | 'Dealer Partner';
  name: string;
  phone: string;
  city: string;
  makeModel: string;
  year: number;
  mileageKm: number;
  askingPriceZmw: number;
  condition: string;
  createdAt: string;
}

export interface LusakaDeliveryZone {
  id: string;
  label: string;
  shortName: string;
  area: string;
  zoneKind: 'Head Office' | 'Airport Terminal' | 'Lusaka Delivery Zone' | 'Out-of-City Corridor';
  deliveryTime: string;
  transferNote: string;
  mapX: number;
  mapY: number;
  isLusakaLocal: boolean;
}

export interface BranchLocation {
  id: string;
  name: string;
  city: string;
  kind: 'Head Office' | 'Airport Transfer Zone' | 'Lusaka Delivery Zone' | 'City Exit Corridor';
  address: string;
  hours: string;
  phone: string;
  services: string[];
  mapX: number;
  mapY: number;
}

export interface BlogArticle {
  id: string;
  title: string;
  category: string;
  readTime: string;
  date: string;
  excerpt: string;
  content: string[];
  image: string;
}

export interface FaqItem {
  category: string;
  question: string;
  answer: string;
}
