import { asc, desc, eq, inArray } from 'drizzle-orm';
import { db } from './index.ts';
import {
  appSettings,
  bookings,
  hireVehicles,
  saleVehicles,
  sellerLeads,
} from './schema.ts';
import { INITIAL_HIRE_FLEET, INITIAL_SALES_INVENTORY } from '../data/zambiaData.ts';
import type {
  CustomerBooking,
  HireVehicle,
  SaleVehicle,
  SellCarSubmission,
} from '../types.ts';

export async function ensureFleetSeeded() {
  try {
    const existingHire = await db.select({ id: hireVehicles.id }).from(hireVehicles).limit(1);
    if (existingHire.length === 0) {
      await db
        .insert(hireVehicles)
        .values(
          INITIAL_HIRE_FLEET.map((v, idx) => ({
            id: v.id,
            name: v.name,
            brand: v.brand,
            category: v.category,
            dailyRateZmw: Math.round(v.dailyRateZmw),
            status: v.status,
            sortOrder: idx,
            data: v,
          }))
        )
        .onConflictDoNothing();
    }

    const existingSales = await db.select({ id: saleVehicles.id }).from(saleVehicles).limit(1);
    if (existingSales.length === 0) {
      await db
        .insert(saleVehicles)
        .values(
          INITIAL_SALES_INVENTORY.map((v, idx) => ({
            id: v.id,
            name: v.name,
            make: v.make,
            year: Math.round(v.year),
            priceZmw: Math.round(v.priceZmw),
            status: v.status,
            sortOrder: idx,
            data: v,
          }))
        )
        .onConflictDoNothing();
    }
  } catch (error) {
    console.error('Failed to seed fleet defaults:', error);
    throw new Error('Failed to initialize fleet catalog.', { cause: error });
  }
}

export async function listHireVehicles(): Promise<HireVehicle[]> {
  try {
    await ensureFleetSeeded();
    const rows = await db
      .select()
      .from(hireVehicles)
      .orderBy(asc(hireVehicles.sortOrder), asc(hireVehicles.name));
    return rows.map((r) => r.data);
  } catch (error) {
    console.error('Database listHireVehicles failed:', error);
    throw new Error('Failed to load hire fleet.', { cause: error });
  }
}

export async function upsertHireVehicle(vehicle: HireVehicle): Promise<HireVehicle> {
  try {
    await db
      .insert(hireVehicles)
      .values({
        id: vehicle.id,
        name: vehicle.name,
        brand: vehicle.brand,
        category: vehicle.category,
        dailyRateZmw: Math.round(vehicle.dailyRateZmw),
        status: vehicle.status,
        sortOrder: -1,
        data: vehicle,
        updatedAt: new Date(),
      })
      .onConflictDoUpdate({
        target: hireVehicles.id,
        set: {
          name: vehicle.name,
          brand: vehicle.brand,
          category: vehicle.category,
          dailyRateZmw: Math.round(vehicle.dailyRateZmw),
          status: vehicle.status,
          data: vehicle,
          updatedAt: new Date(),
        },
      });
    return vehicle;
  } catch (error) {
    console.error('Database upsertHireVehicle failed:', error);
    throw new Error('Failed to save hire vehicle.', { cause: error });
  }
}

export async function deleteHireVehicleById(id: string): Promise<void> {
  try {
    await db.delete(hireVehicles).where(eq(hireVehicles.id, id));
  } catch (error) {
    console.error('Database deleteHireVehicleById failed:', error);
    throw new Error('Failed to delete hire vehicle.', { cause: error });
  }
}

export async function listSaleVehicles(): Promise<SaleVehicle[]> {
  try {
    await ensureFleetSeeded();
    const rows = await db
      .select()
      .from(saleVehicles)
      .orderBy(asc(saleVehicles.sortOrder), asc(saleVehicles.name));
    return rows.map((r) => r.data);
  } catch (error) {
    console.error('Database listSaleVehicles failed:', error);
    throw new Error('Failed to load sales inventory.', { cause: error });
  }
}

export async function upsertSaleVehicle(vehicle: SaleVehicle): Promise<SaleVehicle> {
  try {
    await db
      .insert(saleVehicles)
      .values({
        id: vehicle.id,
        name: vehicle.name,
        make: vehicle.make,
        year: Math.round(vehicle.year),
        priceZmw: Math.round(vehicle.priceZmw),
        status: vehicle.status,
        sortOrder: -1,
        data: vehicle,
        updatedAt: new Date(),
      })
      .onConflictDoUpdate({
        target: saleVehicles.id,
        set: {
          name: vehicle.name,
          make: vehicle.make,
          year: Math.round(vehicle.year),
          priceZmw: Math.round(vehicle.priceZmw),
          status: vehicle.status,
          data: vehicle,
          updatedAt: new Date(),
        },
      });
    return vehicle;
  } catch (error) {
    console.error('Database upsertSaleVehicle failed:', error);
    throw new Error('Failed to save sales vehicle.', { cause: error });
  }
}

export async function deleteSaleVehicleById(id: string): Promise<void> {
  try {
    await db.delete(saleVehicles).where(eq(saleVehicles.id, id));
  } catch (error) {
    console.error('Database deleteSaleVehicleById failed:', error);
    throw new Error('Failed to delete sales vehicle.', { cause: error });
  }
}

export async function resetAllFleetDefaults(): Promise<{
  hireFleet: HireVehicle[];
  salesInventory: SaleVehicle[];
}> {
  try {
    await db.delete(hireVehicles);
    await db
      .insert(hireVehicles)
      .values(
        INITIAL_HIRE_FLEET.map((v, idx) => ({
          id: v.id,
          name: v.name,
          brand: v.brand,
          category: v.category,
          dailyRateZmw: Math.round(v.dailyRateZmw),
          status: v.status,
          sortOrder: idx,
          data: v,
        }))
      )
      .onConflictDoNothing();

    await db.delete(saleVehicles);
    await db
      .insert(saleVehicles)
      .values(
        INITIAL_SALES_INVENTORY.map((v, idx) => ({
          id: v.id,
          name: v.name,
          make: v.make,
          year: Math.round(v.year),
          priceZmw: Math.round(v.priceZmw),
          status: v.status,
          sortOrder: idx,
          data: v,
        }))
      )
      .onConflictDoNothing();

    return {
      hireFleet: INITIAL_HIRE_FLEET,
      salesInventory: INITIAL_SALES_INVENTORY,
    };
  } catch (error) {
    console.error('Database resetAllFleetDefaults failed:', error);
    throw new Error('Failed to restore default fleet catalog.', { cause: error });
  }
}

export async function listAllBookings(): Promise<CustomerBooking[]> {
  try {
    const rows = await db.select().from(bookings).orderBy(desc(bookings.createdAt));
    return rows.map((r) => r.data);
  } catch (error) {
    console.error('Database listAllBookings failed:', error);
    throw new Error('Failed to load bookings.', { cause: error });
  }
}

export async function listBookingsByIds(ids: string[]): Promise<CustomerBooking[]> {
  if (ids.length === 0) return [];
  try {
    const rows = await db
      .select()
      .from(bookings)
      .where(inArray(bookings.id, ids))
      .orderBy(desc(bookings.createdAt));
    return rows.map((r) => r.data);
  } catch (error) {
    console.error('Database listBookingsByIds failed:', error);
    throw new Error('Failed to load customer bookings.', { cause: error });
  }
}

export async function getBookingById(id: string): Promise<CustomerBooking | null> {
  try {
    const rows = await db.select().from(bookings).where(eq(bookings.id, id)).limit(1);
    return rows[0]?.data || null;
  } catch (error) {
    console.error('Database getBookingById failed:', error);
    throw new Error('Failed to load booking record.', { cause: error });
  }
}

export async function upsertBooking(booking: CustomerBooking): Promise<CustomerBooking> {
  try {
    await db
      .insert(bookings)
      .values({
        id: booking.id,
        type: booking.type,
        vehicleId: booking.vehicleId,
        vehicleName: booking.vehicleName,
        customerName: booking.customerName,
        customerPhone: booking.customerPhone,
        customerEmail: booking.customerEmail,
        totalZmw: Math.round(booking.totalZmw),
        paymentStatus: booking.paymentStatus || 'Pending Online Verification',
        status: booking.status,
        data: booking,
        createdAt: booking.createdAt ? new Date(booking.createdAt) : new Date(),
        updatedAt: new Date(),
      })
      .onConflictDoUpdate({
        target: bookings.id,
        set: {
          totalZmw: Math.round(booking.totalZmw),
          paymentStatus: booking.paymentStatus || 'Pending Online Verification',
          status: booking.status,
          data: booking,
          updatedAt: new Date(),
        },
      });
    return booking;
  } catch (error) {
    console.error('Database upsertBooking failed:', error);
    throw new Error('Failed to save booking.', { cause: error });
  }
}

export async function deleteBookingById(id: string): Promise<void> {
  try {
    await db.delete(bookings).where(eq(bookings.id, id));
  } catch (error) {
    console.error('Database deleteBookingById failed:', error);
    throw new Error('Failed to delete booking.', { cause: error });
  }
}

export async function listAllSellerLeads(): Promise<SellCarSubmission[]> {
  try {
    const rows = await db.select().from(sellerLeads).orderBy(desc(sellerLeads.createdAt));
    return rows.map((r) => r.data);
  } catch (error) {
    console.error('Database listAllSellerLeads failed:', error);
    throw new Error('Failed to load seller leads.', { cause: error });
  }
}

export async function insertSellerLead(lead: SellCarSubmission): Promise<SellCarSubmission> {
  try {
    await db
      .insert(sellerLeads)
      .values({
        id: lead.id,
        sellerName: lead.name,
        phone: lead.phone,
        makeModel: lead.makeModel,
        askingPriceZmw: Math.round(lead.askingPriceZmw),
        data: lead,
        createdAt: lead.createdAt ? new Date(lead.createdAt) : new Date(),
      })
      .onConflictDoNothing();
    return lead;
  } catch (error) {
    console.error('Database insertSellerLead failed:', error);
    throw new Error('Failed to save vehicle valuation lead.', { cause: error });
  }
}

export async function getSetting<T extends Record<string, unknown>>(key: string): Promise<T | null> {
  try {
    const rows = await db.select().from(appSettings).where(eq(appSettings.key, key)).limit(1);
    return (rows[0]?.value as T | undefined) || null;
  } catch (error) {
    console.error(`Database getSetting(${key}) failed:`, error);
    throw new Error('Failed to load application setting.', { cause: error });
  }
}

export async function setSetting<T extends Record<string, unknown>>(key: string, value: T): Promise<void> {
  try {
    await db
      .insert(appSettings)
      .values({
        key,
        value,
        updatedAt: new Date(),
      })
      .onConflictDoUpdate({
        target: appSettings.key,
        set: {
          value,
          updatedAt: new Date(),
        },
      });
  } catch (error) {
    console.error(`Database setSetting(${key}) failed:`, error);
    throw new Error('Failed to save application setting.', { cause: error });
  }
}
