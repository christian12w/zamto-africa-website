import { integer, jsonb, pgTable, serial, text, timestamp } from 'drizzle-orm/pg-core';
import type {
  CustomerBooking,
  HireVehicle,
  SaleVehicle,
  SellCarSubmission,
} from '../types.ts';

export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  uid: text('uid').notNull().unique(),
  email: text('email').notNull(),
  role: text('role').notNull().default('customer'),
  createdAt: timestamp('created_at').defaultNow(),
});

export const hireVehicles = pgTable('hire_vehicles', {
  id: text('id').primaryKey(),
  name: text('name').notNull(),
  brand: text('brand').notNull(),
  category: text('category').notNull(),
  dailyRateZmw: integer('daily_rate_zmw').notNull(),
  status: text('status').notNull().default('Available'),
  sortOrder: integer('sort_order').notNull().default(0),
  data: jsonb('data').$type<HireVehicle>().notNull(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

export const saleVehicles = pgTable('sale_vehicles', {
  id: text('id').primaryKey(),
  name: text('name').notNull(),
  make: text('make').notNull(),
  year: integer('year').notNull(),
  priceZmw: integer('price_zmw').notNull(),
  status: text('status').notNull().default('For Sale'),
  sortOrder: integer('sort_order').notNull().default(0),
  data: jsonb('data').$type<SaleVehicle>().notNull(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

export const bookings = pgTable('bookings', {
  id: text('id').primaryKey(),
  type: text('type').notNull(),
  vehicleId: text('vehicle_id').notNull(),
  vehicleName: text('vehicle_name').notNull(),
  customerName: text('customer_name').notNull(),
  customerPhone: text('customer_phone').notNull(),
  customerEmail: text('customer_email').notNull(),
  totalZmw: integer('total_zmw').notNull(),
  paymentStatus: text('payment_status').notNull().default('Pending Online Verification'),
  status: text('status').notNull().default('Confirmed'),
  data: jsonb('data').$type<CustomerBooking>().notNull(),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

export const sellerLeads = pgTable('seller_leads', {
  id: text('id').primaryKey(),
  sellerName: text('seller_name').notNull(),
  phone: text('phone').notNull(),
  makeModel: text('make_model').notNull(),
  askingPriceZmw: integer('asking_price_zmw').notNull(),
  data: jsonb('data').$type<SellCarSubmission>().notNull(),
  createdAt: timestamp('created_at').defaultNow(),
});

export const appSettings = pgTable('app_settings', {
  key: text('key').primaryKey(),
  value: jsonb('value').$type<Record<string, unknown>>().notNull(),
  updatedAt: timestamp('updated_at').defaultNow(),
});
