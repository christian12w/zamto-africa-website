import crypto from 'crypto';
import type { NextFunction, Request, Response } from 'express';
import type { DecodedIdToken } from 'firebase-admin/auth';
import { adminAuth } from '../lib/firebase-admin.ts';
import { getOrCreateUser, getUserByUid } from '../db/users.ts';
import { getSetting, setSetting } from '../db/repository.ts';

export interface AuthRequest extends Request {
  user?: DecodedIdToken;
  isAdmin?: boolean;
}

export const ADMIN_COOKIE_NAME = 'zamto_admin_session';
const ADMIN_SESSION_TTL_MS = 12 * 60 * 60 * 1000;
const EPHEMERAL_FALLBACK_SECRET = crypto.randomBytes(32).toString('hex');
let cachedSigningSecret: string | null = null;

interface AdminCredsRecord {
  hash: string;
  salt: string;
  updatedAt: string;
  [key: string]: unknown;
}

const loginAttempts = new Map<string, { count: number; resetAt: number }>();

export function checkLoginRateLimit(ip: string): boolean {
  const now = Date.now();
  const entry = loginAttempts.get(ip);
  if (!entry || entry.resetAt <= now) {
    return true;
  }
  return entry.count < 8;
}

export function recordFailedLoginAttempt(ip: string) {
  const now = Date.now();
  const entry = loginAttempts.get(ip);
  if (!entry || entry.resetAt <= now) {
    loginAttempts.set(ip, { count: 1, resetAt: now + 15 * 60 * 1000 });
    return;
  }
  entry.count += 1;
}

export function clearLoginAttempts(ip: string) {
  loginAttempts.delete(ip);
}

async function getSigningSecret(): Promise<string> {
  const envSecret = (process.env.SESSION_SECRET || '').trim();
  if (envSecret && envSecret.length >= 16) {
    return envSecret;
  }
  if (cachedSigningSecret) {
    return cachedSigningSecret;
  }
  try {
    const existing = await getSetting<{ secret?: string }>('session_hmac_secret');
    if (existing?.secret && existing.secret.length >= 32) {
      cachedSigningSecret = existing.secret;
      return existing.secret;
    }
    const generated = crypto.randomBytes(32).toString('hex');
    await setSetting('session_hmac_secret', { secret: generated });
    cachedSigningSecret = generated;
    return generated;
  } catch {
    cachedSigningSecret = EPHEMERAL_FALLBACK_SECRET;
    return EPHEMERAL_FALLBACK_SECRET;
  }
}

function hashScrypt(password: string, salt: string): string {
  return crypto.scryptSync(password, salt, 64).toString('hex');
}

function timingSafeHexEqual(aHex: string, bHex: string): boolean {
  const aBuf = Buffer.from(aHex, 'hex');
  const bBuf = Buffer.from(bHex, 'hex');
  if (aBuf.length === 0 || aBuf.length !== bBuf.length) return false;
  return crypto.timingSafeEqual(aBuf, bBuf);
}

export async function isAdminPasswordConfigured(): Promise<boolean> {
  const envPass = (process.env.ADMIN_PASSWORD || '').trim();
  if (envPass.length >= 6) return true;
  try {
    const creds = await getSetting<AdminCredsRecord>('admin_credentials');
    return Boolean(creds?.hash && creds?.salt);
  } catch {
    return false;
  }
}

export async function verifyAdminPassword(password: string): Promise<boolean> {
  if (!password || password.length < 4) return false;

  try {
    const creds = await getSetting<AdminCredsRecord>('admin_credentials');
    if (creds?.hash && creds?.salt) {
      const candidateHash = hashScrypt(password, creds.salt);
      return timingSafeHexEqual(candidateHash, creds.hash);
    }
  } catch {
    // Fallback to env password check below if settings lookup fails
  }

  const envPass = (process.env.ADMIN_PASSWORD || '').trim();
  if (!envPass) return false;

  const expectedDigest = crypto.createHash('sha256').update(envPass).digest('hex');
  const actualDigest = crypto.createHash('sha256').update(password).digest('hex');
  return timingSafeHexEqual(actualDigest, expectedDigest);
}

export async function saveNewAdminPassword(password: string): Promise<void> {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = hashScrypt(password, salt);
  await setSetting('admin_credentials', {
    hash,
    salt,
    updatedAt: new Date().toISOString(),
  });
}

export async function createSignedAdminSessionToken(subject = 'admin'): Promise<string> {
  const secret = await getSigningSecret();
  const payload = Buffer.from(
    JSON.stringify({
      sub: subject,
      exp: Date.now() + ADMIN_SESSION_TTL_MS,
      nonce: crypto.randomBytes(8).toString('hex'),
    })
  ).toString('base64url');
  const sig = crypto.createHmac('sha256', secret).update(payload).digest('base64url');
  return `${payload}.${sig}`;
}

export async function verifySignedAdminSessionToken(token: string): Promise<boolean> {
  const parts = token.split('.');
  if (parts.length !== 2) return false;
  const [payload, sig] = parts;
  if (!payload || !sig) return false;

  const secret = await getSigningSecret();
  const expectedSig = crypto.createHmac('sha256', secret).update(payload).digest('base64url');
  const sigBuf = Buffer.from(sig);
  const expBuf = Buffer.from(expectedSig);
  if (sigBuf.length !== expBuf.length || !crypto.timingSafeEqual(sigBuf, expBuf)) {
    return false;
  }

  try {
    const decoded = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8')) as {
      exp?: number;
    };
    return typeof decoded.exp === 'number' && decoded.exp > Date.now();
  } catch {
    return false;
  }
}

export function parseCookieHeader(cookieHeader: string | undefined): Record<string, string> {
  const result: Record<string, string> = {};
  if (!cookieHeader) return result;
  for (const part of cookieHeader.split(';')) {
    const eqIdx = part.indexOf('=');
    if (eqIdx === -1) continue;
    const key = part.slice(0, eqIdx).trim();
    const val = part.slice(eqIdx + 1).trim();
    if (key) {
      try {
        result[key] = decodeURIComponent(val);
      } catch {
        result[key] = val;
      }
    }
  }
  return result;
}

export function setAdminSessionCookie(req: Request, res: Response, token: string) {
  const proto = String(req.headers['x-forwarded-proto'] || req.protocol || 'http')
    .split(',')[0]
    .trim();
  const isHttps = proto === 'https' || req.secure;
  res.cookie(ADMIN_COOKIE_NAME, token, {
    httpOnly: true,
    secure: isHttps,
    sameSite: isHttps ? 'none' : 'lax',
    maxAge: ADMIN_SESSION_TTL_MS,
    path: '/',
  });
}

export function clearAdminSessionCookie(req: Request, res: Response) {
  const proto = String(req.headers['x-forwarded-proto'] || req.protocol || 'http')
    .split(',')[0]
    .trim();
  const isHttps = proto === 'https' || req.secure;
  res.clearCookie(ADMIN_COOKIE_NAME, {
    httpOnly: true,
    secure: isHttps,
    sameSite: isHttps ? 'none' : 'lax',
    path: '/',
  });
}

export async function createBookingClaimToken(bookingId: string): Promise<string> {
  const secret = await getSigningSecret();
  return crypto.createHmac('sha256', secret).update(`booking:${bookingId}`).digest('hex');
}

export async function verifyBookingClaimToken(bookingId: string, token: string): Promise<boolean> {
  if (!bookingId || !/^[0-9a-f]{64}$/i.test(token)) return false;
  const expected = await createBookingClaimToken(bookingId);
  return timingSafeHexEqual(token.toLowerCase(), expected);
}

export const requireAuth = async (req: AuthRequest, res: Response, next: NextFunction) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    res.status(401).json({ error: 'Unauthorized: Missing token' });
    return;
  }

  const token = authHeader.split('Bearer ')[1];
  try {
    const decodedToken = await adminAuth.verifyIdToken(token);
    req.user = decodedToken;
    if (decodedToken.email) {
      await getOrCreateUser(decodedToken.uid, decodedToken.email);
    }
    next();
  } catch (error) {
    console.error('Error verifying Firebase ID token:', error);
    res.status(401).json({ error: 'Unauthorized: Invalid token' });
  }
};

export async function isRequestAdmin(req: AuthRequest): Promise<boolean> {
  const cookies = parseCookieHeader(req.headers.cookie);
  const sessionToken = cookies[ADMIN_COOKIE_NAME];
  if (sessionToken && (await verifySignedAdminSessionToken(sessionToken))) {
    return true;
  }

  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    const idToken = authHeader.split('Bearer ')[1];
    try {
      const decoded = await adminAuth.verifyIdToken(idToken);
      req.user = decoded;
      const dbUser = await getUserByUid(decoded.uid);
      if (dbUser?.role === 'admin') {
        return true;
      }
    } catch {
      return false;
    }
  }

  return false;
}

export const requireAdmin = async (req: AuthRequest, res: Response, next: NextFunction) => {
  const authorized = await isRequestAdmin(req);
  if (!authorized) {
    res.status(401).json({ error: 'Admin authentication required.' });
    return;
  }
  req.isAdmin = true;
  next();
};
