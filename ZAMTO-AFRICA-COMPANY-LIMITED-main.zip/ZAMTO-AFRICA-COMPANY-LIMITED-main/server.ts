import 'dotenv/config';
import fs from 'fs';
import http from 'http';
import path from 'path';
import crypto from 'crypto';
import express from 'express';
import type { Request, Response } from 'express';
import nodemailer from 'nodemailer';
import type {
  CustomerBooking,
  HireVehicle,
  SaleVehicle,
  SellCarSubmission,
} from './src/types.ts';
import {
  deleteBookingById,
  deleteHireVehicleById,
  deleteSaleVehicleById,
  getBookingById,
  getSetting,
  insertSellerLead,
  listAllBookings,
  listAllSellerLeads,
  listBookingsByIds,
  listHireVehicles,
  listSaleVehicles,
  resetAllFleetDefaults,
  setSetting,
  upsertBooking,
  upsertHireVehicle,
  upsertSaleVehicle,
} from './src/db/repository.ts';
import {
  type AuthRequest,
  checkLoginRateLimit,
  clearAdminSessionCookie,
  clearLoginAttempts,
  createBookingClaimToken,
  createSignedAdminSessionToken,
  isAdminPasswordConfigured,
  isRequestAdmin,
  recordFailedLoginAttempt,
  requireAdmin,
  saveNewAdminPassword,
  setAdminSessionCookie,
  verifyAdminPassword,
  verifyBookingClaimToken,
} from './src/middleware/auth.ts';
import { adminAuth } from './src/lib/firebase-admin.ts';
import { promoteUserToAdmin } from './src/db/users.ts';
import {
  buildBrandedResendEmailHtml,
  ZAMTO_BRAND_LOGO_PATH,
} from './src/lib/resendEmailTemplate.ts';

const PORT = Number(process.env.PORT) || 3000;
const BUSINESS_EMAIL = (process.env.NOTIFICATION_EMAIL || 'zamtoafrica@gmail.com').trim();
const BUSINESS_WHATSAPP = (process.env.WHATSAPP_TARGET_NUMBER || '260572213038').replace(/\D/g, '');

const ALLOWED_RAILS = new Set([
  'MTN Mobile Money',
  'Airtel Money',
  'Zamtel Kwacha',
  'Visa / Mastercard',
  'Bank EFT / Zanaco',
]);

interface PendingLencoOrder {
  expectedAmountZmw: number;
  currency: string;
  rail: string;
  createdAt: number;
}

interface LencoWebhookRecord {
  reference: string;
  lencoReference?: string;
  status: string;
  amount: number;
  currency: string;
  reasonForFailure?: string | null;
  updatedAt: number;
}

const MAX_TRACKED_TX = 500;
const pendingLencoOrders = new Map<string, PendingLencoOrder>();
const verifiedLencoWebhooks = new Map<string, LencoWebhookRecord>();

function setBoundedMap<K, V>(map: Map<K, V>, key: K, value: V) {
  if (map.size >= MAX_TRACKED_TX) {
    const oldestKey = map.keys().next().value;
    if (oldestKey !== undefined) {
      map.delete(oldestKey);
    }
  }
  map.set(key, value);
}

function getLencoConfig() {
  const secretKey = (process.env.LENCO_SECRET_KEY || '').trim();
  const publicKey = (process.env.LENCO_PUBLIC_KEY || '').trim();
  const envRaw = (process.env.LENCO_ENV || 'production').trim().toLowerCase();
  const env: 'sandbox' | 'production' = envRaw === 'sandbox' ? 'sandbox' : 'production';
  const baseUrl =
    env === 'sandbox'
      ? 'https://sandbox.lenco.co/access/v2'
      : 'https://api.lenco.co/access/v2';
  const accountId = (process.env.LENCO_ACCOUNT_ID || '').trim();
  const isUuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(accountId);

  return {
    secretKey,
    publicKey,
    env,
    baseUrl,
    accountId: isUuid ? accountId : '',
    configured: Boolean(secretKey && !secretKey.includes('MY_')),
    publicConfigured: Boolean(publicKey && !publicKey.includes('MY_')),
  };
}

function normalizeZambiaMomoPhone(raw: string): string | null {
  const digits = raw.replace(/\D/g, '');
  let national9 = '';
  if (digits.startsWith('260') && digits.length === 12) {
    national9 = digits.slice(3);
  } else if (digits.startsWith('0') && digits.length === 10) {
    national9 = digits.slice(1);
  } else if (digits.length === 9 && (digits.startsWith('9') || digits.startsWith('7') || digits.startsWith('5'))) {
    national9 = digits;
  } else {
    return null;
  }
  if (!/^[579]\d{8}$/.test(national9)) {
    return null;
  }
  return `0${national9}`;
}

function escapeHtml(raw: unknown): string {
  return String(raw ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function cleanText(raw: unknown, maxLen = 500): string {
  return String(raw ?? '')
    .replace(/[\r\n\t]+/g, ' ')
    .trim()
    .slice(0, maxLen);
}

function isValidEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email) && email.length <= 160;
}

function sanitizeSafeId(raw: unknown): string {
  const str = String(raw ?? '').trim();
  if (!/^[A-Za-z0-9_-]{3,128}$/.test(str)) return '';
  return str;
}

function resolveTrustedOrigin(req: Request): string {
  const configured = process.env.APP_URL?.trim();
  if (configured && /^https?:\/\//i.test(configured)) {
    return configured.replace(/\/+$/, '');
  }
  const protoHeader = String(req.headers['x-forwarded-proto'] || req.protocol || 'http')
    .split(',')[0]
    .trim();
  const proto = protoHeader === 'https' ? 'https' : 'http';
  const hostHeader = String(req.headers['x-forwarded-host'] || req.headers.host || `localhost:${PORT}`)
    .split(',')[0]
    .trim();
  const safeHost = /^[A-Za-z0-9._:-]{1,200}$/.test(hostHeader) ? hostHeader : `localhost:${PORT}`;
  return `${proto}://${safeHost}`;
}

function getGatewayAvailability() {
  const lenco = getLencoConfig();
  const smtpUser = (process.env.SMTP_USER || '').trim();
  const smtpPass = (process.env.SMTP_PASS || '').trim();
  const resendKey = (process.env.RESEND_API_KEY || '').trim();
  const waToken = (process.env.WHATSAPP_TOKEN || '').trim();
  const waPhoneId = (process.env.WHATSAPP_PHONE_NUMBER_ID || '').trim();

  return {
    lencoConfigured: lenco.configured,
    lencoPublicConfigured: lenco.publicConfigured,
    lencoEnv: lenco.env,
    smtpConfigured: Boolean(smtpUser && smtpPass && !smtpPass.includes('MY_')),
    resendConfigured: Boolean(resendKey && !resendKey.includes('MY_')),
    whatsappCloudConfigured: Boolean(waToken && waPhoneId && !waToken.includes('MY_')),
  };
}

function buildWhatsAppDeepLink(message: string): string {
  return `https://wa.me/${BUSINESS_WHATSAPP}?text=${encodeURIComponent(message)}`;
}

async function sendEmailNotification(params: {
  subject: string;
  textBody: string;
  htmlBody: string;
  replyToEmail?: string;
  customerReceiptEmail?: string;
  customerSubject?: string;
  customerHtmlBody?: string;
}): Promise<{ sent: boolean; provider: string; error?: string }> {
  const status = getGatewayAvailability();

  if (status.smtpConfigured) {
    try {
      const host = (process.env.SMTP_HOST || 'smtp.gmail.com').trim();
      const port = Number(process.env.SMTP_PORT) || 465;
      const user = (process.env.SMTP_USER || '').trim();
      const pass = (process.env.SMTP_PASS || '').trim();
      const transporter = nodemailer.createTransport({
        host,
        port,
        secure: port === 465,
        auth: { user, pass },
      });

      await transporter.sendMail({
        from: `"Zamto Africa Desk" <${user}>`,
        to: BUSINESS_EMAIL,
        replyTo: params.replyToEmail && isValidEmail(params.replyToEmail) ? params.replyToEmail : undefined,
        subject: params.subject,
        text: params.textBody,
        html: params.htmlBody,
      });

      if (
        params.customerReceiptEmail &&
        isValidEmail(params.customerReceiptEmail) &&
        params.customerReceiptEmail.toLowerCase() !== BUSINESS_EMAIL.toLowerCase()
      ) {
        await transporter.sendMail({
          from: `"Zamto Africa Company Limited" <${user}>`,
          to: params.customerReceiptEmail,
          replyTo: BUSINESS_EMAIL,
          subject: params.customerSubject || params.subject,
          text: params.textBody,
          html: params.customerHtmlBody || params.htmlBody,
        });
      }

      return { sent: true, provider: 'smtp' };
    } catch (err) {
      return {
        sent: false,
        provider: 'smtp',
        error: err instanceof Error ? err.message : 'SMTP delivery failed',
      };
    }
  }

  if (status.resendConfigured) {
    try {
      const resendKey = (process.env.RESEND_API_KEY || '').trim();
      const fromEmail = (process.env.RESEND_FROM_EMAIL || 'Zamto Africa <onboarding@resend.dev>').trim();
      const resp = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${resendKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          from: fromEmail,
          to: [BUSINESS_EMAIL],
          reply_to:
            params.replyToEmail && isValidEmail(params.replyToEmail) ? params.replyToEmail : undefined,
          subject: params.subject,
          text: params.textBody,
          html: params.htmlBody,
        }),
      });
      if (!resp.ok) {
        const errBody = await resp.text();
        return { sent: false, provider: 'resend', error: errBody.slice(0, 200) };
      }

      if (
        params.customerReceiptEmail &&
        isValidEmail(params.customerReceiptEmail) &&
        params.customerReceiptEmail.toLowerCase() !== BUSINESS_EMAIL.toLowerCase()
      ) {
        try {
          await fetch('https://api.resend.com/emails', {
            method: 'POST',
            headers: {
              Authorization: `Bearer ${resendKey}`,
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              from: fromEmail,
              to: [params.customerReceiptEmail],
              reply_to: BUSINESS_EMAIL,
              subject: params.customerSubject || params.subject,
              text: params.textBody,
              html: params.customerHtmlBody || params.htmlBody,
            }),
          });
        } catch {
          // Customer receipt requires a verified domain on Resend; ignore if sandbox sender restricts external recipients
        }
      }

      return { sent: true, provider: 'resend' };
    } catch (err) {
      return {
        sent: false,
        provider: 'resend',
        error: err instanceof Error ? err.message : 'Resend delivery failed',
      };
    }
  }

  return { sent: false, provider: 'none' };
}

async function sendWhatsAppCloudNotification(message: string): Promise<{ sent: boolean; error?: string }> {
  const status = getGatewayAvailability();
  if (!status.whatsappCloudConfigured) {
    return { sent: false };
  }
  const token = (process.env.WHATSAPP_TOKEN || '').trim();
  const phoneNumberId = (process.env.WHATSAPP_PHONE_NUMBER_ID || '').trim();

  try {
    const resp = await fetch(
      `https://graph.facebook.com/v21.0/${encodeURIComponent(phoneNumberId)}/messages`,
      {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          messaging_product: 'whatsapp',
          to: BUSINESS_WHATSAPP,
          type: 'text',
          text: { preview_url: false, body: message.slice(0, 3800) },
        }),
      }
    );
    if (!resp.ok) {
      const errText = await resp.text();
      return { sent: false, error: errText.slice(0, 200) };
    }
    return { sent: true };
  } catch (err) {
    return {
      sent: false,
      error: err instanceof Error ? err.message : 'WhatsApp Cloud request failed',
    };
  }
}

async function startServer() {
  const app = express();
  app.set('trust proxy', 1);

  // Lenco signed webhook endpoint (must use raw body before express.json parses it)
  app.post(
    '/api/payments/lenco/webhook',
    express.raw({ type: 'application/json', limit: '512kb' }),
    (req: Request, res: Response) => {
      const lenco = getLencoConfig();
      if (!lenco.configured) {
        res.status(503).send('Lenco not configured');
        return;
      }

      const signatureHeader = String(req.headers['x-lenco-signature'] || '').trim().toLowerCase();
      if (!signatureHeader || !/^[0-9a-f]{128}$/.test(signatureHeader)) {
        res.status(400).send('Missing or malformed signature');
        return;
      }

      const rawPayload = Buffer.isBuffer(req.body) ? req.body : Buffer.from('');
      const webhookHashKey = crypto.createHash('sha256').update(lenco.secretKey).digest('hex');
      const computedSignature = crypto
        .createHmac('sha512', webhookHashKey)
        .update(rawPayload)
        .digest('hex');

      const sigBuf = Buffer.from(signatureHeader, 'hex');
      const compBuf = Buffer.from(computedSignature, 'hex');
      if (sigBuf.length !== compBuf.length || !crypto.timingSafeEqual(sigBuf, compBuf)) {
        res.status(401).send('Invalid signature');
        return;
      }

      try {
        const payload = JSON.parse(rawPayload.toString('utf8')) as {
          event?: string;
          data?: {
            reference?: string;
            lencoReference?: string;
            status?: string;
            amount?: string | number;
            currency?: string;
            reasonForFailure?: string | null;
          };
        };

        const data = payload.data;
        const ref = sanitizeSafeId(data?.reference);
        if (ref && data) {
          let nextStatus = cleanText(data.status, 40) || 'pending';
          if (payload.event === 'collection.successful' || payload.event === 'collection.settled') {
            nextStatus = 'successful';
          } else if (payload.event === 'collection.failed') {
            nextStatus = 'failed';
          }

          setBoundedMap(verifiedLencoWebhooks, ref, {
            reference: ref,
            lencoReference: cleanText(data.lencoReference, 80) || undefined,
            status: nextStatus,
            amount: Number(data.amount || 0),
            currency: cleanText(data.currency, 10) || 'ZMW',
            reasonForFailure: data.reasonForFailure ? cleanText(data.reasonForFailure, 200) : null,
            updatedAt: Date.now(),
          });
        }
        res.status(200).json({ received: true });
      } catch {
        res.status(400).send('Invalid JSON payload');
      }
    }
  );

  app.use(express.json({ limit: '10mb' }));

  app.get('/api/health', (_req: Request, res: Response) => {
    res.json({ ok: true });
  });

  // ---------------- CLOUD SQL PUBLIC FLEET & SETTINGS ----------------
  app.get('/api/fleet', async (_req: Request, res: Response) => {
    try {
      const [hireFleet, salesInventory, fxSetting] = await Promise.all([
        listHireVehicles(),
        listSaleVehicles(),
        getSetting<{ rate?: number; source?: string; updatedAt?: string }>('fx_rate'),
      ]);
      res.json({
        hireFleet,
        salesInventory,
        fxRate: fxSetting && typeof fxSetting.rate === 'number' ? fxSetting : null,
      });
    } catch (error) {
      console.error('GET /api/fleet failed:', error);
      res.status(500).json({ error: 'Unable to load fleet catalog from database.' });
    }
  });

  // ---------------- CUSTOMER BOOKINGS & SELLER LEADS (CLOUD SQL) ----------------
  app.post('/api/bookings', async (req: Request, res: Response) => {
    const body = (req.body || {}) as Partial<CustomerBooking>;
    const id = sanitizeSafeId(body.id);
    const vehicleId = cleanText(body.vehicleId, 100);
    const vehicleName = cleanText(body.vehicleName, 160);
    const customerName = cleanText(body.customerName, 120);
    const customerPhone = cleanText(body.customerPhone, 50);
    const totalZmw = Number(body.totalZmw);

    if (!id || !vehicleId || !vehicleName || !customerName || !customerPhone || !Number.isFinite(totalZmw)) {
      res.status(400).json({ error: 'Missing required booking fields.' });
      return;
    }

    const booking: CustomerBooking = {
      ...(body as CustomerBooking),
      id,
      type:
        body.type === 'Test Drive' || body.type === 'Purchase Offer' ? body.type : 'Car Hire',
      vehicleId,
      vehicleName,
      customerName,
      customerPhone,
      customerEmail: cleanText(body.customerEmail, 160) || BUSINESS_EMAIL,
      totalZmw: Math.max(0, Math.round(totalZmw)),
      paymentMethod: cleanText(body.paymentMethod, 60) || 'Airtel Money',
      paymentStatus:
        body.paymentStatus === 'Paid' ||
        body.paymentStatus === 'Deposit Paid' ||
        body.paymentStatus === 'Pending Online Verification'
          ? body.paymentStatus
          : 'Pending Online Verification',
      status:
        body.status === 'Pending Verification' || body.status === 'Cancelled'
          ? body.status
          : 'Confirmed',
      createdAt: cleanText(body.createdAt, 50) || new Date().toISOString(),
    };

    try {
      const saved = await upsertBooking(booking);
      const claimToken = await createBookingClaimToken(saved.id);
      res.status(201).json({ booking: saved, claimToken });
    } catch (error) {
      console.error('POST /api/bookings failed:', error);
      res.status(500).json({ error: 'Could not save booking to database.' });
    }
  });

  app.post('/api/bookings/mine', async (req: Request, res: Response) => {
    const claimsRaw = (req.body as { claims?: unknown })?.claims;
    if (!Array.isArray(claimsRaw)) {
      res.status(400).json({ error: 'Invalid booking lookup payload.' });
      return;
    }
    try {
      const validIds: string[] = [];
      for (const item of claimsRaw.slice(0, 50)) {
        if (!item || typeof item !== 'object') continue;
        const rec = item as { id?: unknown; token?: unknown };
        const id = sanitizeSafeId(rec.id);
        const token = typeof rec.token === 'string' ? rec.token.trim() : '';
        if (id && token && (await verifyBookingClaimToken(id, token))) {
          validIds.push(id);
        }
      }
      const rows = await listBookingsByIds(validIds);
      res.json({ bookings: rows });
    } catch (error) {
      console.error('POST /api/bookings/mine failed:', error);
      res.status(500).json({ error: 'Failed to retrieve your bookings.' });
    }
  });

  app.post('/api/bookings/:id/complete-payment', async (req: AuthRequest, res: Response) => {
    const id = sanitizeSafeId(req.params.id);
    const body = (req.body || {}) as {
      claimToken?: unknown;
      paymentMethod?: unknown;
      paymentStatus?: unknown;
      transactionRef?: unknown;
      paidAmountZmw?: unknown;
      paidAt?: unknown;
    };
    const token = typeof body.claimToken === 'string' ? body.claimToken.trim() : '';
    const isAdmin = await isRequestAdmin(req);
    if (!id || (!isAdmin && !(await verifyBookingClaimToken(id, token)))) {
      res.status(403).json({ error: 'Invalid booking authorization token.' });
      return;
    }

    try {
      const existing = await getBookingById(id);
      if (!existing) {
        res.status(404).json({ error: 'Booking not found.' });
        return;
      }

      const paidAmount = Number(body.paidAmountZmw || 0);
      const nextStatus =
        body.paymentStatus === 'Paid' ||
        body.paymentStatus === 'Deposit Paid' ||
        body.paymentStatus === 'Pending Online Verification'
          ? body.paymentStatus
          : existing.paymentStatus || 'Pending Online Verification';

      const updated: CustomerBooking = {
        ...existing,
        paymentMethod: cleanText(body.paymentMethod, 60) || existing.paymentMethod,
        paymentStatus: nextStatus,
        paymentTransactionRef: cleanText(body.transactionRef, 80) || existing.paymentTransactionRef,
        paidAmountZmw:
          (existing.paidAmountZmw || 0) + (Number.isFinite(paidAmount) && paidAmount > 0 ? Math.round(paidAmount) : 0),
        paidAt: cleanText(body.paidAt, 50) || new Date().toISOString(),
        status: nextStatus === 'Pending Online Verification' ? existing.status : 'Confirmed',
      };

      const saved = await upsertBooking(updated);
      res.json({ booking: saved });
    } catch (error) {
      console.error('POST /api/bookings/:id/complete-payment failed:', error);
      res.status(500).json({ error: 'Failed to update booking payment.' });
    }
  });

  app.post('/api/bookings/:id/cancel', async (req: AuthRequest, res: Response) => {
    const id = sanitizeSafeId(req.params.id);
    const token =
      typeof (req.body as { claimToken?: unknown })?.claimToken === 'string'
        ? (req.body as { claimToken: string }).claimToken.trim()
        : '';
    const isAdmin = await isRequestAdmin(req);
    if (!id || (!isAdmin && !(await verifyBookingClaimToken(id, token)))) {
      res.status(403).json({ error: 'Invalid booking authorization token.' });
      return;
    }

    try {
      const existing = await getBookingById(id);
      if (!existing) {
        res.status(404).json({ error: 'Booking not found.' });
        return;
      }
      const saved = await upsertBooking({ ...existing, status: 'Cancelled' });
      res.json({ booking: saved });
    } catch (error) {
      console.error('POST /api/bookings/:id/cancel failed:', error);
      res.status(500).json({ error: 'Failed to cancel booking.' });
    }
  });

  app.post('/api/seller-leads', async (req: Request, res: Response) => {
    const body = (req.body || {}) as Partial<SellCarSubmission>;
    const id = sanitizeSafeId(body.id) || `SELL-${Date.now()}`;
    const name = cleanText(body.name, 120);
    const phone = cleanText(body.phone, 50);
    const makeModel = cleanText(body.makeModel, 140);
    const askingPriceZmw = Number(body.askingPriceZmw);

    if (!name || !phone || !makeModel || !Number.isFinite(askingPriceZmw)) {
      res.status(400).json({ error: 'Name, phone, vehicle model, and price are required.' });
      return;
    }

    const lead: SellCarSubmission = {
      id,
      sellerType: body.sellerType === 'Dealer Partner' ? 'Dealer Partner' : 'Private Seller',
      name,
      phone,
      city: cleanText(body.city, 80) || 'Lusaka',
      makeModel,
      year: Math.round(Number(body.year) || new Date().getFullYear()),
      mileageKm: Math.max(0, Math.round(Number(body.mileageKm) || 0)),
      askingPriceZmw: Math.max(0, Math.round(askingPriceZmw)),
      condition: cleanText(body.condition, 80) || 'Good',
      createdAt: cleanText(body.createdAt, 50) || new Date().toISOString(),
    };

    try {
      const saved = await insertSellerLead(lead);
      res.status(201).json({ lead: saved });
    } catch (error) {
      console.error('POST /api/seller-leads failed:', error);
      res.status(500).json({ error: 'Failed to save vehicle valuation.' });
    }
  });

  app.get('/api/resend-template-preview', (req: Request, res: Response) => {
    const origin = resolveTrustedOrigin(req);
    const logoUrl = `${origin}${ZAMTO_BRAND_LOGO_PATH}`;
    const sampleWhatsapp = buildWhatsAppDeepLink(
      'Hello Zamto Africa, checking Car Hire Booking ZAMTO-8842A1'
    );
    const html = buildBrandedResendEmailHtml({
      logoUrl,
      siteUrl: origin,
      kind: 'Car Hire Booking',
      reference: 'ZAMTO-8842A1',
      headline: 'Car Hire Booking Confirmation',
      introText:
        'Thank you for choosing Zamto Africa Company Limited. Below is the official record for your booking and Lusaka dispatch reference.',
      rows: [
        { label: 'Submission Type', value: 'Car Hire Booking' },
        { label: 'Reference', value: 'ZAMTO-8842A1' },
        { label: 'Client Name', value: 'Chanda Mwansa' },
        { label: 'Phone / WhatsApp', value: '+260 977 123 456' },
        { label: 'Client Email', value: 'chanda@example.zm' },
        { label: 'Vehicle / Topic', value: 'Toyota Land Cruiser Prado TX-L (Self Drive)' },
        { label: 'Pickup / Location', value: 'Kenneth Kaunda International Airport (KKIA)' },
        { label: 'Drop-off', value: 'Rhodes Park Head Office, Lusaka' },
        { label: 'Dates', value: '2026-12-01 to 2026-12-05 (4 days)' },
      ],
      totalDisplay: '$480.00 (ZMW 9,893 · 16% VAT Included)',
      paymentSummary: 'Paid Online via Lenco Zambia (MTN Mobile Money)',
      notes: 'Flight arrives 14:20 — please meet at KKIA Arrivals Gate.',
      whatsappUrl: sampleWhatsapp,
      supportEmail: BUSINESS_EMAIL,
    });
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.send(html);
  });

  // ---------------- ADMIN AUTH & SESSION ROUTES ----------------
  app.get('/api/admin/session', async (req: AuthRequest, res: Response) => {
    const [authenticated, passwordConfigured] = await Promise.all([
      isRequestAdmin(req),
      isAdminPasswordConfigured(),
    ]);
    res.json({
      authenticated,
      passwordConfigured,
      email: req.user?.email || null,
    });
  });

  app.post('/api/admin/setup-password', async (req: Request, res: Response) => {
    try {
      const alreadyConfigured = await isAdminPasswordConfigured();
      if (alreadyConfigured) {
        res.status(409).json({ error: 'Admin password is already configured. Please sign in.' });
        return;
      }
      const password = String((req.body as { password?: unknown })?.password || '');
      if (password.length < 8 || password.length > 128) {
        res.status(400).json({ error: 'Password must be between 8 and 128 characters.' });
        return;
      }
      await saveNewAdminPassword(password);
      const token = await createSignedAdminSessionToken('admin-password');
      setAdminSessionCookie(req, res, token);

      const authHeader = req.headers.authorization;
      if (authHeader && authHeader.startsWith('Bearer ')) {
        try {
          const decoded = await adminAuth.verifyIdToken(authHeader.split('Bearer ')[1]);
          if (decoded.email) {
            await promoteUserToAdmin(decoded.uid, decoded.email);
          }
        } catch {
          // Optional Google account linking ignored if invalid
        }
      }

      res.json({ authenticated: true, passwordConfigured: true });
    } catch (error) {
      console.error('POST /api/admin/setup-password failed:', error);
      res.status(500).json({ error: 'Could not save admin password.' });
    }
  });

  app.post('/api/admin/login', async (req: Request, res: Response) => {
    const ip = req.ip || 'unknown';
    if (!checkLoginRateLimit(ip)) {
      res.status(429).json({ error: 'Too many failed attempts. Wait 15 minutes and try again.' });
      return;
    }

    const password = String((req.body as { password?: unknown })?.password || '');
    const configured = await isAdminPasswordConfigured();
    if (!configured) {
      res.status(400).json({ error: 'No admin password has been set yet.' });
      return;
    }

    const valid = await verifyAdminPassword(password);
    if (!valid) {
      recordFailedLoginAttempt(ip);
      res.status(401).json({ error: 'Incorrect admin password.' });
      return;
    }

    clearLoginAttempts(ip);
    const token = await createSignedAdminSessionToken('admin-password');
    setAdminSessionCookie(req, res, token);

    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith('Bearer ')) {
      try {
        const decoded = await adminAuth.verifyIdToken(authHeader.split('Bearer ')[1]);
        if (decoded.email) {
          await promoteUserToAdmin(decoded.uid, decoded.email);
        }
      } catch {
        // Optional Firebase user promotion ignored if no valid token
      }
    }

    res.json({ authenticated: true, passwordConfigured: true });
  });

  app.post('/api/admin/logout', (req: Request, res: Response) => {
    clearAdminSessionCookie(req, res);
    res.json({ authenticated: false });
  });

  app.post('/api/admin/change-password', requireAdmin, async (req: Request, res: Response) => {
    const body = (req.body || {}) as { currentPassword?: unknown; newPassword?: unknown };
    const currentPassword = String(body.currentPassword || '');
    const newPassword = String(body.newPassword || '');

    if (!(await verifyAdminPassword(currentPassword))) {
      res.status(401).json({ error: 'Current password is incorrect.' });
      return;
    }
    if (newPassword.length < 8 || newPassword.length > 128) {
      res.status(400).json({ error: 'New password must be between 8 and 128 characters.' });
      return;
    }

    try {
      await saveNewAdminPassword(newPassword);
      const token = await createSignedAdminSessionToken('admin-password');
      setAdminSessionCookie(req, res, token);
      res.json({ ok: true });
    } catch (error) {
      console.error('POST /api/admin/change-password failed:', error);
      res.status(500).json({ error: 'Failed to update admin password.' });
    }
  });

  // ---------------- PROTECTED ADMIN CLOUD SQL ROUTES ----------------
  app.get('/api/admin/dashboard', requireAdmin, async (_req: Request, res: Response) => {
    try {
      const [allBookings, allLeads] = await Promise.all([
        listAllBookings(),
        listAllSellerLeads(),
      ]);
      res.json({ bookings: allBookings, sellerLeads: allLeads });
    } catch (error) {
      console.error('GET /api/admin/dashboard failed:', error);
      res.status(500).json({ error: 'Failed to load admin records.' });
    }
  });

  app.put('/api/admin/fx-rate', requireAdmin, async (req: Request, res: Response) => {
    const body = (req.body || {}) as { rate?: unknown; source?: unknown };
    const rate = Number(body.rate);
    if (!Number.isFinite(rate) || rate < 5 || rate > 100) {
      res.status(400).json({ error: 'Exchange rate must be between 5 and 100 ZMW/USD.' });
      return;
    }
    const rounded = Math.round(rate * 100) / 100;
    const fxRate = {
      rate: rounded,
      source: body.source === 'live' ? 'live' : 'admin',
      updatedAt: new Date().toISOString(),
    };
    try {
      await setSetting('fx_rate', fxRate);
      res.json({ fxRate });
    } catch (error) {
      console.error('PUT /api/admin/fx-rate failed:', error);
      res.status(500).json({ error: 'Failed to save exchange rate.' });
    }
  });

  app.post('/api/admin/hire-vehicles', requireAdmin, async (req: Request, res: Response) => {
    const v = (req.body || {}) as Partial<HireVehicle>;
    const id = sanitizeSafeId(v.id) || `hire-custom-${Date.now()}`;
    const name = cleanText(v.name, 140);
    if (!name) {
      res.status(400).json({ error: 'Vehicle name is required.' });
      return;
    }
    const payload: HireVehicle = {
      ...(v as HireVehicle),
      id,
      name,
      brand: cleanText(v.brand, 60) || name.split(' ')[0] || 'Toyota',
      dailyRateZmw: Math.max(0, Math.round(Number(v.dailyRateZmw || v.premiumRateZmw || 0))),
      photos: Array.isArray(v.photos) && v.photos.length > 0 ? v.photos : [],
    };
    try {
      const saved = await upsertHireVehicle(payload);
      res.status(201).json({ vehicle: saved });
    } catch (error) {
      console.error('POST /api/admin/hire-vehicles failed:', error);
      res.status(500).json({ error: 'Failed to add hire vehicle.' });
    }
  });

  app.put('/api/admin/hire-vehicles/:id', requireAdmin, async (req: Request, res: Response) => {
    const id = sanitizeSafeId(req.params.id);
    const v = (req.body || {}) as Partial<HireVehicle>;
    if (!id || !cleanText(v.name, 140)) {
      res.status(400).json({ error: 'Valid vehicle ID and name are required.' });
      return;
    }
    const payload: HireVehicle = {
      ...(v as HireVehicle),
      id,
      name: cleanText(v.name, 140),
      brand: cleanText(v.brand, 60) || 'Toyota',
      dailyRateZmw: Math.max(0, Math.round(Number(v.dailyRateZmw || v.premiumRateZmw || 0))),
    };
    try {
      const saved = await upsertHireVehicle(payload);
      res.json({ vehicle: saved });
    } catch (error) {
      console.error('PUT /api/admin/hire-vehicles/:id failed:', error);
      res.status(500).json({ error: 'Failed to update hire vehicle.' });
    }
  });

  app.delete('/api/admin/hire-vehicles/:id', requireAdmin, async (req: Request, res: Response) => {
    const id = sanitizeSafeId(req.params.id);
    if (!id) {
      res.status(400).json({ error: 'Invalid vehicle ID.' });
      return;
    }
    try {
      await deleteHireVehicleById(id);
      res.json({ ok: true });
    } catch (error) {
      console.error('DELETE /api/admin/hire-vehicles/:id failed:', error);
      res.status(500).json({ error: 'Failed to delete hire vehicle.' });
    }
  });

  app.post('/api/admin/sale-vehicles', requireAdmin, async (req: Request, res: Response) => {
    const v = (req.body || {}) as Partial<SaleVehicle>;
    const id = sanitizeSafeId(v.id) || `sale-custom-${Date.now()}`;
    const name = cleanText(v.name, 140);
    if (!name) {
      res.status(400).json({ error: 'Vehicle name is required.' });
      return;
    }
    const payload: SaleVehicle = {
      ...(v as SaleVehicle),
      id,
      name,
      make: cleanText(v.make, 60) || 'Toyota',
      year: Math.round(Number(v.year) || 2020),
      priceZmw: Math.max(0, Math.round(Number(v.priceZmw) || 0)),
      photos: Array.isArray(v.photos) && v.photos.length > 0 ? v.photos : [],
    };
    try {
      const saved = await upsertSaleVehicle(payload);
      res.status(201).json({ vehicle: saved });
    } catch (error) {
      console.error('POST /api/admin/sale-vehicles failed:', error);
      res.status(500).json({ error: 'Failed to add sales vehicle.' });
    }
  });

  app.put('/api/admin/sale-vehicles/:id', requireAdmin, async (req: Request, res: Response) => {
    const id = sanitizeSafeId(req.params.id);
    const v = (req.body || {}) as Partial<SaleVehicle>;
    if (!id || !cleanText(v.name, 140)) {
      res.status(400).json({ error: 'Valid vehicle ID and name are required.' });
      return;
    }
    const payload: SaleVehicle = {
      ...(v as SaleVehicle),
      id,
      name: cleanText(v.name, 140),
      make: cleanText(v.make, 60) || 'Toyota',
      year: Math.round(Number(v.year) || 2020),
      priceZmw: Math.max(0, Math.round(Number(v.priceZmw) || 0)),
    };
    try {
      const saved = await upsertSaleVehicle(payload);
      res.json({ vehicle: saved });
    } catch (error) {
      console.error('PUT /api/admin/sale-vehicles/:id failed:', error);
      res.status(500).json({ error: 'Failed to update sales vehicle.' });
    }
  });

  app.delete('/api/admin/sale-vehicles/:id', requireAdmin, async (req: Request, res: Response) => {
    const id = sanitizeSafeId(req.params.id);
    if (!id) {
      res.status(400).json({ error: 'Invalid vehicle ID.' });
      return;
    }
    try {
      await deleteSaleVehicleById(id);
      res.json({ ok: true });
    } catch (error) {
      console.error('DELETE /api/admin/sale-vehicles/:id failed:', error);
      res.status(500).json({ error: 'Failed to delete sales vehicle.' });
    }
  });

  app.post('/api/admin/reset-fleet', requireAdmin, async (_req: Request, res: Response) => {
    try {
      const reset = await resetAllFleetDefaults();
      res.json(reset);
    } catch (error) {
      console.error('POST /api/admin/reset-fleet failed:', error);
      res.status(500).json({ error: 'Failed to reset fleet defaults.' });
    }
  });

  app.patch('/api/admin/bookings/:id', requireAdmin, async (req: Request, res: Response) => {
    const id = sanitizeSafeId(req.params.id);
    if (!id) {
      res.status(400).json({ error: 'Invalid booking ID.' });
      return;
    }
    const body = (req.body || {}) as {
      status?: CustomerBooking['status'];
      paymentStatus?: CustomerBooking['paymentStatus'];
    };
    try {
      const existing = await getBookingById(id);
      if (!existing) {
        res.status(404).json({ error: 'Booking not found.' });
        return;
      }
      const next: CustomerBooking = {
        ...existing,
        status:
          body.status === 'Confirmed' ||
          body.status === 'Pending Verification' ||
          body.status === 'Cancelled'
            ? body.status
            : existing.status,
        paymentStatus:
          body.paymentStatus === 'Paid' ||
          body.paymentStatus === 'Deposit Paid' ||
          body.paymentStatus === 'Pending Online Verification'
            ? body.paymentStatus
            : existing.paymentStatus,
      };
      const saved = await upsertBooking(next);
      res.json({ booking: saved });
    } catch (error) {
      console.error('PATCH /api/admin/bookings/:id failed:', error);
      res.status(500).json({ error: 'Failed to update booking.' });
    }
  });

  app.delete('/api/admin/bookings/:id', requireAdmin, async (req: Request, res: Response) => {
    const id = sanitizeSafeId(req.params.id);
    if (!id) {
      res.status(400).json({ error: 'Invalid booking ID.' });
      return;
    }
    try {
      await deleteBookingById(id);
      res.json({ ok: true });
    } catch (error) {
      console.error('DELETE /api/admin/bookings/:id failed:', error);
      res.status(500).json({ error: 'Failed to delete booking.' });
    }
  });

  app.get('/api/payments/config', (_req: Request, res: Response) => {
    const avail = getGatewayAvailability();
    const lenco = getLencoConfig();
    res.json({
      lencoConfigured: avail.lencoConfigured,
      lencoPublicConfigured: avail.lencoPublicConfigured,
      lencoPublicKey: lenco.publicConfigured ? lenco.publicKey : undefined,
      lencoEnv: lenco.env,
      livePaymentsReady: avail.lencoConfigured,
      vatInclusive: true,
      vatRatePercent: 16,
      emailConfigured: avail.smtpConfigured || avail.resendConfigured,
      whatsappCloudConfigured: avail.whatsappCloudConfigured,
      notificationEmail: BUSINESS_EMAIL,
      whatsappNumberDisplay: '+260 572 213 038',
    });
  });

  app.post('/api/payments/initiate', async (req: Request, res: Response) => {
    const body = (req.body || {}) as Record<string, unknown>;
    const rail = cleanText(body.rail, 60);
    if (!ALLOWED_RAILS.has(rail)) {
      res.status(400).json({ error: 'Unsupported payment method selected.' });
      return;
    }

    const amountZmw = Number(body.amountZmw);
    if (!Number.isFinite(amountZmw) || amountZmw < 0 || amountZmw > 50_000_000) {
      res.status(400).json({ error: 'Invalid payment amount.' });
      return;
    }

    const customerName = cleanText(body.customerName, 120) || 'Zamto Guest';
    const customerPhone = cleanText(body.customerPhone, 40) || '+260';
    const rawEmail = cleanText(body.customerEmail, 160);
    const customerEmail = isValidEmail(rawEmail) ? rawEmail : BUSINESS_EMAIL;

    const txRef = `ZAMTO-${crypto.randomBytes(4).toString('hex').toUpperCase()}`;
    const avail = getGatewayAvailability();
    const origin = resolveTrustedOrigin(req);

    if (rail === 'Bank EFT / Zanaco') {
      const bankRef = cleanText(body.bankRef, 60);
      res.json({
        mode: 'bank_eft',
        configured: true,
        txRef: bankRef || `EFT-ZM-${crypto.randomBytes(3).toString('hex').toUpperCase()}`,
        paymentStatus: bankRef ? 'Deposit Paid' : 'Pending Online Verification',
        paidAmountZmw: bankRef ? Math.round(amountZmw) : 0,
      });
      return;
    }

    if (amountZmw < 10) {
      res.status(400).json({ error: 'Minimum online payment is ZMW 10.' });
      return;
    }

    // 1) Primary Zambia Gateway: Lenco API v2 Mobile Money (Airtel Money, MTN MoMo, Zamtel Kwacha)
    if (
      (rail === 'MTN Mobile Money' || rail === 'Airtel Money' || rail === 'Zamtel Kwacha') &&
      avail.lencoConfigured
    ) {
      const lenco = getLencoConfig();
      const localPhone = normalizeZambiaMomoPhone(customerPhone);
      if (!localPhone) {
        res.status(400).json({
          error: 'Enter a valid Zambian Mobile Money number (e.g. 097 / 096 / 095 / 076 / 077).',
        });
        return;
      }

      const operator =
        rail === 'MTN Mobile Money'
          ? 'mtn'
          : rail === 'Airtel Money'
          ? 'airtel'
          : 'zamtel';
      const chargeAmount = Math.round(amountZmw * 100) / 100;

      try {
        const lencoPayload: Record<string, unknown> = {
          amount: chargeAmount,
          reference: txRef,
          phone: localPhone,
          operator,
          country: 'zm',
          bearer: 'merchant',
        };
        if (lenco.accountId) {
          lencoPayload.accountId = lenco.accountId;
        }

        const lencoRes = await fetch(`${lenco.baseUrl}/collections/mobile-money`, {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${lenco.secretKey}`,
            Accept: 'application/json',
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(lencoPayload),
        });

        const lencoJson = (await lencoRes.json()) as {
          status?: boolean;
          message?: string;
          data?: {
            id?: string;
            reference?: string;
            lencoReference?: string;
            status?: string;
            reasonForFailure?: string | null;
          };
        };

        if (!lencoRes.ok || !lencoJson.status) {
          res.status(400).json({
            error: lencoJson.message || `Lenco ${rail} collection could not be initiated.`,
          });
          return;
        }

        const resolvedRef = lencoJson.data?.reference || txRef;
        setBoundedMap(pendingLencoOrders, resolvedRef, {
          expectedAmountZmw: chargeAmount,
          currency: 'ZMW',
          rail,
          createdAt: Date.now(),
        });

        res.json({
          mode: 'live_momo_pending',
          configured: true,
          provider: 'lenco',
          txRef: resolvedRef,
          transactionId: lencoJson.data?.id,
          lencoReference: lencoJson.data?.lencoReference,
          lencoStatus: lencoJson.data?.status || 'pay-offline',
          message:
            lencoJson.message ||
            `Lenco prompt sent to ${localPhone}. Enter your ${rail} PIN on your phone to confirm.`,
        });
        return;
      } catch (err) {
        res.status(502).json({
          error: err instanceof Error ? err.message : 'Lenco gateway connection failed.',
        });
        return;
      }
    }

    // 2) Lenco Pay Inline Checkout (Visa / Mastercard & Online Card/Mobile Channels)
    if (rail === 'Visa / Mastercard' && avail.lencoConfigured && avail.lencoPublicConfigured) {
      const lenco = getLencoConfig();
      const chargeAmount = Math.round(amountZmw * 100) / 100;
      const nameParts = customerName.split(/\s+/).filter(Boolean);
      const firstName = nameParts[0] || 'Zamto';
      const lastName = nameParts.slice(1).join(' ') || 'Guest';
      const localPhone = normalizeZambiaMomoPhone(customerPhone) || undefined;

      setBoundedMap(pendingLencoOrders, txRef, {
        expectedAmountZmw: chargeAmount,
        currency: 'ZMW',
        rail,
        createdAt: Date.now(),
      });

      res.json({
        mode: 'lenco_inline',
        configured: true,
        provider: 'lenco',
        publicKey: lenco.publicKey,
        env: lenco.env,
        txRef,
        amount: chargeAmount,
        currency: 'ZMW',
        channels: ['card', 'mobile-money'],
        customer: {
          email: customerEmail,
          phone: localPhone,
          firstName,
          lastName,
        },
        redirectUrl: `${origin}/?gateway=lenco&tx_ref=${encodeURIComponent(txRef)}`,
        message: 'Opening Lenco secure checkout...',
      });
      return;
    }

    // Lenco secret/public key not yet configured — record reservation pending online verification
    res.json({
      mode: 'gateway_unconfigured',
      configured: false,
      txRef: `REQ-${crypto.randomBytes(3).toString('hex').toUpperCase()}`,
      paymentStatus: 'Pending Online Verification',
      paidAmountZmw: 0,
      message:
        'Lenco online merchant keys are not configured yet. Reservation saved as pending online payment verification.',
    });
  });

  app.get('/api/payments/verify', async (req: Request, res: Response) => {
    const provider = cleanText(req.query.provider, 20);
    const transactionId = sanitizeSafeId(req.query.transactionId);
    const txRef = sanitizeSafeId(req.query.txRef);

    if (provider === 'lenco' && (txRef || transactionId)) {
      const lenco = getLencoConfig();
      if (!lenco.configured) {
        res.status(503).json({ verified: false, error: 'Lenco secret key is not configured.' });
        return;
      }

      const webhookHit = txRef ? verifiedLencoWebhooks.get(txRef) : undefined;
      const expected = txRef ? pendingLencoOrders.get(txRef) : undefined;

      try {
        const endpoint = txRef
          ? `${lenco.baseUrl}/collections/status/${encodeURIComponent(txRef)}`
          : `${lenco.baseUrl}/collections/${encodeURIComponent(transactionId)}`;

        const lencoRes = await fetch(endpoint, {
          headers: {
            Authorization: `Bearer ${lenco.secretKey}`,
            Accept: 'application/json',
          },
        });
        const lencoJson = (await lencoRes.json()) as {
          status?: boolean;
          message?: string;
          data?: {
            id?: string;
            reference?: string;
            lencoReference?: string;
            status?: string;
            amount?: string | number;
            currency?: string;
            reasonForFailure?: string | null;
          };
        };

        const apiStatus = lencoJson.data?.status || webhookHit?.status || 'pending';
        const paidAmount = Number(lencoJson.data?.amount ?? webhookHit?.amount ?? 0);
        const paidCurrency = (lencoJson.data?.currency || webhookHit?.currency || 'ZMW').toUpperCase();

        const amountMatches =
          !expected || (paidAmount + 0.01 >= expected.expectedAmountZmw && paidCurrency === expected.currency);

        const isSuccessful =
          amountMatches &&
          ((lencoRes.ok && lencoJson.status && apiStatus === 'successful') ||
            webhookHit?.status === 'successful');

        if (isSuccessful && txRef) {
          pendingLencoOrders.delete(txRef);
        }

        res.json({
          verified: isSuccessful,
          provider: 'lenco',
          status: apiStatus,
          transactionRef:
            lencoJson.data?.lencoReference ||
            webhookHit?.lencoReference ||
            lencoJson.data?.reference ||
            txRef ||
            transactionId,
          amount: paidAmount,
          currency: paidCurrency,
          reasonForFailure: lencoJson.data?.reasonForFailure || webhookHit?.reasonForFailure || null,
        });
        return;
      } catch (err) {
        if (webhookHit?.status === 'successful') {
          const amountMatches =
            !expected ||
            (webhookHit.amount + 0.01 >= expected.expectedAmountZmw &&
              webhookHit.currency.toUpperCase() === expected.currency);
          if (amountMatches) {
            res.json({
              verified: true,
              provider: 'lenco',
              status: 'successful',
              transactionRef: webhookHit.lencoReference || webhookHit.reference,
              amount: webhookHit.amount,
              currency: webhookHit.currency,
            });
            return;
          }
        }
        res.status(502).json({
          verified: false,
          error: err instanceof Error ? err.message : 'Lenco verification error',
        });
        return;
      }
    }

    res.status(400).json({ verified: false, error: 'Missing valid Lenco verification parameters.' });
  });

  app.post('/api/notify', async (req: Request, res: Response) => {
    const body = (req.body || {}) as Record<string, unknown>;
    const kind = cleanText(body.kind, 60) || 'Inquiry';
    const reference = cleanText(body.reference, 50) || `ZA-${Date.now().toString().slice(-6)}`;
    const customerName = cleanText(body.customerName, 120);
    const customerPhone = cleanText(body.customerPhone, 50);
    const customerEmail = cleanText(body.customerEmail, 160);
    const topicOrVehicle = cleanText(body.topicOrVehicle, 160);
    const pickupLocation = cleanText(body.pickupLocation, 180);
    const dropoffLocation = cleanText(body.dropoffLocation, 180);
    const dateRange = cleanText(body.dateRange, 100);
    const totalDisplay = cleanText(body.totalDisplay, 60);
    const paymentSummary = cleanText(body.paymentSummary, 140);
    const messageText = cleanText(body.message, 1500);

    if (!customerName || !customerPhone) {
      res.status(400).json({ error: 'Customer name and phone/WhatsApp number are required.' });
      return;
    }

    const lines = [
      `ZAMTO AFRICA — ${kind.toUpperCase()} (${reference})`,
      `Client: ${customerName}`,
      `Phone / WhatsApp: ${customerPhone}`,
      customerEmail ? `Email: ${customerEmail}` : '',
      topicOrVehicle ? `Vehicle / Topic: ${topicOrVehicle}` : '',
      pickupLocation ? `Pickup / Area: ${pickupLocation}` : '',
      dropoffLocation ? `Drop-off: ${dropoffLocation}` : '',
      dateRange ? `Dates: ${dateRange}` : '',
      totalDisplay ? `Amount: ${totalDisplay}` : '',
      paymentSummary ? `Payment: ${paymentSummary}` : '',
      messageText ? `Details: ${messageText}` : '',
    ].filter(Boolean);

    const plainText = lines.join('\n');
    const subject = `[Zamto Africa ${kind}] ${reference} — ${customerName}`;
    const origin = resolveTrustedOrigin(req);
    const logoUrl = `${origin}${ZAMTO_BRAND_LOGO_PATH}`;
    const whatsappDeepLink = buildWhatsAppDeepLink(plainText);

    const templateRows = [
      { label: 'Submission Type', value: kind },
      { label: 'Reference', value: reference },
      { label: 'Client Name', value: customerName },
      { label: 'Phone / WhatsApp', value: customerPhone },
      { label: 'Client Email', value: customerEmail || 'Not provided' },
      { label: 'Vehicle / Topic', value: topicOrVehicle || 'General' },
      { label: 'Pickup / Location', value: pickupLocation },
      { label: 'Drop-off', value: dropoffLocation },
      { label: 'Dates', value: dateRange },
    ];

    const htmlBody = buildBrandedResendEmailHtml({
      logoUrl,
      siteUrl: origin,
      kind,
      reference,
      headline: `${kind} Dispatch Alert`,
      introText:
        'A new customer submission was received on the Zamto Africa platform. Review the booking and payment verification summary below.',
      rows: templateRows,
      totalDisplay,
      paymentSummary,
      notes: messageText,
      whatsappUrl: whatsappDeepLink,
      supportEmail: BUSINESS_EMAIL,
    });

    const customerHtmlBody = buildBrandedResendEmailHtml({
      logoUrl,
      siteUrl: origin,
      kind,
      reference,
      headline: `${kind} Confirmation`,
      introText: `Dear ${customerName}, thank you for choosing Zamto Africa Company Limited. Your request and reference number have been logged with our Rhodes Park, Lusaka dispatch desk.`,
      rows: templateRows,
      totalDisplay,
      paymentSummary,
      notes: messageText,
      whatsappUrl: whatsappDeepLink,
      supportEmail: BUSINESS_EMAIL,
    });

    const [emailResult, waResult] = await Promise.all([
      sendEmailNotification({
        subject,
        textBody: plainText,
        htmlBody,
        customerHtmlBody,
        replyToEmail: customerEmail,
        customerReceiptEmail: kind === 'Car Hire Booking' ? customerEmail : undefined,
        customerSubject: `Zamto Africa Confirmation — ${reference}`,
      }),
      sendWhatsAppCloudNotification(plainText),
    ]);

    res.json({
      ok: true,
      reference,
      emailSent: emailResult.sent,
      emailProvider: emailResult.provider,
      emailError: emailResult.error,
      whatsappCloudSent: waResult.sent,
      whatsappUrl: buildWhatsAppDeepLink(plainText),
      mailtoUrl: `mailto:${BUSINESS_EMAIL}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(
        plainText
      )}`,
      targetEmail: BUSINESS_EMAIL,
      targetWhatsAppDisplay: '+260 572 213 038',
    });
  });

  const httpServer = http.createServer(app);
  const isProduction = process.env.NODE_ENV === 'production';

  if (!isProduction) {
    const { createServer } = await import('vite');
    const enableHmr = process.env.DISABLE_HMR === 'false';
    const vite = await createServer({
      server: {
        middlewareMode: true,
        allowedHosts: true,
        hmr: enableHmr ? { server: httpServer } : false,
        ws: { server: httpServer },
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req: Request, res: Response) => {
      const indexFile = path.join(distDir, 'index.html');
      if (fs.existsSync(indexFile)) {
        res.sendFile(indexFile);
      } else {
        res.status(404).send('Build output not found.');
      }
    });
  }

  httpServer.listen(PORT, '0.0.0.0', () => {
    console.log(`Zamto Africa server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start Zamto Africa server:', err);
  process.exit(1);
});
